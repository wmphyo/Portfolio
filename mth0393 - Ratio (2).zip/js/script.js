/* Template JS */
/* The State of Queensland (Department of Education and Training) */

//jQuery - Run on page ready
$(function () {
    
    //initial setups
    $('#btnBack').hide();
    nxtBtnMsg = msg.incompleteA;
    $('#inputArea').html(fillTXT[0]);
    $('input').attr('maxlength', '2');
    $('#one, #two').on('input', charLimit);
    $('#instruction').find('span').html(instructionTXT[0]);
    
    if (isApple || isDroid) {
        $('.hover').removeClass('hover');
    }
    
    //create layout
    divineCreation(page, 1, 4, 5, 7);
    
    $('#btnClear').on('click touchend', clearEverything);
    
    $('#btnCheck').on('click touchend', checkFun);
    
    //popup panel and message
    $('#popup, #btnClose').on('click touchend', function(e) {
        e.preventDefault();
        $('#popup').css({visibility: 'hidden'});
    });
    
    //next button and back button actions
    $('#btnBack, #btnNext').on('click touchend', function (e) {
        e.preventDefault();
        var clicked = e.currentTarget.id;        
        if (isApple || isDroid) {$('.hover').removeClass('hover');}
        
        //back button is clicked
        if (clicked === 'btnBack') {
            
            //back button is enable
            if (backBtnCtrl) {
                
                page = 'apple';
                pageChange(page);
                btnCtrl();
                
            }
            
        //next button is clicked
        } else {
            
            //next button is enable
            if (nextBtnCtrl) {
                
                //set it as reset button for second page
                if (page === 'banana') {
                    
                    if (inputs.first === true && inputs.second === true) {
                        location.reload();
                    }
                
                //next button for first page | this will change page.
                } else {
                    
                    page = 'banana';
                    pageChange(page);
                    btnCtrl();
                    
                }
            //next button is disabled | false
            } else {
                //update popup message for - Complete > Next > Back > Next button condition.
                completeRow === 4 ? nxtBtnMsg = msg.completeA : nxtBtnMsg = msg.incompleteA;
                
                //show the popup message
                if (page === 'apple') {
                    $('#popupMsg').html(nxtBtnMsg);
                    $('#popup').css({visibility: 'visible'});
                }
            }
        }

        inputs.first = inputs.second = false;
        $('#one, #two').removeAttr('disabled');
        
    });
    
    //to hide popup box when clicking on input boxes.
    $('#one, #two').on('click touchend', function (){
        $('#popup').css({'visibility':'hidden'}) ;
    });
});

function checkFun () {
    var rowCount, incompleteMSG, completeMSG, correctMSG;
    
    //assign variables according to current page
    if (page === 'apple') {
        
        rowCount = 4;
        correctMSG = msg.correctA;
        completeMSG = msg.completeA;
        incompleteMSG = msg.incompleteA;
        
    } else {
        
        rowCount = 5;
        correctMSG = msg.correctB;
        completeMSG = msg.completeB;
        incompleteMSG = msg.incompleteB;
        
    }
    
    //check values in input boxes.
    checkInput();
    
    //check inserted images
    checkImages();
    
    //not all rows are completed
    if (completeRow !== rowCount) {
        
        nxtBtnMsg = incompleteMSG;
        $('#popupMsg').html(incompleteMSG);        
        
    //when all rows are completed
    } else {
                    
        //both inputs are correct
        if (inputs.first === true && inputs.second === true) {
            
            nextBtnCtrl = true;
            nxtBtnMsg = correctMSG;
            $('#btnNext').btnEnabled();
            $('#popupMsg').html(correctMSG);
            $('#one, #two').attr('disabled', 'disabled');
            
        //inputs are incorrect
        } else {
            
            $('#popupMsg').html(completeMSG);
            nxtBtnMsg = completeMSG;
        }
    }
    
    //show popup message
    $('#popup').css({visibility: 'visible'});
    
}

function divineCreation (page, rowNum, imgCount, rowCount, colCount) {
    var fruitClass;
    
    //insert coloured apple images
    for (var i = 0; i < imgCount; i++) {$('#imgs').append('<div class="' + page + ' fruit"></div>');};
    
    //define row number and cell numbers so that total numbers of click can be confirmed later.
    for (var i = 1; i < rowCount; i++) {
        $('#dropZone').append('<div id="row' + rowNum + '"></div>');
        for (var j = 0; j < colCount; j++) {
            $('#row' + rowNum).append('<div class="hover dropArea cell_' + i + j + '"></div>');
        }
        rowNum++;
    };
    
    $('.dropArea').on('click touchend', function (e) {
        e.preventDefault();
        
        if (page === 'apple') {
            fruitClass = 'banana_bw';
        } else {
            fruitClass = 'apple_bw';
        }
        
        if(!$(this).hasClass('complete')) {
            if($(this).hasClass(fruitClass)) {
                $(this).removeClass(fruitClass);
            } else {
                $(this).addClass(fruitClass);
            }
        }
        $('#popup').css({'visibility':'hidden'});
    });
}

//function to check whether correct images are inserted according to current page.
function checkImages () {
    
    var rowCount, colCount, fruitClass, fruitClassBW;
    
    if (page === 'apple') {
        
        rowCount = 5;
        colCount = 7;
        fruitClass = 'banana';
        fruitClassBW = 'banana_bw';
        
    } else {
        
        rowCount = 6;
        colCount = 7;
        fruitClass = 'apple';
        fruitClassBW = 'apple_bw';
        
    }
    
    for (var i = 1; i < rowCount; i++) {
        var count = 0;
        for (var j = 0; j < colCount; j++) {
            if ($('.cell_' + i + j).hasClass(fruitClassBW)) {
                count++;
                fruitCount[i - 1] = count;
            }
        }
        
        if (count === 5) {
            $('#row'+i+' .' + fruitClassBW).toggleClass(fruitClass + ' ' + fruitClassBW);
            $('#row'+i+' .dropArea').removeClass('hover').addClass('complete');
            completeRow++;
        }
    }
}

//function to check input values.
function checkInput () {
    var firstInput, secondInput, firstCheck, secondCheck, firstFirst, firstSecond, splited;
    
    firstInput = $('#one').val();
    secondInput = $('#two').val();
    
    //assign variables as per page
    if (page === 'apple') {
        
        firstCheck = inputCheck[0][0];
        secondCheck = inputCheck[0][1];
        
    } else {
        
        firstCheck = inputCheck[1][0];
        secondCheck = inputCheck[1][1];
        
    }
    
    //check if first input has two digits
    if (firstInput.length === 2) {
        splited = firstInput.split('');
        firstFirst = splited[0];
        firstSecond = splited[1];
        
        if (firstFirst === '0') {
            splited.shift();
            firstInput = splited[0];
        }
    }
    
    //check if both inputs are correct, must add false for incorrect values.
    //otherwise, it will cause error.
    firstInput === firstCheck ? inputs.first = true : inputs.first = false;
    secondInput === secondCheck ? inputs.second = true : inputs.second = false;
    
    //clear incorrect inputs upon check button click.
    if (!inputs.first) {
        $('#one').val('');
    }
    
    if (!inputs.second) {
        $('#two').val('');
    }
}

//function for clearing things up
function clearEverything () {
    
    btnCtrl();
    completeRow = 0;
    $('input').val('');
    
    inputs.first = inputs.second = false;

    $('.dropArea').addClass('hover');
    $('.complete').removeClass('complete');
    $('#one, #two').removeAttr('disabled');
    $('#popup').css({visibility: 'hidden'});
    
    //clear images inside drop area
    if ($('.fruit').hasClass('apple')) {
        $('.banana_bw, .banana').removeClass('banana_bw banana');
    } else {
        $('.apple_bw, .apple').removeClass('apple_bw apple');
    }
}

//function to control back and next button
function btnCtrl () {
    
    if (page === 'apple') {
        
        backBtnCtrl = nextBtnCtrl = false;
        $('#btnBack').hide();
        $('#btnNext').btnEnabled();
        
    } else {
        
        $('#btnBack').show();
        $('#btnBack').btnEnabled();
        $('#btnNext').btnDisabled();
        backBtnCtrl = true; nextBtnCtrl = false;
    }
    
    completeRow = 0;
    $('input').attr('maxlength', '2');
    $('#popup').css({visibility: 'hidden'});
}

//function for page change
function pageChange (page) {
    
    //reset contents in the IDs
    $('#imgs, #dropZone').html('');
    if (page === 'apple') {        
        $('#instruction').find('span').html(instructionTXT[0]);     //change instruction text
        divineCreation(page, 1, 4, 5, 7);                           //create page layout
        $('#btnNext').find('span').html('Next');                    //update button text
        $('#inputArea').html(fillTXT[0]);                           //update text in inputArea
    } else {        
        $('#instruction').find('span').html(instructionTXT[1]);
        divineCreation(page, 1, 5, 6, 7);
        $('#btnNext').find('span').html('Reset');
        $('#inputArea').html(fillTXT[1]);        
    }
    
    $('#dropZone').toggleClass('appleTab bananaTab');   //Toggle drop cell backgrounds
    $('#one, #two').removeAttr('disabled');             //Enable inputs
    $('input').val('');                                 //Reset values in inputs
    $('#one, #two').on('input', charLimit);             //re-set the input to number only.
    
    //to hide popup box when clicking on input boxes.
    $('#one, #two').on('click touchend', function (){
        $('#popup').css({'visibility':'hidden'});
    });    
}