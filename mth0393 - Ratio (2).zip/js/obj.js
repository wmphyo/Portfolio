//for image preload
var imgs = [
    'assets/images/apple.png',
    'assets/images/apple_col.png',
    'assets/images/banana.png',
    'assets/images/banana_col.png',
];

var length = imgs.length;
var img = new Image();

for (var i = 0; i < length; i++) {
    img.src = imgs[i];
};

var completeRow = 0;
var backBtnCtrl = nextBtnCtrl = false;

//useragents for mobile devices.
var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
var isDroid = /Android/i.test(navigator.userAgent);

//instruction texts
var instructionTXT = [
    'Select the squares to show a ratio of 1 apple to 5 bananas.',
    'Select the squares to show a ratio of 1 banana to 5 apples.'
];

//input texts
var fillTXT = [
    'The ratio of apples to bananas shown is <input id="one"> to <input id="two"> .',
    'The ratio of bananas to apples shown is <input id="one"> to <input id="two"> .'
];

//to store fruit counts
var fruitCount = [
    ['1', ''],
    ['2', ''],
    ['3', ''],
    ['4', ''],
    ['5', '']
];

/*Function to set input - number only*/
function charLimit() {
        var position = this.selectionStart;
        var start = $('input').val().length;
        this.value = this.value.replace(/[^0-9]+/g, '');
        var final = $('input').val().length;
	
		/*Codes that keep cursor position as it is instead of moving to the end of input*/
        if (start == final) {
            this.selectionEnd = position;
        } else {
            this.selectionEnd = position - 1;
    	}
};

//for popup messages 
var msg = {
    incompleteA:'Complete the ratio for all the apples.',
    incompleteB:'Complete the ratio for all the bananas.',
    completeA:'There are 4 apples. <br/><br/>Count the bananas and write the total in the ratio.',
    completeB:'There are 5 bananas. <br/><br/>Count the apples and write the total in the ratio.',
    correctA:'Correct! Select <strong>next</strong> to try another ratio.',
    correctB:'Correct! You are roaring ahead in ratios. <strong>Reset</strong> to repeat the activity.'
};

//array to verify inputs
var inputCheck = [
    ['4', '20'],
    ['5', '25']
];

//input verification to be used inside check button click.
var inputs = {
    first: false,
    second: false
};

var page = 'apple';

var nxtBtnMsg;

//for button control
$.fn.extend({
    
    btnDisabled: function() {
        $(this).addClass('disable');
        $(this).removeClass('hover');
    },
    
    btnEnabled: function() {
        $(this).removeClass('disable');
        $(this).addClass('hover');
    }
});