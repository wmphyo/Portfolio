/* Template JS */
/* The State of Queensland (Department of Education and Training) */
//to control the buttons with true or false.

//jQuery - Run on page ready
$(function() {
    
    //for mobile devices
    if (isDroid || isApple) {
        if (isDroid) {       //specific text placement for Android
            $('#playbtn, #backbtn, #nextbtn').addClass('droid');
        } else {            //specific text placement for iPad
            $('#playbtn, #backbtn, #nextbtn').addClass('iOS');
            //window.alert();
        }
    } else {
        //add hover for desktops
        $('#audiobtn, #nextbtn, #playbtn, #backbtn').addClass('hover');
    }
    
    //pink screen
    //$('#frame').addClass('loadScreen').removeClass('bg');
    $('#playbtn, #nextbtn, #animation_container').css('visibility','hidden');
    //button for first interaction
    $('#frame').append('<div id="beginbtn" class="btn play"></div>');
    $('#beginbtn').addClass('hover');
    
    //add originial elements when first button is clicked.
    $('#beginbtn').on('click touchend', function() {
        playAnime = true; 
        $('#playbtn').playIt();
        $(this).css('visibility','hidden');
        $('#frame').addClass('bg').removeClass('loadScreen');
        $('#pg_num, #playbtn, #nextbtn, #animation_container').css('visibility','visible');
    });      
    
    //default states
    $('#backbtn, #pg_num').css({'visibility':'hidden'});

    $('#playbtn').on('click touchend', function(e) {
        e.preventDefault();        
        if(playAnime) {
            playAnime = false;
            $(this).pauseIt();            
        } else {
            playAnime = true;
            $(this).playIt();
        }
    });

    $('#backbtn, #nextbtn').on('click touchend', function(e) {
        
        e.preventDefault();
        clickedBTN = e.currentTarget.id;
        $('#pg_num').show();
        
        clickedBTN === 'nextbtn' ? clickCount++ : clickCount--;        
        clickCount > 1 ? $('#backbtn').css({'visibility':'visible'}) : $('#backbtn').css({'visibility':'hidden'});
        clickCount < 6 ? $('#nextbtn').css({'visibility':'visible'}) : $('#nextbtn').css({'visibililty':'hidden'});
        $('#pg_num').html(clickCount + '/6');
    });
});
