var INITIAL_POSITION = {
	girl: {
		left: '120px',
		top: '200px'
	},
	boy: {
		left: '250px',
		top: '200px'
	},
	tallTree: {
		left: '310px',
		top: '210px'
	},
	wideTree: {
		left: '290px',
		top: '0px'
	},
	smallTree: {
		left: '440px',
		top: '8px'
	},
	bird: {
		left: '340px',
		top: '150px'
	},
	dog: {
		left: '430px',
		top: '110px'
	},
	car: {
		left: '15px',
		top: '250px'
	},
	hat: {
		left: '250px',
		top: '195px'
	}
};



$(document).ready(function() {
	var PositionalWords = ["near", "nearest", "further", "between", "next to"];
	var i = 0;
	initiate();
	/*Function called when Back button is clicked*/
	$('#backBtn').click(function() {
		$('#scrollingText').removeClass("animatingClass");
		$("#scrollingText").css("left", "-20px");
		i = 0;
		$("#scrollingText").text(PositionalWords[i]);
		$("#scrollingText").show();
		$('#scrollingText').addClass("animatingClass");
		$("#scrollingText").css("animation-play-state", "running");
		setImages();
		
		$("#introMessage").show();
		$("#instructions").hide();
		$("#instructions").html("Place the girl <b>near</b> the house.");
		
        $(".borderC").removeClass().addClass('makedrag borderC');
		$(".borderC,#resetBtn,#backBtn,#instructions").addClass('hiddenC');
		$('#nextBtn').show();
	});
	
	/*Function called when Next button is clicked*/
	$('#nextBtn').click(function() {
		$("#scrollingText").css("animation-play-state", "paused");
		$("#scrollingText").hide();
		$("#introMessage").hide();
		$("#instructions").show();
		$('#girl').addClass('nowDroppableinTop ');
		$("#instructions").html("Place the girl <b>near</b> the house.");
		$(".borderC,#resetBtn,#backBtn,#instructions").removeClass('hiddenC');
		$('#nextBtn').hide();
	});
	/*To change the text after near, nearest.... */
	var scrolT = document.querySelector("#scrollingText");
	scrolT.addEventListener("animationiteration", function() {
		i++;
		$("#scrollingText").text(PositionalWords[i]);
		if (i == 4) i = -1;
	}, false);
	/*Function called when Reset Button is clicked*/
	$('#resetBtn').click(function() {
		$(".borderC").removeClass();
		setImages();
		$("#instructions").show();
	
	
	});
	/*Function making all the images draggable*/
	$(".makeDrag").draggable({
		cursor: "pointer",
		containment: "#bgImage",
		revertDuration: 0,
		revert: "invalid",
		
		start: function() {
			  $(this).draggable("option", "cursorAt", {
            left: Math.floor(this.clientWidth / 2),
            top: Math.floor(this.clientHeight / 2)
        }); 
$(this).css("z-index", 10);
		},
		
		
		
		stop: function() {
			$(this).css("z-index", 0);
		}
	});
	/*Droppable div for girl,talltree*/
	$("#topDroppableParentDiv").droppable({
		accept: ".nowDroppableinTop",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});
	/*Droppable div for boy,widetree*/
	$("#bottomDroppableParentDiv").droppable({
		accept: ".nowDroppableinBottom",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});
	/*Droppable div for smalltree*/
	$("#middleDroppableParentDiv1,#middleDroppableParentDiv2,#middleDroppableParentDiv3").droppable({
		accept: ".nowDroppableinMiddle",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});
	/*Droppable div for bird*/
	$("#dropTallTree").droppable({
		accept: ".nowDroppableinTree",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});
	/*Droppable div for dog*/
	$("#middleDroppableBetweenChildrenDiv1,#middleDroppableBetweenChildrenDiv2,#middleDroppableBetweenChildrenDiv3").droppable({
		accept: ".nowDroppableinBetweenChildren",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});
	/*Droppable div for car*/
	$("#nextToHouseDiv").droppable({
		accept: ".nowDroppableNextHouse",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});
	/*Droppable div for hat*/
	$("#girlHeadDiv").droppable({
		accept: ".nowDroppableonGirlHead",
		drop: function(event, ui) {
			positionDropped(ui.draggable.attr('id'));
		}
	});

	/*Set the images in  the position once dropped and lock*/
	function positionDropped(myId) {
		$('#' + myId).css({
			"position": "absolute"
		});
		switch (myId) {
			case 'girl':
				$('#girl').css({
					"left": "165px",
					"top": "84px"
				});
				$("#instructions").html("Place the boy <b>near</b> the church.");
				$('#boy').addClass('nowDroppableinBottom');
				break;
			case 'boy':
				$('#boy').css({
					"left": "430px",
					"top": "295px"
				});
				$("#instructions").html("Place the tall tree <b>near</b> the house.");
				$('#tallTree').addClass('nowDroppableinTop');
				break;
			case 'tallTree':
				$('#tallTree').css({
					"left": "10px",
					"top": "0px"
				});
				$("#instructions").html("Place the wide tree <b> near </b> the church.");
				$('#wideTree').addClass('nowDroppableinBottom');
				break;
			case 'wideTree':
				$('#wideTree').css({
					"left": "310px",
					"top": "280px"
				});
				$("#instructions").html("Place the smallest tree <b>between</b> the house and the church.");
				$('#smallTree').addClass('nowDroppableinMiddle');
				break;
			case 'smallTree':
				$('#smallTree').css({
					"left": "189px",
					"top": "200px"
				});
				$("#instructions").html("Place the the bird in the tree <b>nearest</b> the house.");
				$('#bird').addClass('nowDroppableinTree');
				break;
			case 'bird':
				$('#bird').css({
					"left": "10px",
					"top": "35px"
				});
				$("#instructions").html("Place the dog <b>between</b> the children.");
				$('#dog').addClass('nowDroppableinBetweenChildren');
				break;
			case 'dog':
				$('#dog').css({
					"left": "256px",
					"top": "224px"
				});
				$("#instructions").html("Place the car <b>next to</b> the house.");
				$('#car').addClass('nowDroppableNextHouse');
				break;
			case 'car':
				$('#car').css({
					"left": "203px",
					"top": "98px"
				});
				$("#instructions").html("Place a hat on the person who is <b>further</b> from the church.");
				$('#hat').addClass('nowDroppableonGirlHead');
				break;
			case 'hat':
				$('#hat').css({
					"left": "166px",
					"top": "77px"
				});
				
				$("#instructions").hide();
		    	$("#goodWork").show();
				break;
			default:
		}
		$('#' + myId).removeClass().addClass('unselectable noPointerEvents');
	}

	/*Set the images to the initial position*/
	function setImages() {
		$("#goodWork").hide();
		$('img').removeClass('unselectable noPointerEvents makeDrag').addClass('makeDrag borderC');
		
		$('#girl').addClass('nowDroppableinTop ');
		$("#instructions").html("Place the girl <b>near</b> the house.");
		$('#girl').css({
			'top': INITIAL_POSITION.girl.top,
			'left': INITIAL_POSITION.girl.left
		});
		$('#boy').css({
			'top': INITIAL_POSITION.boy.top,
			'left': INITIAL_POSITION.boy.left
		});
		$('#tallTree').css({
			'top': INITIAL_POSITION.tallTree.top,
			'left': INITIAL_POSITION.tallTree.left
		});
		$('#wideTree').css({
			'top': INITIAL_POSITION.wideTree.top,
			'left': INITIAL_POSITION.wideTree.left
		});
		$('#smallTree').css({
			'top': INITIAL_POSITION.smallTree.top,
			'left': INITIAL_POSITION.smallTree.left
		});
		$('#bird').css({
			'top': INITIAL_POSITION.bird.top,
			'left': INITIAL_POSITION.bird.left
		});
		$('#dog').css({
			'top': INITIAL_POSITION.dog.top,
			'left': INITIAL_POSITION.dog.left
		});
		$('#car').css({
			'top': INITIAL_POSITION.car.top,
			'left': INITIAL_POSITION.car.left
		});
		$('#hat').css({
			'top': INITIAL_POSITION.hat.top,
			'left': INITIAL_POSITION.hat.left
		});
	}

	function initiate() {
		preloader() ;		
		if ('ontouchstart' in window || navigator.msMaxTouchPoints || 'ontouchstart' in document.documentElement || typeof window.orientation !== 'undefined') {} else $('#resetBtn,#backBtn,#nextBtn').addClass('hover');
		$('#bgImage').prepend($('<div id="introMessage" class="messageBox"><p class="message"> - Read the words as they appear <br/> - Select next to continue</p></div><div id="instructions" class="messageBox hiddenC"> </div> <div id="goodWork" class="messageBox hiddenC">Good Work. Reset to do the activity again. </div>'));
		$('#wideTree,#smallTree,#tallTree,#car,#girl,#hat,#boy,#bird,#dog').addClass('borderC');
		$('.borderC,#resetBtn,#backBtn').addClass('hiddenC');
		$("#scrollingText").text(PositionalWords[i]);
		setImages();
	}
	
	
	function preloader() 

{

     var i = 0;
     imageObj = new Image();

     images = new Array();
    var images = ['./assets/images/back_h.png','./assets/images/next_h.png','./assets/images/reset_h.png'];


     // start preloading
     for(i=0; i<=2; i++) 
     {
          imageObj.src=images[i];
     }


} 
	
	
	
	
});