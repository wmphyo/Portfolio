/* The State of Queensland (Department of Education and Training).*/

var slide_num = 1;
var pos_value = 0;
var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
var isDroid = /Android/i.test(navigator.userAgent);

//jQuery - Run on page ready.
$(document).ready(function (){	
	//Default interface design on load.
	
	btnOnAction();	 	//Call function for slide number panel.
	btnAction();		//Call function for for and bac btns.
    
});

/*Hold button actions on slide numbers
Call display function and pass slide number variable.*/
function btnOnAction(){
 
	//remove hover effect on mobile devices.
	if (isApple || isDroid){
		$('.hover').removeClass('hover');	
	} else {
		 //add hover effects to slide numbers
    	$('.ctrlID').addClass('hover');	
    	//remove hover effect from element with active class
    	$('.active').removeClass('hover');	
	}
    
	//Add off actions to prevent calling same panel number twice
	$('#one').on('click touchend', function(){
		if (slide_num === 1) {
			$(this).off('click touchend');
		} else {
			display(1);	
		}
	});
	
	$('#two').on('click touchend', function(){
		if (slide_num === 2){
			$(this).off('click touchend');
		} else {
			display(2);	
		}
	});

	$('#three').on('click touchend', function(){
		if (slide_num === 3){
			$(this).off('click touchend');
		} else {
			display(3);
		}
	});
	
	$('#four').on('click touchend', function(){
		if (slide_num === 4){
			$(this).off('click touchend');
		} else {
			display(4);
		}
	});
	
	$('#five').on('click touchend', function(){
		if (slide_num === 5){
			$(this).off('click touchend');
		} else {
			display(5);
		}
	});
	
	$('#six').on('click touchend', function(){
		if (slide_num === 6){
			$(this).off('click touchend');
		} else {
			display(6);
		}
	});
}

/*Function to display animated images & texts.*/
function display(val){
	
	//Call panelDesign for bot border design (active or not).
	if (val === 1) {
		
		pos_value = 0;	
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 1;
		
	} else if (val === 2){
		
		pos_value = -734;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 2;
		
	} else if (val === 3){
		
		pos_value = -1468;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 3;
		
	} else if (val === 4){
		
		pos_value = -2202;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 4;
		
	} else if (val === 5){
		
		pos_value = -2936;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 5;
		
	} else {
		
		pos_value = -3670;	
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 6;
		
	}
	
    //Call ctrl function to animation & button designs.
	ctrl();
}

//To animate text display, off button actions and turn them back on.
function ctrl(){
	
    offAction();
    
    //For underline design under slide panel numbers.    
    //Reset all underline on click.
	$('#one, #two, #three, #four, #five, #six ').removeClass('active');
	
	//Add active class accordingly.
	if (slide_num === 1){
		$('#one').addClass('active');	
	} else if (slide_num === 2){
		$('#two').addClass('active');
	} else if (slide_num === 3){
		$('#three').addClass('active');
	} else if (slide_num === 4){
		$('#four').addClass('active');
	} else if (slide_num === 5){
		$('#five').addClass('active');
	} else {
		$('#six').addClass('active');
	}	
    
    //for disable / enable button designs | put them here to show effect before animation
    if (slide_num === 1) {
        $('#btnBacHolder').addClass('btnDisable');
		
    } else {
        $('#btnBacHolder').removeClass('btnDisable');
    }
    
    if (slide_num === 6) {
        $('#btnForHolder').addClass('btnDisable');
		
    } else {
        $('#btnForHolder').removeClass('btnDisable');
    }
    
	$('#btnBacHolder, #btnForHolder').css({'width':'65px','cursor':'default'});
	
    //remove hover effect from all events
    $('.ctrlID').removeClass('hover');
    
	//This one turns back on actions from all buttons.
	setTimeout(btnOnAction, 1000);
	setTimeout(btnAction, 1000);
}

//Turn off actions from all buttons for a second while sliding.
function offAction(){
	
	$("#one").off("click touchend");
	$("#two").off("click touchend");
	$("#three").off("click touchend");
	$("#four").off("click touchend");
	$("#five").off("click touchend");
	$("#six").off("click touchend");
	$("#btnFor, #btnForHolder").off("click touchend");
	$("#btnBac, #btnBacHolder").off("click touchend");
	
}

//For forward and backward buttons. 
function btnAction(){
	//Disable forward button on last slide (num 6).
	if(slide_num === 6){
		$('#btnFor, #btnForHolder').off('click touchend');
	} else {
		//works at the end of animation or on load.
		$('#btnForHolder').css({'width':'75px','cursor':'pointer'});
		
		$('#btnFor, #btnForHolder').on('click touchend', function(e){
			e.preventDefault();
			//reduce width on click (interactive button design)
			$('#btnForHolder, #btnBacHolder').css({'width':'65px','cursor':'default'});
			
			//Slide image, display text through ctrl().
			pos_value = pos_value - 734;
			$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
			slide_num++;
			ctrl();	
		});
	}
	
	//Disable backward button on first slide (num 1).
	if(slide_num === 1){
		$('#btnBac, #btnBacHolder').off('click touchend');
	} else {
		//works at the end of animation or on load.
		$('#btnBacHolder').css({'width':'75px','cursor':'pointer'});
		
		$('#btnBac, #btnBacHolder').on('click touchend', function(e){
			e.preventDefault();
			//reduce width on click (interactive button design)
			$('#btnBacHolder, #btnForHolder').css({'width':'65px','cursor':'default'});
			
			//Slide image, display text through ctrl().
			pos_value = pos_value + 734;
			$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
			slide_num--;
			ctrl();
		});
	}
}
