//Number Expander Print JS
//Example Query String: http://127.0.0.1:50115/numberExpanderPrint.html?1#y#h#text#g
//This print page takes the query string generated from the LO and displays it in a print friendly page

//To allow correct print layout, the print page is setup in cm not px
//For each expand item the query string is formatted like this:
//<number to display>#<colourLetter>#<hide/show text>#<text to display>#<colourLetter>
//First item starts with ? for query string, all the rest start with &
//B is inserted if there is no number (blank!)

function init() {
    var queryString = window.location.href.split("?");
    var params = queryString[1].split("&");
    
    switch (params.length) {
            case 6:
                $('#container6').css('display','block');
            break;
            
            case 5:
                $('#container5').css('display','block');
            break;
         
            case 4:
                $('#container4').css('display','block');
            break;
         
            case 3:
                $('#container3').css('display','block');
            break;
         
            case 2:
                $('#container2').css('display','block');
            break;
         
            case 1:
                $('#container1').css('display','block');
            break;
    }
    
    for (var i=0;i<params.length;i++){
        
        var contNum = params.length;
        var values = params[i].split('#');

        if (values[0] === 'b') {
            $('#container'+contNum+' #item'+(i+1)+' h2').html('');
        } else {
            $('#container'+contNum+' #item'+(i+1)+' h2').html(values[0]);
        }

        $('#container'+contNum+' #item'+(i+1)+' .inputCont img').attr('src','../images/'+values[1]+'.png');
        
        $('#container'+contNum+' #item'+(i+1)+' h1').html(values[3]);
        $('#container'+contNum+' #item'+(i+1)+' .numtext img').attr('src','../images/'+values[4]+'.png');
        
        if (values[2] === "h") {
            $('#container'+contNum+' #item'+(i+1)+' .numtext').css('display','none');
        }
        
        if (values[5] === "y") {
            $('#container'+contNum+' #item'+(i+1)+' .inputCont').append('<span class="decimalPoint"><img src="../images/d.png" /></span>');
        }
    }
    
    window.print();
    window.onfocus = function() {window.close();};
}