//Number Expander JS
var closeClick = 0;
var openClick = 0;

var isMobile = /iPad|iPhone|iPod|Android/i.test(navigator.userAgent);

$(function() {
    
    //to prevent (ghost) images from being dragged
    $('.expBut').attr('draggable', false);
    
    changeSelects();
	$('input').on('input', charLimit);
	
    /*$('input').val('');
    $('input').keypress(function(e) {
        if (e.charCode<48 || e.charCode>57) {
            e.preventDefault();
        }
    });*/
    
    $('.expBut').on('click touchend',function() {toggleText($(this).data('id'));});
    $('.numtext').on('click touchend',function() {toggleText($(this).data('id'));});
    
    $('#printBut').on('click touchend',function(e) {e.preventDefault();printPage();});
    
    $('#wholeNumbersSelect').on('change',function() {changeSelects();});
    $('#decimalFractionSelect').on('change',function() {changeSelects();});
    
    $('#closeNumberExpand').on('click touchend',function() {
        //to prevent events from queing up upon button spamming.
       if($('#closeNumberExpand').data('state') !== 'off'){
           closeAllText();
       }
    });
    
    $('#openNumberExpand').on('click touchend',function() {
        //to prevent events from queing up upon button spamming.
        if($('#openNumberExpand').data('state') !== 'off'){
            openAllText();
        }
    });
     
    $('#resetBut').on('click',function() {$('input').val('');openAllText();});
    
    if (isMobile) {$('.btns').removeClass('hover').addClass('mobile');}
});

function toggleText(theID) {

    var theText = $('#item' + theID + ' span.numtext');
    var theButton = $('#item' + theID + ' img.expBut');
 
    if (theText.data('state') === 'close') {

        theText.show('blind', {duration: 400, direction: 'horizontal'});
        theButton.removeClass('expButClose');
        
        //to prevent events from queing up
        setTimeout(function(){
            theText.data('state','open');
            $('#closeNumberExpand').data('state', 'on');
        }, 250);
        
    } else {

        theText.hide('blind', {duration: 400, direction: 'horizontal'});
        theButton.addClass('expButClose');
        
        //to prevent events from queing up
        setTimeout(function(){
            theText.data('state','close');
            $('#openNumberExpand').data('state', 'on');
        }, 250);
    }
    //to prevent decimal showing incorrectly issue.
    setTimeout(showHideDecimalPoint, 300);
}

function showHideDecimalPoint() {
    
    var decShowing = $('.decimal').is(':visible');
    var closeNum = 0;
    var count = 0;
    
    $('span.numtext:visible').each(function() {
        count++;
        if ($(this).data('state') === 'close') {
            closeNum++;
        }
    });
    
    var decPoint = $('.decimalPoint');
        
    if (closeNum === count && decShowing === true) {
        decPoint.show('fade');
    } else {
        decPoint.hide('fade');
    }
}

function changeSelects() {
    $('#closeNumberExpand').data('state', 'on');
    
    var wholeNum = $('#wholeNumbersSelect').val();
    var fractionNum = $('#decimalFractionSelect').val();
    $('span.inputCont input').val('');
    
    //Hide all
    $('.items').hide();
    $('#content').attr('class','');
    $('.decimalPoint').hide();
    
    $('span.numtext').show();
    $('span.numtext').data('state','open');
    
    //clear input boxes
    $('input').val('');
    
    //Show the Whole Numbers
    switch (wholeNum)
    {
        case 'Thousands':
            $('#item1').show();

        case 'Hundreds':
            $('#item2').show();

        case 'Tens':
            $('#item3').show();

        case 'Ones':
            $('#item4').show();

        break;

    }

    //Show the Fraction
    switch (fractionNum)
    {
            case 'None':
                $('#item4').show();
            break;
    
            case 'Hundredths':
                $('#item6').show();

            case 'Tenths':
                $('#item5').show();
            
            break;
    }
    
    var count = $('.items').not(':hidden').length;

    $('#content').addClass('v'+count);
    
    $('.expBut').removeClass('expButClose');    
}

function closeAllText() {  
    $('#closeNumberExpand').data('state', 'off');
    
    $('.items:visible span.numtext').each(function() {
        $(this).hide('blind', {duration: 400, direction: 'horizontal'});
        $(this).data('state','close');
    });
    
    
    showHideDecimalPoint();
    
    $('.expBut').addClass('expButClose');
    
    //turn open number back on
    setTimeout(function() {
        $('#openNumberExpand').data('state', 'on');
    }, 450);
}

function openAllText() {
    $('#openNumberExpand').data('state', 'off');
    
    $('.items:visible span.numtext').each(function() {
        $(this).show('blind', {duration: 400, direction: 'horizontal'});
        $(this).data('state','open');
    });

    showHideDecimalPoint();
    
    $('.expBut').removeClass('expButClose');
    
    //turn close number back on
    setTimeout(function() {
        $('#closeNumberExpand').data('state', 'on');
    }, 450);
}

function printPage() {
    
    //To allow correct print layout, the print page is setup in cm not px
    //This function reads the current values and then appends them to the href
    //The print page then reads the query string and rebuild in the print friendly page
    //For each expand item the query string is formatted like this:
    //<number to display>#<colourLetter>#<hide/show text>#<text to display>#<colourLetter>
    //First item starts with ? for query string, all the rest start with &
    //B is inserted if there is no number (blank!)
    
    var itemString = '?';
    
    //For each item that is visible
    $('.items:visible').each(function() {

        //Add the number that is in the input or the letter b
        if (isNaN(parseInt($('#'+this.id+' input').val()))) {
            itemString += 'b'
        } else {
            itemString += $('#'+this.id+' input').val();
        }

        //If the text has been closed, set the string with the hide flag else the show flag
        if ($('#'+this.id+' span.numtext') .data('state') === "close") {

            //set the correct colour
            if (this.id === "item5" || this.id == "item6") {
                itemString += '#g#h#';
            } else {
                itemString += '#y#h#';
            }

        } else {
            
            //set the correct colour
            if (this.id === "item5" || this.id == "item6") {
                itemString += '#g#s#';
            } else {
                itemString += '#y#s#';
            }
        }

        //add the text from the field
        itemString += $('#'+this.id+' h1').html();

        if (this.id === "item5" || this.id === "item6") {
            itemString += '#b';
        } else {
            itemString += '#p';
        }
         
        //Add the decimal flag if needed
        if (this.id === "item4" && $('.decimalPoint').is(':visible') === true) {
            itemString += '#y&';
        } else {
            itemString += '#n&';
        }
    });
    
    //remove the last string
    itemString = itemString.slice(0,itemString.length-1);
    
    //open new window
    window.open('assets/print/numberExpanderPrint.html'+itemString);
    //window.print();
}

function charLimit() {
        var position = this.selectionStart;
        var start = $('input').val().length;
        this.value = this.value.replace(/[^0-9]+/g, '');
        var final = $('input').val().length;
	
		/*Codes that keep cursor position as it is instead of moving to the end of input*/
        if (start == final) {
            this.selectionEnd = position;
        } else {
            this.selectionEnd = position - 1;
    	}
}
