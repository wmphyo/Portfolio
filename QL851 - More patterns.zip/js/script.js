/* The State of Queensland (Department of Education and Training).*/
var slide_num = 1;
var pos_value = 0;
var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
var isDroid = /Android/i.test(navigator.userAgent);

//jQuery - Run on page ready.
$(document).ready(function (){	
	
    //Remove hover effect for mobile devices
	if (isApple || isDroid){
		$('.hover').removeClass('hover');
    }
    
   
    //Default interface design on load.
	//Disable btn bac, display txt 1, add slide num 1 cell border (bottom).
    $('#one').addClass('active');
	$('#btnBacHolder').addClass('btnDisable');

	btnOnAction();		//Call function for slide number panel.
	btnAction();		//Call function for forward and back btns.
});

//Hold button actions on slide numbers. Call display function and pass slide number variable.
function btnOnAction(){

	//add hover effects after animation.
    if(!isApple || !isDroid){ 
		
		//add hover classes back onload.
		$('#btnBac, #btnBacHolder, #btnFor, #btnForHolder').addClass('hover');
		$('.ctrlID').addClass('hover');
		if($('.ctrlID').hasClass('active')){
			$('.active').removeClass('hover');
		}
		
		$('.ctrlID').find('span').css({'cursor': 'pointer'});
		
		//check condition for hovers. 
        $('#one, #two, #three, #four, #five, #six, #seven, #eight, #nine, #ten').mouseover(function(){
            //prevent adding hover effect to active slide number
			if($(this).hasClass('active')) {
                $(this).removeClass('hover'); 
            } else {
                $(this).addClass('hover');
            }            
        }).mouseout(function(){
            $(this).removeClass('hover');
        });
		
        $('#btnBac, #btnBacHolder, #btnFor, #btnForHolder').hover(function(){
            $(this).addClass('hover');
            
			//prevent adding hover effect to disabled buttons.
            if($('#btnBacHolder').hasClass('btnDisable')){
                $('#btnBac, #btnBacHolder').removeClass('hover');
            }
            
            if($('#btnForHolder').hasClass('btnDisable')){
                $('#btnFor, #btnForHolder').removeClass('hover');
            }
        }, function(){
            $(this).removeClass('hover');
        });
		
    }
    
	//Add off actions to prevent calling same panel number twice
	$('#one').on('click touchend', function(){
		if (slide_num === 1) {
			$(this).off('click touchend');
		} else {
			display(1);	
		}
	});
	
	$('#two').on('click touchend', function(){
		if (slide_num === 2){
			$(this).off('click touchend');
		} else {
			display(2);	
		}
	});

	$('#three').on('click touchend', function(){
		if (slide_num === 3){
			$(this).off('click touchend');
		} else {
			display(3);
		}
	});
	
	$('#four').on('click touchend', function(){
		if (slide_num === 4){
			$(this).off('click touchend');
		} else {
			display(4);
		}
	});
	
	$('#five').on('click touchend', function(){
		if (slide_num === 5){
			$(this).off('click touchend');
		} else {
			display(5);
		}
	});
	
	$('#six').on('click touchend', function(){
		if (slide_num === 6){
			$(this).off('click touchend');
		} else {
			display(6);
		}
	});
	
	$('#seven').on('click touchend', function(){
		if (slide_num === 7){
			$(this).off('click touchend');
		} else {
			display(7);
		}
	});
	
	$('#eight').on('click touchend', function(){
		if (slide_num === 8){
			$(this).off('click touchend');
		} else {
			display(8);
		}
	});
	
	$('#nine').on('click touchend', function(){
		if (slide_num === 9){
			$(this).off('click touchend');
		} else {
			display(9);
		}
	});
	
	$('#ten').on('click touchend', function(){
		if (slide_num === 10){
			$(this).off('click touchend');
		} else {
			display(10);
		}
	});
}

//Turn off actions from all buttons for a second while sliding.
function offAction(){
	$("#one").off("click touchend");
	$("#two").off("click touchend");
	$("#three").off("click touchend");
	$("#four").off("click touchend");
	$("#five").off("click touchend");
	$("#six").off("click touchend");
	$("#seven").off("click touchend");
	$("#eight").off("click touchend");
	$("#nine").off("click touchend");
	$("#ten").off("click touchend");
	$("#btnFor, #btnForHolder").off("click touchend");
	$("#btnBac, #btnBacHolder").off("click touchend");
}

/*Function to display animated images & texts.*/
function display(val){
       
    //Display slide images as per slide number
	if (val === 1) {
		
		pos_value = 0;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 1;
		
	} else if (val === 2){
		
		pos_value = -734;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 2;
		
	} else if (val === 3){
		
		pos_value = -1468;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 3;
		
	} else if (val === 4){
		
		pos_value = -2202;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 4;
		
	} else if (val === 5){
		
		pos_value = -2936;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 5;
		
	} else if (val === 6){
		
		pos_value = -3670;	
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 6;
		
	} else if (val === 7){
		
		pos_value = -4404;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 7;
		
	} else if (val === 8){
		
		pos_value = -5138;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 8;
		
	} else if (val === 9){
		
		pos_value = -5872;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 9;
		
	} else {
		
		pos_value = -6606;
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 10;
		
	}
    	
	//Call ctrl function to animation & button designs.
	ctrl();	
}

//To animate text display, off button actions and turn them back on.
function ctrl(){
	
	//disable hover effects from the buttons
    //added removeClass hover to remove hover effect on click 
    //(otherwise, it sticks on click until hover again)
	
	
	$('#one, #two, #three, #four, #five, #six, #seven, #eight, #nine, #ten').removeClass('hover').unbind('mouseover mouseout');
	$('#btnBac, #btnFor, #btnBacHolder, #btnForHolder').removeClass('hover').unbind('mouseenter mouseleave');
	//$('.ctrlID').find('span').css({'cursor': 'default'});
	
    offAction();
	
    //Condition check for back & for buttons
    //everything not 1.
	if(slide_num !== 1){
		
		$('#btnBacHolder').removeClass('btnDisable');
		
		//everything not 1 but 7.
		if(slide_num === 10){	
			$('#btnForHolder').addClass('btnDisable');
		}
	}
	
	//everything not 7.
	if (slide_num !== 10){		
		$('#btnForHolder').removeClass('btnDisable');
        
		//everything not 7 but 1.
		if (slide_num === 1){
			$('#btnBacHolder').addClass('btnDisable');
		}
	}
    
    //Design for slide numbers
    //Reset all underline on call.
	$('#one, #two, #three, #four, #five, #six, #seven, #eight, #nine, #ten').removeClass('active');    
    
	//Add underline border to slide numbers accordingly.
	if (slide_num === 1){
		$('#one').addClass('active');
	} else if (slide_num === 2){
		$('#two').addClass('active');
	} else if (slide_num === 3){
		$('#three').addClass('active');
	} else if (slide_num === 4){
		$('#four').addClass('active');
	} else if (slide_num === 5){
		$('#five').addClass('active');
	} else if (slide_num === 6){
		$('#six').addClass('active');
	} else if (slide_num === 7){
		$('#seven').addClass('active');
	} else if (slide_num === 8){
		$('#eight').addClass('active');
	} else if (slide_num === 9){
		$('#nine').addClass('active');
	} else {
		$('#ten').addClass('active');
	}
    
	//This one turns back on actions from all buttons.
	setTimeout(btnOnAction, 1000);
	setTimeout(btnAction, 1000);
}

//For forward and backward buttons. 
function btnAction(){
	
	$('#btnFor, #btnForHolder').on('click touchend', function(e){
		e.preventDefault();
		//Disable forward button on last slide (num 7).
		if (slide_num === 10){
			$('#btnFor, #btnForHolder').off('click touchend');
		} else {
            //Slide image, display text through ctrl()
            pos_value = pos_value - 734;
            $('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
            slide_num++;
            ctrl();
        }
    });
	
	$('#btnBac, #btnBacHolder').on('click touchend', function(e){
		e.preventDefault();
        
		//Disable backward button on first slide (num 1).
		if (slide_num === 1){
			$('#btnBac, #btnBacHolder').off('click touchend');
		} else {
			//Slide image, display text through ctrl(), add bot border through panelDesign(val).
			pos_value = pos_value + 734;
			$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
			slide_num--;
			ctrl();
		}
	});
}
