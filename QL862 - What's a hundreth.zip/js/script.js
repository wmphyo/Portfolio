/* Template JS */
/* The State of Queensland (Department of Education and Training) */

var pos_value = 0; 		
var value;
var slide_num = 1;			/*Display image 1 on load*/
var isApple = /iPad|iPhone|iPod/i.test(navigator.userAgent);
var isMobile = /Android/i.test(navigator.userAgent);

/*Array for texts*/
var display_txt = [
	"This is a metre ruler. It shows one metre or 1 m.",
	"The metre ruler has been divided into 100 sections.",
	"This line shows one-hundredth of the metre ruler.",
	"This square has been divided into 100 sections. Each section is one-hundredth of the whole square.",
	"I have coloured 25 sections. This is 25-hundredths or 25/100.",
	"This is a pile of 100 counters. Each counter is one-hundredth of the whole pile.",
	"I have taken 42 counters to use. That's 42-hundredths or 42/100. How many hundredths are left in the pile?"
	];
	
/*To run these codes on load. one off use.*/
$(document).ready(function(){
	
    /*onclick for slide number panel*/
	slide_panel_num();
	$("#slide1").css({"color": "black","background-color": "rgba(255,150,50,0.6)"});
	displayTxt(1);
    
	/*Function on click on Backward and Forward buttons*/
	btnAction(); 
	btnCtrl();    
});

/*Function to display texts above images*/
function displayTxt(value){
	var val = value - 1;
	$("#txt_display").find('span').html(display_txt[val]).fadeIn(250);
}

/*For individual click on number underneath display panel*/
function slide_panel_num(){
   //add hover effect to slide numbers after animation
    if(isMobile || isApple){
        $('#btnBac, #btnFor').removeClass('clicked');
    } else {
        
        $('.slide_num').addClass('hover');
        $('#btnBac, #btnFor').addClass('hover').removeClass('clicked');

        if ($('#btnBac').hasClass('disable')){
            $('#btnBac').removeClass('hover');
        }
                           
        if ($('#btnFor').hasClass('disable')){
            $('#btnFor').removeClass('hover');
        }
    }
                         
                           
    //remove hover effect from active slide number
    $('#slide' + slide_num).removeClass('hover');
               
	/*Added off function to improve the overall efficiency. Otherwise, 
    //it runs all codes for the identical slide number click*/
	if (slide_num === 1){
		$("#slide1").off("click touchend");
	} else {
		$("#slide1").on("click touchend", function(e){
            e.preventDefault();
			slide_num = 1;
			resetVal(slide_num);            
		});	
	}
	
	if (slide_num === 2){
		$("#slide2").off("click touchend");
	} else {
		$("#slide2").on("click touchend", function(e){
            e.preventDefault();
			slide_num = 2;
			resetVal(slide_num);
		});
	}
		
	if (slide_num === 3){
		$("#slide3").off("click touchend");
	} else {
		$("#slide3").on("click touchend", function(e){
            e.preventDefault();
			slide_num = 3;
			resetVal(slide_num);
		});		
	}

	if(slide_num === 4){
		$("#slide4").off("click touchend");
	} else {
		$("#slide4").on("click touchend", function(){
			slide_num = 4;
			resetVal(slide_num);
		});	
	}
	
	if(slide_num === 5){
		$("#slide5").off("click touchend");
	} else {
		$("#slide5").on("click touchend", function(e){
            e.preventDefault();
			slide_num = 5;		
			resetVal(slide_num);
            $(this).removeClass('hover');
		});	
	}
	
	if(slide_num === 6){
		$("#slide6").off("click touchend");
	} else {
		$("#slide6").on("click touchend", function(e){
            e.preventDefault();
			slide_num = 6;
			resetVal(slide_num);
		});	
	}
	
	if(slide_num === 7){
		$("#slide7").off("click touchend");
	} else{
		$("#slide7").on("click touchend", function(e){
            e.preventDefault();
			slide_num = 7;
			resetVal(slide_num);
		});		 
	}
}

/*To reset values according slidle_panel_num and move display image*/
function resetVal(value){
    var val = value;
	/*call button visibility control function and color function*/
	ctrl();
    
	/*For numbers on the panel underneath display panel | individual click*/
		if(val === 1) {
			pos_value = 0;
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);
		} else if (val === 2) {
			pos_value = -680;
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);	
		} else if (val === 3) {
			pos_value = -1360;
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);
		} else if (val === 4) {
			pos_value = -2040;			
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);
		} else if (val === 5) {
			pos_value = -2720;
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);
		} else if (val === 6) { 						/*value === 6 (slide_num) */
			pos_value = -3400;
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);
		} else {
            pos_value = -4080;
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);
        }
}

/*Function to control visibility of the buttons & colors on slide number*/
function ctrl(){
	
	$("#txt_display").find('span').html('').fadeOut(250);
	
	setTimeout(function(){
		displayTxt(slide_num);
	}, 700);
    
	/*Reset text color to purple and background color to white*/
	$(".slide_num").css({"color": "#000000", "background-color": "rgba(0,0,0,0)"});	
	
    /*These must be separated for button action. 
    Change number color to black and background color to orange-ish accordingly
	These are here to function after 1 sec of disable functioning*/
	if (slide_num === 1) {
		$("#slide1").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});
	} else if (slide_num === 2) {
		$("#slide2").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});
	} else if (slide_num === 3) {
		$("#slide3").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});
	} else if (slide_num === 4) {
		$("#slide4").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});
	} else if (slide_num === 5)  {
		$("#slide5").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});	
	} else if (slide_num === 6) {
		$("#slide6").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});
	} else  {	/*(slide_num === 7)*/
		$("#slide7").css({"color": "black", "background-color": "rgba(255,150,50,0.6)"});
	}	
	
	btnCtrl();
    
    
    //disable hover features on slide numbers and will be enable after 1 second.
	$('.slide_num').removeClass('hover');
    $('#btnBac, #btnFor').removeClass('hover');
    
    //added clicked button designs during animation.
    if(!$('#btnBac').hasClass('disable')){
        $('#btnBac').addClass('clicked');
    }
    
    if(!$('#btnFor').hasClass('disable')){
        $('#btnFor').addClass('clicked');    
    }
    
    
	/*Disable all the buttons and actions to have consistent transition and experience*/
	offAction();
    
    
	/*Set time as 1.1sec (instead of 1sec) to improve the user experience and feel*/
	setTimeout(slide_panel_num, 1100);
	setTimeout(btnAction, 1100);	
}

function btnCtrl(){
	
    //Button click UI/UX for mobile browsers and disable hover effect
    //remove hover effect for mobile devices
	if(isApple || isMobile){
        //remove all hover effect on all buttons / clickables
		$('.slide_num').removeClass('hover');
        $('#btnBac, #btnFor').removeClass('hover');
        
        if(slide_num !== 1){
            $('#btnBac').removeClass('disable');
            if(slide_num === 7){
                $('#btnFor').addClass('disable');
            }
        }
        
        if(slide_num !== 7){
            $('#btnFor').removeClass('disable');
            if(slide_num === 1){
                $('#btnBac').addClass('disable');
            }
        }
        
	} else {
        
        //for backward button
        if(slide_num !== 1){
            $('#btnBac').removeClass('disable').addClass('hover');
    
            
            if (slide_num === 7){
                $('#btnFor').removeClass('hover clicked').addClass('disable');
            }
        }
        
        //for forward button
        if(slide_num !== 7) {
            $('#btnFor').removeClass('disable').addClass('hover');
            
            if (slide_num === 1){
                $('#btnBac').removeClass('hover clicked').addClass('disable');
            }
        }
    }
}

/*Function to disable all button actions for 1.15 secs*/
function offAction(){
	$("#slide1").off("click touchend");
	$("#slide2").off("click touchend");
	$("#slide3").off("click touchend");
	$("#slide4").off("click touchend");
	$("#slide5").off("click touchend");
	$("#slide6").off("click touchend");
	$("#slide7").off("click touchend");
	$("#btnFor").off("click touchend");
	$("#btnBac").off("click touchend");
}

function btnAction(){
	
	$("#btnFor").on("click touchend", function(e){
        //don't think it is necessary here due to the flow of the codes, but just in case.
        e.preventDefault();
        
		if(slide_num === 7){
			$("#btnFor").off("click touchend");
		} else {
            
            pos_value = pos_value - 680;
            
            /*slide to next image*/
            $("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);	
            slide_num++;
            ctrl();	
        }
    });
	
	/*Backward button action*/
	$("#btnBac").on("click touchend", function(e){
        //don't think it is necessary here due to the flow of the codes, but just in case.
        e.preventDefault();
        
		if(slide_num === 1){
			$("#btnBac").off("click touchend");
		} else {

			/*getting ready slide to previous image on click*/
			pos_value = pos_value + 680;

			/*slide to previous image*/
			$("#img_display").animate({backgroundPosition: pos_value + "px"}, 1000);	
			slide_num--;
			ctrl();
		}
	});
}