var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;

function init() {
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");
	var comp=AdobeAn.getComposition("C6330C9194DD924EB4BFC04996A90718");
	var lib=comp.getLibrary();
	handleComplete({},comp);
}

function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	exportRoot = new lib.birdy();
	stage = new lib.Stage(canvas);
	stage.addChild(exportRoot);
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {
		var lastW, lastH, lastS=1;
		window.addEventListener('resize', resizeCanvas);
		resizeCanvas();
		function resizeCanvas() {
			var w = lib.properties.width, h = lib.properties.height;
			var iw = window.innerWidth, ih=window.innerHeight;
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
			if(isResp) {
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
					sRatio = lastS;
				}
				else if(!isScale) {
					if(iw<w || ih<h)
						sRatio = Math.min(xRatio, yRatio);
				}
				else if(scaleType==1) {
					sRatio = Math.min(xRatio, yRatio);
				}
				else if(scaleType==2) {
					sRatio = Math.max(xRatio, yRatio);
				}
			}
			canvas.width = w*pRatio*sRatio;
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;
			stage.scaleY = pRatio*sRatio;
			lastW = iw; lastH = ih; lastS = sRatio;
		}
	}
	makeResponsive(false,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}

var obj = [
    ['<div class=\'dot hover btn22\'></div>'],
    ['<div class=\'dot hover btn23\'></div>'],
    ['<div class=\'dot hover btn24\'></div>'],
    ['<div class=\'dot hover btn25\'></div>'],
    ['<div class=\'dot hover btn26\'></div>'],
    ['<div class=\'dot hover btn27\'></div>'],
    ['<div class=\'dot hover btn28\'></div>'],
    ['<div class=\'dot hover btn29\'></div>'],
    ['<div class=\'dot hover btn30\'></div>'],
    ['<div class=\'dot hover btn31\'></div>'],
    ['<div class=\'dot hover btn32\'></div>'],
    ['<div class=\'dot hover btn33\'></div>'],
    ['<div class=\'dot hover btn34\'></div>'],
    ['<div class=\'dot hover btn35\'></div>'],
    ['<div class=\'dot hover btn36\'></div>'],
    ['<div class=\'dot hover btn37\'></div>'],
    ['<div class=\'dot hover btn38\'></div>'],
    ['<div class=\'dot hover btn39\'></div>'],
    ['<div class=\'dot hover btn40\'></div>'],
    ['<div class=\'dot hover btn41\'></div>'],
    ['<div class=\'dot hover btn42\'></div>'],
    ['<div class=\'dot hover btn43\'></div>'],
    ['<div class=\'dot hover btn44\'></div>'],
    ['<div class=\'dot hover btn45\'></div>'],
    ['<div class=\'dot hover btn46\'></div>'],
    ['<div class=\'dot hover btn47\'></div>'],
    ['<div class=\'dot hover btn48\'></div>'],
    ['<div class=\'dot hover btn49\'></div>'],
    ['<div class=\'dot hover btn50\'></div>'], 
    ['<div class=\'dot hover btn51\'></div>'],
    ['<div class=\'dot hover btn52\'></div>'],
    ['<div class=\'dot hover btn53\'></div>'],
    ['<div class=\'dot hover btn54\'></div>'],
    ['<div class=\'dot hover btn55\'></div>'],
    ['<div class=\'dot hover btn56\'></div>'],
    ['<div class=\'dot hover btn57\'></div>'],
    ['<div class=\'dot hover btn58\'></div>'],
    ['<div class=\'dot hover btn59\'></div>'],
    ['<div class=\'dot hover btn60\'></div>'],
    ['<div class=\'dot hover btn61\'></div>'],
    ['<div class=\'dot hover btn62\'></div>'],
    ['<div class=\'dot hover btn63\'></div>'],
    ['<div class=\'dot hover btn64\'></div>'],
    ['<div class=\'dot hover btn65\'></div>'],
    ['<div class=\'dot hover btn66\'></div>'],
    ['<div class=\'dot hover btn67\'></div>'],
    ['<div class=\'dot hover btn68\'></div>'], 
    ['<div class=\'dot hover btn69\'></div>'],
    ['<div class=\'dot hover btn70\'></div>'],
    ['<div class=\'dot hover btn21\'></div>'],
    ['<div class=\'dot hover btn801\'></div>'],
    ['<div class=\'dot hover btn802\'></div>'],
    ['<div class=\'dot hover btn803\'></div>'],
    ['<div class=\'dot hover btn804\'></div>'],
    ['<div class=\'dot hover btn805\'></div>'],
    ['<div class=\'dot hover btn806\'></div>'],
    ['<div class=\'dot hover btn807\'></div>'],
    ['<div class=\'dot hover btn808\'></div>'],
    ['<div class=\'dot hover btn809\'></div>'],
    ['<div class=\'dot hover btn90\'></div>']
]