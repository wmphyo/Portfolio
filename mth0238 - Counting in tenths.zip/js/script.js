/* Template JS */
/* The State of Queensland (Department of Education and Training) */

//jQuery - Run on page ready
$(function () {
    
    for (var i = 0; i < obj.length; i++) {
        $('.number').append(obj[i]);
    }    
    $('.number').append('<div id="active" class="dot hover btn22"></div>')
    
    //reload the LO
    $('#reset').on('click touchend', function(e){
        location.reload();
    });
    
    var num = 22;
    $('#active').on('click touchend', function(e){
        if($(this).hasClass('btn' + num)){
            $('.btn' + num).removeClass('hover');
            if (num < 70) {
                num++;
                $(this).removeClass().addClass('dot hover btn'+num);
            } else {
                $('.number').hide();
            }
        }
    });
});