/*The State of Queensland (Department of Education and Training)*/

var htmlTxtDisplay = "";

/*Add lyrics to variable*/
htmlTxtDisplay += "Five little monkeys sitting in a tree<br/> Teasing Mr Crocodile: ‘You can’t catch me!’<br/>";
htmlTxtDisplay += "Here is Mr Crocodile, quiet as can be,<br/> He snaps that monkey right out of the tree.<br/><br/>";
htmlTxtDisplay += "Four little monkeys sitting in a tree<br/> Teasing Mr Crocodile: ‘You can’t catch me!’<br/>";
htmlTxtDisplay += "Here is Mr Crocodile, quiet as can be,<br/> He snaps that monkey right out of the tree.<br/><br/>";
htmlTxtDisplay += "Three little monkeys sitting in a tree<br/> Teasing Mr Crocodile: ‘You can’t catch me!’<br/>";
htmlTxtDisplay += "Here is Mr Crocodile, quiet as can be,<br/> He snaps that monkey right out of the tree.<br/><br/>";
htmlTxtDisplay += "Two little monkeys sitting in a tree<br/> Teasing Mr Crocodile: ‘You can’t catch me!’<br/>";
htmlTxtDisplay += "Here is Mr Crocodile, quiet as can be,<br/> He snaps that monkey right out of the tree.<br/><br/>";
htmlTxtDisplay += "One little monkey, sitting in a tree<br/> Teasing Mr Crocodile: ‘You can’t catch me!’<br/>";
htmlTxtDisplay += "Here is Mr Crocodile, quiet as can be,<br/> SNAP went Mr Crocodile!<br/> ‘Ha, ha, you missed me!’";

/*Run on page ready*/
$(document).ready(function(){
	vdoTimerFun();
	$("#displayTxt").html(htmlTxtDisplay);
	
	$("#btnTxtDisplay").on("click touchend", function(e){
		e.preventDefault();
		lyricDisplay();
	});
	
	ctrlBtns();
	
	volBtn();
	
	detectDevice();
	
	var doc = new jsPDF();
	
	$("#btnPrint").on("click touchend", function(e){
		e.preventDefault();
		doc.setFontSize(14);
		doc.text(50, 20, "Five little monkeys sitting in a tree lyrics");
		
		doc.setFontSize(11);
		//left px, top px, html text (syntax).
		doc.text(55, 30, "Five little monkeys sitting in a tree");
		doc.text(55, 35, "Teasing Mr Crocodile: ‘You can’t catch me!’");
		doc.text(55, 40, "Here is Mr Crocodile, quiet as can be,");
		doc.text(55, 45, "He snaps that monkey right out of the tree.");
		doc.text(55, 55, "Four little monkeys sitting in a tree");
		doc.text(55, 60, "Teasing Mr Crocodile: ‘You can’t catch me!’");
		doc.text(55, 65, "Here is Mr Crocodile, quiet as can be,");
		doc.text(55, 70, "He snaps that monkey right out of the tree.");
		doc.text(55, 80, "Three little monkeys sitting in a tree");
		doc.text(55, 85, "Teasing Mr Crocodile: ‘You can’t catch me!’");
		doc.text(55, 90, "Here is Mr Crocodile, quiet as can be,");
		doc.text(55, 95, "He snaps that monkey right out of the tree.");
		doc.text(55, 105, "Two little monkeys sitting in a tree");
		doc.text(55, 110, "Teasing Mr Crocodile: ‘You can’t catch me!’");
		doc.text(55, 115, "Here is Mr Crocodile, quiet as can be,");
		doc.text(55, 120, "He snaps that monkey right out of the tree.");
		doc.text(55, 130, "One little monkeys sitting in a tree");
		doc.text(55, 135, "Teasing Mr Crocodile: ‘You can’t catch me!’");
		doc.text(55, 140, "Here is Mr Crocodile, quiet as can be,");
		doc.text(55, 145, "SNAP went Mr Crocodile!");
		doc.text(55, 150, "‘Ha, Ha, you missed me!’");
		
		doc.save('Lyrics.pdf');
	});				  
	
	$('#btnTxtDisplay, #btnPrint, #btnPlay, #btnStop, #btnPause, #btnVol').on('dragstart', false);
});

/*Function to detect mobile device / desktop browser and hide button on iPad and hover features on all mobile devices.*/
function detectDevice(){
	var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
	var isDroid = /Android/i.test(navigator.userAgent);
	
	if (isApple) {
		$('#btnVol').hide();
		$('.hover').removeClass('hover');
	} else if (isDroid) {
		$('.hover').removeClass('hover');
		//add these to display 00:00 on load on andriod
		var min = '00';
		var sec = '00';
		document.getElementById("timer").innerHTML = min + ":" + sec;
	} else {
		hoverEffects();
	}	
}

/*Function to display text on hovering the buttons | If hover, visible. Else, hidden*/
function hoverEffects(){
	/*Display 'Play' TEXT on screen on hovering play button*/
	$("#btnPlay").hover(function(){
		document.getElementById("playTxt").style.visibility = "visible";		//Display text on screen when hover on the buttons
	}, function() {
		document.getElementById("playTxt").style.visibility = "hidden";
		
	});
	
	/*Display 'Stop' TEXT on screen on hovering stop button*/
	$("#btnStop").hover(function(){
		document.getElementById("stopTxt").style.visibility = "visible";
	}, function(){
		document.getElementById("stopTxt").style.visibility = "hidden";
		
	});
	
	/*Display 'Pause' TEXT on screen on hovering pause button*/
	$("#btnPause").hover(function(){
		document.getElementById("pauseTxt").style.visibility = "visible";
	}, function(){
		document.getElementById("pauseTxt").style.visibility = "hidden";
	});
	
	/*Display 'Volume' TEXT on screen on hovering volume button*/
	$("#btnVol").hover(function(){
		document.getElementById("volTxt").style.visibility = "visible";
	}, function(){
		document.getElementById("volTxt").style.visibility = "hidden";
	});
}

function vdoTimerFun(){
	var vdoTime = document.getElementById("videoScreen");
	
	
	vdoTime.addEventListener("timeupdate", function(){
		/*Store video timer value in variable*/
		
		var currentTime = this.currentTime;
		var remainingseconds = 0;
		var sec = '00';
		var min = '00';
		
		/*Condition check for minute display*/
		if(currentTime >= 60){
			if(Math.floor(currentTime / 60) < 10) {
				min = "0" + Math.floor(currentTime / 60);
			} else {
				min = Math.floor(currentTime / 60);
			}
		}

		remainingseconds = currentTime - (Math.floor(currentTime / 60) * 60);

		/*Condition check for second display*/
		if (remainingseconds < 10) {
			sec = "0" + Math.floor(remainingseconds);
		} else {
			sec = Math.floor (remainingseconds);	
		}
		
		/*Display the numbers on load*/
		document.getElementById("timer").innerHTML = min + ":" + sec;
	});
	
	//Set the timer back to 00:00 at the end of audio. ()
	vdoTime.addEventListener('ended', function(){
		var sec = '00';
		var min = '00';
		document.getElementById('timer').innerHTML = min + ":" + sec;
	});	
}

/*Function for lyric display control*/
function lyricDisplay(){
		/*Toogle slide left and right*/
		  $("#displayTxt").toggle("slide", {
			  direction: "left"
		  }, 300);
}

/*Function to control the video - play, pause, stop*/
function ctrlBtns(){
	
	var vdo = document.getElementById("videoScreen");
	
	$("#btnPlay").on("click touchend", function(e){
		e.preventDefault();
		vdo.play();
	});
	
	$("#btnStop").on("click touchend", function(e){
		e.preventDefault();
		
		if (vdo.currentTime !== 0){
			vdo.pause();
			vdo.addEventListener("loadedmetadata", function () {
				
				/*Assign 0 to current time*/
				vdo.currentTime = 0;
				
			}, false);		
			
			/*reload the video file on load and pause to get ready*/
			vdo.load();
			vdo.pause();
		}
	});
	
	$("#btnPause").on("click touchend", function(e){
		e.preventDefault();
		vdo.pause();
	});
	
}

/*Function to control volume*/
function volBtn(){
	
	/*Store different volume images*/
	var volume = new Array("assets/images/volume3.png", "assets/images/volume2.png", "assets/images/volume1.png", "assets/images/volume.png");
	var counter = 0;

	$("#btnVol").on("click touchend", function(e){
		e.preventDefault();
		/*Reset the counter if it reaches 3*/
		if (counter === 3){
			counter = 0;
		} else {
			counter++;
		}
		
		/*Set volume according to click count*/
		if (counter === 0){
			document.getElementById("videoScreen").volume = 1;
		} else if (counter === 1){
			document.getElementById("videoScreen").volume = 0.6;
		} else if (counter === 2){
			document.getElementById("videoScreen").volume = 0.3;
		} else { 	/*counter == 3*/
			document.getElementById("videoScreen").volume = 0;
		} 
		
		/*Insert volume images into HTML code*/
		$("#btnVol").html("<img src=" + volume[counter] + ">");
	});
}