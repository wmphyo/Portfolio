/* The State of Queensland (Department of Education and Training).*/

var slide_num = 1;
var pos_value = 0;
var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
var isDroid = /Android/i.test(navigator.userAgent);

//jQuery - Run on page ready.
$(document).ready(function (){	
	
	/*Default interface design on load.
	Disable btn bac, display txt 1, add slide num 1 cell border (bottom).*/
	if (isApple || isDroid){
		
		$('.hover').removeClass('hover');
		$('#btnBacHolder').addClass('btnDisable');
		$('#one').addClass('active');
		$('#btnBac, #btnBacHolder').off('click touchend');
		
	} else {
		
		$('#one').addClass('active');
		$('#btnBacHolder').addClass('btnDisable');
		$('#btnBacHolder').removeClass('hover');
		$('#btnBac').removeClass('hover');
		$('#btnBac, #btnBacHolder').off('click touchend');
		
	}
	
	btnOnAction();		//Call function for slide number panel.
	btnAction();		//Call function for for and bac btns.
});

/*Hold button actions on slide numbers
Call display function and pass slide number variable.*/
function btnOnAction(){
	
	//Add off actions to prevent calling same panel number twice
	$('#one').on('click touchend', function(){
		if (slide_num === 1) {
			$('#one').off('click touchend');
		} else {
			display(1);	
		}
	});
	
	$('#two').on('click touchend', function(){
		if (slide_num === 2){
			$('#two').off('click touchend');
		} else {
			display(2);	
		}
	});

	$('#three').on('click touchend', function(){
		if (slide_num === 3){
			$('#three').off('click touchend');
		} else {
			display(3);
		}
	});
	
	$('#four').on('click touchend', function(){
		if (slide_num === 4){
			$('#four').off('click touchend');
		} else {
			display(4);
		}
	});
	
	$('#five').on('click touchend', function(){
		if (slide_num === 5){
			$('#five').off('click touchend');
		} else {
			display(5);
		}
	});
	
	$('#six').on('click touchend', function(){
		if (slide_num === 6){
			$('#six').off('click touchend');
		} else {
			display(6);
		}
	});
	
	$('#seven').on('click touchend', function(){
		if (slide_num === 7){
			$('#seven').off('click touchend');
		} else {
			display(7);
		}
	});
}

//Turn off actions from all buttons for a second while sliding.
function offAction(){
	$("#one").off("click touchend");
	$("#two").off("click touchend");
	$("#three").off("click touchend");
	$("#four").off("click touchend");
	$("#five").off("click touchend");
	$("#six").off("click touchend");
	$("#seven").off("click touchend");
	$("#btnFor, #btnForHolder").off("click touchend");
	$("#btnBac, #btnBacHolder").off("click touchend");
}

/*Function to display animated images & texts.*/
function display(val){
	
	//Call ctrl function to animation & button designs.
	ctrl();
	
	//Call panelDesign for bot border design (active or not).
	if (val === 1) {
		
		pos_value = 0;	
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 1;
		
	} else if (val === 2){
		
		pos_value = -734;
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 2;
		
	} else if (val === 3){
		
		pos_value = -1468;
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 3;
		
	} else if (val === 4){
		
		pos_value = -2202;
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 4;
		
	} else if (val === 5){
		
		pos_value = -2936;
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 5;
		
	} else if (val === 6){
		
		pos_value = -3670;	
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 6;
		
	} else {
		
		pos_value = -4404;
		panelDesign(val);
		$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
		slide_num = 7;
		
	}
	
	//Call btn design so that it will function with slide number accordingly.
	btnDesign();
	
}

//To animate text display, off button actions and turn them back on.
function ctrl(){
	
	offAction();
	
	//This one turns back on actions from all buttons.
	setTimeout(btnOnAction, 1000);
	setTimeout(btnAction, 1000);
}

//For forward and backward buttons. 
function btnAction(){
	
	$('#btnFor, #btnForHolder').on('click touchend', function(){
		
		//Disable forward button on last slide (num 7).
		if (slide_num === 7){
			$('#btnFor, #btnForHolder').off('click touchend');
		} else {
			//Slide image, display text through ctrl(), add bot border through panelDesign(val).
				pos_value = pos_value - 734;
				$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
				slide_num++;
				panelDesign(slide_num);
				ctrl();
				btnDesign();
			}
	});
	
	
	$('#btnBac, #btnBacHolder').on('click touchend', function(){
		
		//Disable backward button on first slide (num 1).
		if (slide_num === 1){
			$('#btnBac, #btnBacHolder').off('click touchend');
		} else {
			//Slide image, display text through ctrl(), add bot border through panelDesign(val).
			pos_value = pos_value + 734;
			$('#imgDisplay').animate({backgroundPosition: pos_value + "px"}, 1000);
			slide_num--;
			panelDesign(slide_num);
			ctrl();
			btnDesign();
		}
	});
}

//for disabling, enabling and hover effect on buttons | separate function just for button designs.
function btnDesign(){
	
	//everything not 1 | enable btn back.
	if(slide_num !== 1){
		
		$('#btnBacHolder').removeClass('btnDisable');
		
		//remove hover effect for mobile devices.
		if (isApple || isDroid){
			$('.hover').removeClass('hover');
		} else {
			$('#btnBacHolder').addClass('hover');
			$('#btnBac').addClass('hover');
		}
		
		$('#btnBac, #btnBacHolder').on('click touchend');
		
		//everything not 1 but 7 | Disable btn forward.
		if(slide_num === 7){
		
			$('#btnForHolder').addClass('btnDisable');
			$('#btnForHolder').removeClass('hover');
			$('#btnFor').removeClass('hover');
			$('#btnFor, #btnForHolder').off('click touchend');
		
		}
	}
	
	//everything not 7 | Enable btn forward.
	if (slide_num !== 7){
		
		$('#btnForHolder').removeClass('btnDisable');
		
		//remove hover effect for mobile devices.
		if (isApple || isDroid) {
			$('.hover').removeClass('hover');
		} else {
			$('#btnForHolder').addClass('hover');
			$('#btnFor').addClass('hover');	
		}
		
		$('#btnFor, #btnForHolder').on('click touchend');
		
		//everything not 7 but 1 | Disable btn back.
		if (slide_num === 1){
			
			$('#btnBacHolder').addClass('btnDisable');
			$('#btnBacHolder').removeClass('hover');
			$('#btnBac').removeClass('hover');
			$('#btnBac, #btnBacHolder').off('click touchend');
			
		}
	}
}

//For underline design under slide panel numbers.
function panelDesign(val){
	
	//Reset all underline on call.
	$('#one, #two, #three, #four, #five, #six, #seven').removeClass('active');
	
	//Add underline border accordingly.
	if (val === 1){
		$('#one').addClass('active');	
	} else if (val === 2){
		$('#two').addClass('active');
	} else if (val === 3){
		$('#three').addClass('active');
	} else if (val === 4){
		$('#four').addClass('active');
	} else if (val === 5){
		$('#five').addClass('active');
	} else if (val === 6){
		$('#six').addClass('active');
	} else {
		$('#seven').addClass('active');
	}	
}