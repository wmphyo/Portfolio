var _multiply = true;
var _divide = false;
var _ten = true;
var _hun = false;
var _thou = false;
var _rdoSPN = true;
var _rdoSD = true;
var _intArr = '';
var _deciArr = '';
var btnctrl = 0;

$(document).ready(function() { 
	
	//Call charlimit function to limit num only input
	$('#numInput').on('input', charLimit);	
	
	//hide text after 'Show digits' on load
	$('#showDigits').find('p').hide();
	
	//10 100 1000 panel buttons
	$('#valTen').on('click touchend', function(e){
		
		e.preventDefault();
		valTen();
		
	});
	
	$('#valHun').on('click touchend', function(e){
		
		e.preventDefault();
		valHun();
		
	});
	
	$('#valThou').on('click touchend', function(e){
		
		e.preventDefault();
		valThou();
		
	});
	
	//Show place names radio button
	$('#rdoShowPlaceNames').on('click touchend', function (e){
		
		e.preventDefault();
		rdoShowPlaceNames();
		
	});
	
	//Show digits radio button
	$('#rdoShowDigits').on('click touchend', function(e) {
		
		e.preventDefault();
		rdoShowDigits();
		
	});
	
	//Divide by radio button
	$('#rdoDivide').on('click touchend', function(e){
		
		e.preventDefault();
		divide_by();
		
	});
	
	//Multiply by radio button
	$('#rdoMultiply').on('click touchend', function(e){
		
		e.preventDefault();
		multiply_by();
		
	});
	
	//Apply function button
	$('#btnApplyFun').on('click touchend', function(e){
		
		e.preventDefault();
		var input_value = $('#numInput').val();
	
		//Give warning for empty input
		if(input_value === ''){
			//warning message and its design
			$('#displayLabel').find('label').html('First enter a number.');
			$('#displayLabel').css('visibility' , 'visible');
		//call apply_fun function if input value is not NULL
		} else {
			//hide warning message
			$('#displayLabel').css('visibility', 'hidden');
			if (btnctrl === 0){
				apply_fun();	
			} else {
				return 0;
			}
		}
	});
	
	//touch action on display cells | display or hide integer values on display cells
	$('#int_1, #int_2, #int_3, #int_4, #int_5, #int_6, #int_7, #deci_1, #deci_2, #deci_3').on('click touchend', function(e){
		
		e.preventDefault();
		$(this).find('span').toggle();
		
	})
	
	//update slider button
	$('#btnUpdate').on('click touchend', function(e){
		
		e.preventDefault();
		
		//Pass variable from text input to variable
		var input_value = $('#numInput').val();
		
		//generate warning message for empty input
		if(input_value === ''){
			
			// warning message and its design
			$('#displayLabel').css('visibility', 'visible');
			$('#displayLabel').find('label').html('First enter a number.');
			clearDisplayCells();
			
			//if input value is not NULL| hide warning message and call accept_input function
		} else {
			
			$('#displayPanel').find('span').show();	//??? why is this one here??
			$('#displayLabel').css('visibility', 'hidden');
			clearDisplayCells();
			accept_input(input_value);
			
		}
	});
	
	//Button Slide left | call slideLeft function
	$('#btnSlideLeft').on('click touchend', function(e){
		e.preventDefault();
		if (btnctrl === 0){
			slideLeft();			
		} else {
			return 0;
		}		
	});
	
	//Button slide right | call slideRight function
	$('#btnSlideRight').on('click touchend', function(e){
		
		e.preventDefault();
		if (btnctrl === 0){
			slideRight();	
		} else {
			return 0;	
		}		
	});
	
	//Set all values to null / original values
	$('#btnClearAll').on('click touchend', function(e){
		e.preventDefault();
		document.getElementById('btnClearAll').disabled = true;
		
		setTimeout(function(){
			document.getElementById('btnClearAll').disabled = false;
		}, 800);
		
		multiply_by();
		valTen();
		$('#numInput').val('');
		$('#numInput').focus();
		$('#displayLabel').css('visibility', 'hidden');
		$('#rdoShowDigits').addClass('rdoChecked');
		$('#rdoShowDigits').removeClass('rdoNormal');
		$('#rdoShowPlaceNames').addClass('rdoChecked');
		$('#rdoShowPlaceNames').removeClass('rdoNormal');
		$('#displayPanel').find('label').show();
		/*Reset slider values to 1 and 4 respectively*/
		$('#sliderBarLeft').slider('value', 0);
		$('#sliderBarRight').slider('value', 4);
		_rdoSD = true;
		_rdoSPN = true;
		$('#showDigits').find('p').hide();
		_intArr = '';
		_deciArr = '';
		clearDisplayCells();
		resetLowOpacCells();
	});
	
	//Slider bar to control shade on decimal values (on the right side of LO)
	$("#sliderBarRight").slider({
		
		range: "min",
		min: 0,
		max: 3,
		value: 3,
		slide: function(event, ui){
			
			var sliderVal = ui.value;
			var j = 3;
			
			//Logic goes reverse of int slider
			if(sliderVal === 3){
				
				/*Remove Low Opac from deci 1 2 3 | t h th*/
				for(j; j >= 0 ; j--){
					
					$('#deci_' + j).addClass('displayCellDeci');
					$('#deci_' + j).removeClass('displayCellDeciSlide');
					
				}
				
			} else if (sliderVal === 2){
				
				/*Add low opac to deci_3 | th*/
				$('#deci_3').addClass('displayCellDeciSlide');
				
				/*Remove low opac from deci_1 and deci_2 | t & h | if they were added before*/
				for(j = 1; j < 3; j++){
					
					$('#deci_' + j).removeClass('displayCellDeciSlide');
					$('#deci_' + j).addClass('displayCellDeci');
					
				}
				
			} else if (sliderVal === 1){
				
				/*Add low opac to deci_3 and deci_2 | th and h*/
				for(j; j >= 2 ; j--){
					
					$('#deci_' + j).addClass('displayCellDeciSlide');
					
				}
				
				/*Remove low opac from deci_1 | t*/
				$('#deci_1').removeClass('displayCellDeciSlide');
				$('#deci_1').addClass('displayCellDeci');
				
			} else { 	/*sliderVal === 0*/
				
				//Add low opac to all 3 cells in decimal side
				for(j; j >= 0 ; j--){
					
					$('#deci_' + j).addClass('displayCellDeciSlide');
					$('#deci_' + j).removeClass('displayCellDeci');
					
				}
				
			}
			
		}
	});
	
	//Slider bar to control shade on integer values (on the left side of LO)
	$("#sliderBarLeft").slider({
		
		range: "max",
		min: 0,
		max: 6,
		value: 0,	/*Starting at 0 position*/
		slide: function( event, ui ) {
			
			//Insert shading on display cells here
			var slideVal = ui.value;
			var i = 1;
			
			//Codes below plays with low opacity and normal background of display cells
			if(slideVal === 0){
				
				/*Remove low opac from all integer cells*/
				for (i; i < 7; i++){
					
					$('#int_' + i).addClass('displayCellInt');
					$('#int_' + i).removeClass('displayCellIntSlide');
					
				}
			} else if (slideVal === 1){
				
				/*Add low opac*/
				$('#int_1').addClass('displayCellIntSlide');
				$('#int_1').removeClass('displayCellInt');
				
				/*Remove low opac - 2 to 6 | HTH to T*/
				for (i = 2; i < 7; i++){
					
					$('#int_' + i).addClass('displayCellInt');
					$('#int_' + i).removeClass('displayCellIntSlide');
					
				}
				
			} else if(slideVal === 2){
				
				/*Add low opac - 1 & 2 | M & HTH*/
				for(i; i < 3; i++){
					
					$('#int_' + i).addClass('displayCellIntSlide');
					$('#int_' + i).removeClass('displayCellInt');
					
				}
				
				/*Remove low opac - 3 to 6 || TTH to T*/
				for (i = 3; i < 7; i++){
					
					$('#int_' + i).addClass('displayCellInt');
					$('#int_' + i).removeClass('displayCellIntSlide');
					
				}
				
			} else if(slideVal === 3){
				
				/*Add low opac - 1 to 3 | M to TTH*/
				for(i; i < 4; i++){
					
					$('#int_' + i).addClass('displayCellIntSlide');
					$('#int_' + i).removeClass('displayCellInt');
					
				}
				
				/*Remove low opac - 4 to 6 || TH to T*/
				for (i = 4; i < 7; i++){
					
					$('#int_' + i).addClass('displayCellInt');
					$('#int_' + i).removeClass('displayCellIntSlide');
					
				}
				
			} else if(slideVal === 4){
				/*Add low opac - 1 to 4 | M to TH*/
				for(i; i < 5; i++){
					
					$('#int_' + i).addClass('displayCellIntSlide');
					$('#int_' + i).removeClass('displayCellInt');
					
				}
				/*Remove low opac - 5 to 6 || H to T*/
				for (i = 5; i < 7; i++){
					
					$('#int_' + i).addClass('displayCellInt');
					$('#int_' + i).removeClass('displayCellIntSlide');
					
				}
				
			} else if(slideVal === 5){
				
				for(i; i < 6; i++){
					
					$('#int_' + i).addClass('displayCellIntSlide');
					$('#int_' + i).removeClass('displayCellInt');
					
				}
				
				$('#int_6').removeClass('displayCellIntSlide');
				$('#int_6').addClass('displayCellInt');
				
			} else { 
				/*Loop to add low opacity class - 1 to 6 | M to Ones*/
				for(i; i < 7; i++){
					
					$('#int_' + i).addClass('displayCellIntSlide');
					$('#int_' + i).removeClass('displayCellInt');
					
				}
			}
		}
	});
	
	$('#btnPrint').on('click touchend', function(e){
		
		e.preventDefault();
		window.print();
		
	});
});

//Function to remove dark grey color to silver creamy color from the cells
function resetLowOpacCells(){
	//Only for btnClearAll action
	var i = 1;
	
	for (i; i < 7; i++){		
		$('#int_' + i).addClass('displayCellInt');
		$('#int_' + i).removeClass('displayCellIntSlide');		
	}
	
	var j = 1;
	
	for (j; j < 4; j++){		
		$('#deci_' + j).addClass('displayCellDeci');
		$('#deci_' + j).removeClass('displayCellDeciSlide');		
	}	
}

/*Slide left button*/
function slideLeft(){
	//fade in out animation								
	$('#slideDisplayInt').find('span').fadeOut(300);
	$('#slideDisplayDeci').find('span').fadeOut(300);
	$('#btnSlideLeft').removeClass('hover');
	
	//to disable button left for a while
	btnctrl = 1;	
	
	setTimeout(function(){		
		$('#btnSlideLeft').addClass('hover');		
		//enable button left
		btnctrl = 0;
	}, 800);	
	
	//pass value from input text
	var input_value = $('#numInput').val();
	
	//Display warning if input is empty | This is correct and no further changes required.
	if(input_value === ''){		
		//warning message and its design
		$('#displayLabel').css('visibility', 'visible');
		$('#displayLabel').find('label').html('First enter a number.');		
	//input is not empty
	} else {
		//empty array values | i.e. input values are not updated to arrays yet.
		if (_intArr === '' || _deciArr === '') {
			
			$('#displayLabel').css('visibility', 'visible');
			$('#displayLabel').find('label').html('First enter a number.');

		//if input values are not empty and array values are not empty
		} else {
			
			//Hide warning container 
			$('#displayLabel').css('visibility', 'hidden');
			
			//integer array length is less than 11
			if (_intArr.length < 11){
				
				if (_deciArr.length !== 0){
					
					_intArr.push(_deciArr[0]);
					_deciArr.shift();
					
				} else {
					
					_intArr.push("0");
					
				}				
				//integer array lenlgth is greater than 11
			} else {
				
				//display warning message
				$('#displayLabel').css('visibility', 'visible');
				$('#displayLabel').find('label').html('Input values exceeded the limit.');
				
			}
			
			remove_zero();
			setTimeout(display_numbers, 300);
		}
	}
}

/*Slide right button*/
function slideRight(){
	//Fade in out animation.
	$('#slideDisplayInt').find('span').fadeOut(300);
	$('#slideDisplayDeci').find('span').fadeOut(300);
	$('#btnSlideRight').removeClass('hover');
	btnctrl = 1; //disable the button
	
	setTimeout(function(){
		$('#btnSlideRight').addClass('hover');
		btnctrl = 0;	//enable the button
	}, 800);
	
	//pass value from input text
	var input_value = $('#numInput').val();
	
	//Display warning if input is empty
	if(input_value === '') {
		
		$('#displayLabel').css('visibility', 'visible');
		$('#displayLabel').find('label').html('First enter a number.');
		
	//input is not empty
	} else {
		
		//input is not empty but array values are empty
		if (_intArr === '' || _deciArr === '') {
			
			$('#displayLabel').css('visibility', 'visible');
			$('#displayLabel').find('label').html('First enter a number.');
			
		} else {
			//hide warning
			$('#displayLabel').css('visibility', 'hidden');
			
			if(_deciArr.length < 11){
				
				if (_intArr.length !== 0){
					
					_deciArr.unshift(_intArr[_intArr.length - 1]);
					_intArr.pop();
					
				} else {
					
					_deciArr.unshift("0");
					
				}
				
			//Decimal array length is larger than 11
			} else {
				
				$('#displayLabel').css('visibility', 'visible');
				$('#displayLabel').find('label').html('Input values exceeded the limit.');
				
			}
			
			setTimeout(display_numbers, 400);
			remove_zero();
		}
	}
}//Loop to ping point dot position - insert values before dot to int array

/*Function to display input number on slide elements*/
function accept_input(input_value){
	
	/*Create objects to check dot first, dot last and dot middle and return the value accordingly*/
	var input_val = input_value;
	
	/*Object to check dot count - one or more than one dot*/
	var dot_count = new check_dot_count(input_val);
	
	/*Object to check dot position - first, middle or last*/
	var dot_pos = new check_dot_position(input_val);
	
	var input_num = new set_input_value();
	
	/*Give warning message if there is more than one dot*/
	if(dot_count.count > 1){
		
		$('#displayLabel').css('visibility', 'visible');
		$('#displayLabel').find('label').text('Input accepts only ONE dot.');
		
	//Give warning if the input is only dot
	} else if (input_val.split('').length === 1 && input_val === '.') {
		
		$('#displayLabel').css('visibility', 'visible');
		$('#displayLabel').find('label').text('Input numbers.');
		
	//condition - one dot and input contain numbers
	} else {
		
		//Check if dot position is at the beginning of input
		if(dot_pos.first){
			
			/*insert values into deci array and return it*/
			dot_first(input_val);
			
		//Check if dot position is at the end of input
		} else if (dot_pos.last){
			
			/*insert values into int array and return it*/
			dot_last(input_val);
			
		//Check if dot position is somewhere in the input
		} else if (dot_pos.dot) {
			
			/*insert values into both int array and deci array and return them*/
			dot(input_val);
			
		//else = input got no dot in it.
		//call dot last again because it does the same function as dot last or no dot.
		} else {
			
			/*insert values into int array and return it*/
			dot_last(input_val);
			
		}
		
		remove_zero();
	}

	display_numbers();
}

/*Function to display numbers on the slider*/
function display_numbers(){
	//to clear the dispaly before numbers are shown everytime
	clearDisplayCells();	
	var int_pos = 7;
	var deci_pos = 1;
	var int_arr_len = _intArr.length;
	var deci_arr_len = _deciArr.length;
	
	//if int array is empty, add zero, else
	/*Loop to insert numbers from array to html span - display them on screen*/
	do {
		
		$('#int_' + int_pos).find('span').text(_intArr[int_arr_len - 1]).fadeIn(200);	
		int_pos--;
		int_arr_len--;
		
	} while ( int_pos > 0 );
	
	//if deci array is empty, add zero, else
	/*Loop to insert numbers from array to html span - display them on screen*/
	do {
		
		$('#deci_' + deci_pos).find('span').text(_deciArr[deci_pos - 1]).fadeIn(200);	//deci_pos - 1 to check position 0 in array
		deci_pos++;
		deci_arr_len--;	
		
	} while ( deci_pos < 4 );
}

/*Function to remove zero in input - at the beginning or at the end after decimal*/
function remove_zero(){

	//remove zeroes in int array
	if (_intArr[0] === '0'){		
		do {
			_intArr.shift();
		} while (_intArr[0] === '0');
	}
	
	//add zero if there is no value in array.
	if(_intArr.length === 0){
			_intArr[0] = '0';
	}
	
	//remove zeroes from decimal array / value
	if(_deciArr[_deciArr.length - 1 ] === '0'){
		do{
			_deciArr.pop();
		} while (_deciArr[_deciArr.length - 1] === '0')
	}
	
	//hide zeroes if there are zeroes in t h th in decimal display.
	if(_deciArr[2] === '0'){
		if(_deciArr[1] === '0'){
			if(_deciArr[0] === '0'){
				var count = 1;
				
				setTimeout(function(){
					for(count; count < 4; count++){
						$('#deci_' + count).find('span').fadeOut('fast');		
					}
					if(_intArr[_intArr.length - 1] === '0'){
						$('#int_7').find('span').fadeOut('fast');	
					}					
				}, 600);	
			}			
		}		
	}
}

/*Function for dot first - to set decimal array values*/
function dot_first(input_val){
	
	this.input_val = input_val.split('');
	var i = 0;
	
	/*Remove dot at the beginning*/
	this.input_val.shift();
	
	/*Call input object to set values in (deci) array*/
	var input = new set_input_value();
	
	for (i ; i < this.input_val.length ; i++){
		
		input.deci_arr[i] = this.input_val[i];
		
	}
}

/*Function for both dot last and no dot - to set integer array values*/
function dot_last(input_val){
	
	this.input_val = input_val.split('');
	var i = 0;
	
	/*Call dot_pos object to check dot last*/
	var dot_pos = new check_dot_position(input_val);
	
	/*Call set input values  object to set values*/
	var input = new set_input_value();
	
	//If there's dot at the end of input, remove it
	if(dot_pos.last){
		this.input_val.pop();
	}
	
	//Assign input values to integer array
	for (i ; i < this.input_val.length; i++){
		
		input.int_arr[i] = this.input_val[i];
		
	}
	
	
}

//Function for dot in the middle of input - to set both integer array and decimal arrays
//Split the input - put values before dot into int array and after into decimal array
function dot(input_val){
	
	this.input_val = input_val.split('');
	
	var i = 0;
	var j = 0;
	
	var input = new set_input_value();
	
	//Loop to ping point dot position - insert values before dot to int array
	do{
		
		input.int_arr[i] = this.input_val[0];
		//i value must vary to set int array element number
		i++; 
		this.input_val.shift();
		
	} while(this.input_val[0] !== '.');
	
	//Remove dot at the beginning
	this.input_val.shift();
	
	//Loop to insert values after dot to deci array
	do{
		
		input.deci_arr[j] = this.input_val[0];
		j++;
		this.input_val.shift();
		
	} while(this.input_val.length !== 0);
	
}

/*Object to set input values as per dot position - setter*/
function set_input_value(){
	
	this.int_arr = [];
	this.deci_arr = [];
	
	_intArr = this.int_arr;
	_deciArr = this.deci_arr;
	
}

/*Object to check dot position - first, middle or last*/
function check_dot_position(input_val){
	
	var input = input_val;
	
	/*Regular expression for dot*/
	var dot = /\./g;
	var last = /\.$/g;
	var first = /^\./g;
	
	/*Four conditions - Dot first, Dot last, Dot in the middle and no dot*/
	if(input.match(first)){
		
		this.first = true;
		
	} else if(input.match(last)){
		
		this.last = true;
		
	} else if (input.match(dot)){
		
		this.dot = true;	   
		
	} else {
		
		this.no_dot = true;
		
	}
}

/*Object to check dot count and return count value*/
function check_dot_count(input_val){
	
	this.input_val = input_val;
	var count = 0;
	
	/*Create dot_check array and check each element whether it is dot or not*/
	var dot_check = this.input_val.split('');
	
	for(var i = 0; i < dot_check.length; i++){
		
		if(dot_check[i] === '.'){
			
			count++;
			
		}
		
	}
	
	this.count = count;
}

/*Function for 'Apply function' button*/
function apply_fun(){	
	
	//for fadein and out feature
	$('#slideDisplayInt').find('span').fadeOut(200);
	$('#slideDisplayDeci').find('span').fadeOut(200);
	
	$('#btnApplyFun').removeClass('hover');
	btnctrl = 1;	//disable the button
	
	setTimeout(function(){
		$('#btnApplyFun').addClass('hover');
		btnctrl = 0;	//enable the button
	}, 800);	
	
	var i = 0;
	//multiple radio button is checked
	if(_multiply){
		
		//Stop function and give warning if array length is larger than 11
		if(_intArr.length >= 11){
			//Display warning
			$('#displayLabel').css('visibility', 'visible');
			$('#displayLabel').find('label').text('Input values exceeded the limit.');
			
		} else {
			//Don't need to hide the warning, as it's hidden in slide buttons
			//If deci array is empty, add zeroes
			if (_deciArr.length === 0){
				
				if (_ten){
					/*Push one zero to int array*/
					_intArr.push("0");
				} else if (_hun){
					/*Push two zero to int array*/
					_intArr.push("0", "0");
				} else {
					/*Push three zero to int array*/
					_intArr.push("0", "0", "0");
				}
				
			} else {	//if deci array is not empty, add array value 0 1 2
				
				if(_ten){
					/*_ten = true*/
					_intArr.push(_deciArr[0]);
					_deciArr.shift();
					/*remove first item of deci array (as it is already added to int array)*/
				} else if(_hun){
					/*_hun = true*/
					for (i; i < 2; i++){
						/*To prevent adding undefined when deci array got no value in it*/
						if (_deciArr.length !== 0){
							_intArr.push(_deciArr[0]);	
						} else {
							_intArr.push("0");
						}						
						_deciArr.shift();	
					}
				} else {
				/*_thou = true*/
					for (i; i < 3; i++){
						/*To prevent adding undefined when deci array got no value in it*/
						if(_deciArr.length !== 0){
							_intArr.push(_deciArr[0]);
						} else {
							_intArr.push("0");
						}
						_deciArr.shift();
					}
				}
				
			}

		}
	//if (_divide) | Divide by radio button is selected
	} else {	
		//Stop executing if decimal array length is larger than 11.
		if(_deciArr.length >= 11){
			
			$('#displayLabel').css('visibility', 'visible');
			$('#displayLabel').find('label').text('Input values exceeded the limit.');
			
		} else {
			
			/*if int array is empty \ add zeroes*/
			if (_intArr.length === 0){	
				if (_ten){
					/*unshift 0 to deci array*/
					_deciArr.unshift("0");
				} else if(_hun){
					/*unshift two zeros to deci array*/
					_deciArr.unshift("0", "0");
				} else {
					/*unshift three zeros to deci array*/
					_deciArr.unshift("0", "0", "0");
				}
				
			} else {		//if int array is not empty \ add last 3 values
				
				if(_ten){	/*_ten = true*/
					
					/*Devide with 10 - shift last item from int array to first item in deci-array*/
					_deciArr.unshift(_intArr[_intArr.length - 1]);
					_intArr.pop();
					
				} else if(_hun){	/*_hun = true*/
					
					/*Devide with 100 - shift last TWO items from int array to TWO item in deci-array*/
					for (i; i < 2; i++){
						
						if (_intArr.length !== 0){
							_deciArr.unshift(_intArr[_intArr.length - 1]);
						} else {
							_deciArr.unshift("0");
						}
						_intArr.pop();
						
					}
					
				} else {	/*_thou = true*/
					
					/*Devide with 1000 - shift last THRWEE items from int array to THREE first item in deci-array*/
					for (i; i < 3; i++){
						
						if(_intArr.length !== 0){
							_deciArr.unshift(_intArr[_intArr.length - 1]);
						} else {
							_deciArr.unshift("0");
						}
						_intArr.pop();						
					}					
				}
			}			
		}
	}
	
	remove_zero();
	setTimeout(display_numbers, 300);
	
}

/*Function for 'Show digits' radio button*/
function rdoShowDigits(){
	
	if(_rdoSD) {
		
		/*remove orange and add grey*/	
		$('#rdoShowDigits').addClass('rdoNormal');
		$('#rdoShowDigits').removeClass('rdoChecked');
		$('#displayPanel').find('span').hide();
		_rdoSD = false;
		$('#showDigits').find('p').show();
		
	} else {
		
		/*add orange and remove grey*/
		$('#rdoShowDigits').removeClass('rdoNormal');
		$('#rdoShowDigits').addClass('rdoChecked');
		$('#displayPanel').find('span').show();
		_rdoSD = true;
		$('#showDigits').find('p').hide();
		
	}
}

/*Function for 'Show place names' radio button*/
function rdoShowPlaceNames(){
	
	if(_rdoSPN){
		
		/*remove orange, add grey and hide the elements*/
		$('#rdoShowPlaceNames').addClass('rdoNormal');
		$('#rdoShowPlaceNames').removeClass('rdoChecked');
		$('#displayPanel').find('label').hide();
		_rdoSPN = false;
		
	} else {
		
		/*add orange and remove grey*/
		$('#rdoShowPlaceNames').removeClass('rdoNormal');
		$('#rdoShowPlaceNames').addClass('rdoChecked');
		$('#displayPanel').find('label').show();
		_rdoSPN = true;
		
	}
	
}

/*Function for value thousand - checked in value panel*/
function valThou(){
	
	_thou = true;
	_ten = false;
	_hun = false;
	
	$('#valThou').addClass('valPanChecked');
	$('#valTen').removeClass('valPanChecked');
	$('#valHun').removeClass('valPanChecked');
	
}

/*Function for value hundred - checked in value panel*/
function valHun(){
	
	_hun = true;
	_ten = false;
	_thou = false;
	
	$('#valHun').addClass('valPanChecked');
	$('#valTen').removeClass('valPanChecked');
	$('#valThou').removeClass('valPanChecked');
	
}

/*Function for value ten - checked in value panel*/
function valTen(){
	
	_ten = true;
	_hun = false;
	_thou = false;
		
	$('#valTen').addClass('valPanChecked');
	$('#valHun').removeClass('valPanChecked');
	$('#valThou').removeClass('valPanChecked');
	
}

/*Radio button multiply by checked | rdoNormal = Grey bg, rdoChecked = Orange bg*/
function multiply_by(){
	
	_multiply = true;
	_divide = false;
	
	$('#rdoMultiply').removeClass('rdoNormal');
	$('#rdoMultiply').addClass('rdoChecked');
	$('#rdoDivide').removeClass('rdoChecked');
	$('#rdoDivide').addClass('rdoNormal');
	
}

/*Radio button divided by checked | rdoNormal = Grey bg, rdoChecked = Orange bg*/
function divide_by(){
	
		_divide = true;
		_multiply = false;
		
		$('#rdoDivide').removeClass('rdoNormal');
		$('#rdoDivide').addClass('rdoChecked');
		$('#rdoMultiply').removeClass('rdoChecked');
		$('#rdoMultiply').addClass('rdoNormal');
	
}

/*Function to set input - number only*/
function charLimit() {
	
        var position = this.selectionStart;
        var start = $('#numInput').val().length;
        this.value = this.value.replace(/[^0-9.]+/g, '');
        var final = $('#numInput').val().length;
	
		/*Codes that keep cursor position as it is instead of moving to the end of input*/
        if (start == final) {
            this.selectionEnd = position;
        } else {
            this.selectionEnd = position - 1;
    	}
	
}

/*Function to clear numbers from display cells*/
function clearDisplayCells(){
	
	$('#slideDisplayInt').find('span').html('');
	$('#slideDisplayDeci').find('span').html('');
	
}

/*Code for 'Enter' key input feature*/
$(document).keypress(function(e){
	
	if(e.which == 13) {
		if($('#numInput').val() !== ''){
			//reveal input numbers in slider cell
			$('#displayPanel').find('span').show();
			$('#displayLabel').css('visibility', 'hidden');
			clearDisplayCells();
			accept_input($('#numInput').val());
		} else {
			$('#displayLabel').css('visibility', 'visible');
			$('#displayLabel').find('label').html('First enter a number.');
			clearDisplayCells();
			$('#numInput').focus();
		}
	}
	
});
