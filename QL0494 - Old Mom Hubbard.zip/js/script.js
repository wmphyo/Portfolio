/* Template JS */
/* The State of Queensland (Department of Education and Training) */
var pgNum = 0;
var not7 = '<div id="imgContainer" class="side-img-container"></div><div id="content" class="content-container float-left" ></div><div id="bgImg"></div>';
var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
var isAndroid = /Android/i.test(navigator.userAgent);
var counter = 0;
var audio = new Audio();
var currentTime, animeTime, clickedBTN, fileCheck1, fileCheck2;

//jQuery - Run on page ready
$(function () {
    
    //codes for initial page load
    pages(pgNum);
    audio.src = imgObj[Object.keys(imgObj)[pgNum]];
    
    //to display page one on load.
    $('#btnBac, #btnFor').on('click touchend', function(e) {
        e.preventDefault();
        var clickedBTN = e.currentTarget.id;
        
        //reset dropCount so that popup message will be correctly displayed
        objDrop.count = 0;
        
        //reset audio features and click boolean when new page is called.
        audio.pause(); audio.load();
        btnClicked.btnCtxtClicked = true;
        btnClicked.btnInsClicked = true;
        $('#btnInstruction').playplay();
        
        //check which button is clicked | button control
        clickedBTN === 'btnBac' ? pgNum-- : pgNum++;
        pgNum < 1 ? $('#btnBac').hidden() : $('#btnBac').visible();
        pgNum > 5 ? $('#btnFor').hidden() : $('#btnFor').visible();
        pgNum === 6 ? $('#playBtn').visible() : $('#playBtn').hidden();
        $('.instructions-container').textChange(pgNum);
        
        //last page
        if(pgNum === 6) {
            audio.addEventListener('timeupdate', lastPgAnimation);
            pageSeven();
        //any other page
        } else {
            audio.removeEventListener('timeupdate', lastPgAnimation);
            $('.main-bg').html(main.content);
            $('.rhyme-content-container').html('');
            $('#bgImg').removeClass().addClass('main-bg page-' + pgNum);
            pages(pgNum);
        }
    });
    
    $('#btnReset').on('click touchend', function(e) {
        e.preventDefault();
        window.location.reload();
    });
    
    //play button for 'Drag the pic onto...
    $('#btnInstruction').on('click touchend', function(e) {
        e.preventDefault();
        clickedBTN = e.currentTarget.id;
        animeTime = currentTime;        
        audio.removeEventListener('timeupdate', lastPgAnimation);
        
        $('#btnPlay, #popUpPlay').playplay();        
        $('#popUpID').css({'visibility': 'hidden'});
        
        btnClicked.btnCtxtClicked = true; btnClicked.btnPopUpClicked = true;
        btnClicked.playBtnClicked = true;
        
        //insert instruction audio path according to page number
        pgNum === 6 ? audio.src = imgObj.ins7 : audio.src = imgObj.ins16;
        
        //check click
        if(btnClicked.btnInsClicked) {
            audio.play();                   //play            
            $(this).stopstop();             //change to stop icon
            btnClicked.btnInsClicked = false;
        } else {
            audio.pause();  audio.load();   //stop and reload         
            $(this).playplay();             //change to play icon
            btnClicked.btnInsClicked = true;
        }
    });
    
    //change the button back to play at the end of audio. need this here for both button actions.
    audio.addEventListener('ended', function() {
        $('#btnInstruction, #btnPlay, #popUpPlay').playplay();
        btnClicked.btnInsClicked = true; btnClicked.btnCtxtClicked = true;
        btnClicked.btnPopUpClicked = true; btnClicked.playBtnClicked = true;
    });
    
    $('#playBtn').on('click touchend', function(e) {
        e.preventDefault();
        clickedBTN = e.currentTarget.id;
        
        fileCheck1 = audio.src;
        fileCheck1 = fileCheck1.substr(fileCheck1.lastIndexOf('/') + 1);
        fileCheck2 = imgObj.ins7;
        fileCheck2 = fileCheck2.substr(fileCheck2.lastIndexOf('/') + 1);
        
        if (fileCheck1 === fileCheck2) {
            audio.src = imgObj[Object.keys(imgObj)[24]];
            audio.currentTime = animeTime;
            audio.addEventListener('timeupdate', lastPgAnimation);            
        }      
        
        
        if (btnClicked.playBtnClicked) {
      
            btnClicked.playBtnClicked = false;
            $('#btnPlay').stopstop();
            playFun();
        } else {
            audio.pause();
            btnClicked.playBtnClicked = true;
        }
    });
});

//page 7 removes #imgContainer, #content and #bgImg divs
function pageSeven() {
    btnClicked.playBtnClicked = true;
    
    //Particularly for page 7, add the content to .main-bg.    
    audio.src = imgObj[Object.keys(imgObj)[24]];
    $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[0]]);
    $('#btnPlay').on('click touchend', playFun);
}

/*Function to enable image drag and drop according to page number (1-6 only).
Page 7 will have a separate function for itself. Completed*/
function pages(pgNum) {
    var img, content, dragClass, len;
    
    //insert the HTML contents into variables
    for (var i = 0; i < 6; i++) {
        switch (pgNum) {
            case i:
                //set the length as per page | page 1 needs 4 drops : other pages only 2.
                pgNum === 0 ? len = 4 : len = 2;
                
                //Object.values is not supported, so used Object.keys
                img = imgConObj[Object.keys(imgConObj)[i]];
                content = contentArr[Object.keys(contentArr)[i]];
                dragClass = dragArr[Object.keys(dragArr)[i]];
                     }
    }

    //background images and texts
    $('#imgContainer').html(img);
    $('#content').html(content);
 
    $(dragClass).draggable({
        revert: 'invalid',          //send img back to its initial position.
        containment: '.main-bg',    //set the boundary that the img cannot pass through it.
        revertDuration: 40          //duration to send img back to its initial position.
    });
          
    //create droppable areas according to page number
    for (var i = 0; i < len; i++) {
        $(dropArr[pgNum][i][0]).droppable({
            accept: dropArr[pgNum][i][1],
            tolerance: 'touch',
            drop: function(event, ui) {
                var imgID = ui.draggable.attr('id');
                
                //another loop to determine which image is dropped so that 
                //it can be recalled later on to check whether dropped or not.                
                imgDropped(imgID);
            }
        });
    }
    
    for (var i = 0 ; i < len; i++) {
        var droppedID = imgIDArr[pgNum][1][i];
        if (droppedID) {
            imgDropped(imgIDArr[pgNum][0][i]);
        }
    }    
    $('#btnPlay').on('click touchend', playFun);
}

//this is needed as there's a play button on each page and they are separated.
//Design for content audio play button and its function
function playFun() {
    $('#popUpID').css({'visibility': 'hidden'});
    //set other play buttons UI to play icon
    $('#btnInstruction, #popUpPlay').playplay();
    btnClicked.btnInsClicked = true; btnClicked.btnPopUpClicked = true; 
    
    if (pgNum !== 6) {
        if (btnClicked.btnCtxtClicked) {
            audio.src = imgObj[Object.keys(imgObj)[pgNum]]; 
            audio.play();
            btnClicked.btnCtxtClicked = false;
            $(this).stopstop();
        } else {
            audio.pause();
            btnClicked.btnCtxtClicked = true;
            $(this).playplay();
        }
    } else {
        //this is in reverse because bool vals are set in btn click function
        if (btnClicked.playBtnClicked) {
            audio.pause();
            $(this).playplay();
        } else {
            audio.play();
            $(this).stopstop();
        }
    }
}

function lastPgAnimation() {
    //don't execute the codes below if instructional audio play button is clicked!!!            
    //timeupdate eventlistener to update the contents and background according to audio time.    
    
    /*if (fileCheck1 === fileCheck2) {
        currentTime = animeTime;
    } else {
        currentTime = this.currentTime;
    }*/
    
    currentTime = this.currentTime;
    switch (Math.floor(currentTime)) {
            //fetch bone
        case 2:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[1]]);
            $('#btnPlay').stopstop();
            break;
            //cupboard
        case 5:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[2]]);
            $('#btnPlay').stopstop();
            break;
            //poor doggo
        case 9:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[3]]);
            $('#btnPlay').stopstop();
            break;
            //hatter
        case 12:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[4]]);
            $('#btnPlay').stopstop();
            break;
            //feeding cat
        case 15:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[5]]);
            $('#btnPlay').stopstop();
            break;
            //wig
        case 19:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[6]]);
            $('#btnPlay').stopstop();
            break;
            //jig
        case 23:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[7]]);
            $('#btnPlay').stopstop();
            break;
            //fruit
        case 27:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[8]]);
            $('#btnPlay').stopstop();
            break;
            //flute
        case 31:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[9]]);
            $('#btnPlay').stopstop();            
            break;
            //coat
        case 35:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[10]]);
            $('#btnPlay').stopstop();
            break;
            //goat
        case 39:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[11]]);
            $('#btnPlay').stopstop();
            break;
            //cobbler
        case 43:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[12]]);
            $('#btnPlay').stopstop();
            break;
            //shoes
        case 47:
            $('.main-bg').html(pg7Obj[Object.keys(pg7Obj)[13]]);
            $('#btnPlay').stopstop();
            break;
        default:
            break;
                                   }
    
    if (Math.floor(currentTime) === 50) {
        pageSeven();
    }
}
//to display complete message upon complete drop.
function popUp() {
    var count = objDrop.count;
    
    switch (count) {
        case 2:
            var audioURL;
            //for page 2 to 6
            if(!$('#bgImg').hasClass('page-0')) {
                if($('#bgImg').hasClass('page-5')) {
                    //popup message and frame here! Great work!
                    $('.main-bg').find('#content').append(popUpMsg.six.msg);
                    audioURL = imgObj.great;
                } else {
                    //add popup divs to html | Good work!
                    $('.main-bg').find('#content').append(popUpMsg.others.msg);                    
                    audioURL = imgObj.good;                    
                }
                
                //show popup message for 1 to 5 here
                audio.addEventListener('ended', function() {
                    if(count === 2) {
                        $('#popUpPlay').stopstop();
                        btnClicked.btnPopUpClicked = false;
                        
                        this.src = audioURL;
                        this.play();
                        count = 0;
                    }
                });
            }
            
			$('#popUpPlay').on('click touchend', popupbtn);
            break;
        case 4:
            
			$('.main-bg').find('#content').append(popUpMsg.others.msg);
			audio.addEventListener('ended', function() {
				if (count === 4) {
					$('#popUpPlay').stopstop();
                    btnClicked.btnPopUpClicked = false;
					this.src = imgObj.good;
					this.play();
					count = 0;
				}
			});
            
			$('#popUpPlay').on('click touchend', popupbtn);
            break;
	}
    
    //hide popup message when close button is clicked.
    $('.btnclose').on('click touchend', function(e) {
        $('#popUpID').css({'visibility': 'hidden'});
        audio.pause();
        
        $('#btnInstruction, #btnPlay, #popUpPlay').playplay();
        btnClicked.btnInsClicked = true; btnClicked.btnCtxtClicked = true;
        btnClicked.btnPopUpClicked = true; btnClicked.playBtnClicked = true;
    });
 }

function popupbtn(e) {
        e.preventDefault();
        btnClicked.btnCtxtClicked = true;
        btnClicked.btnInsClicked = true;
        $('#btnInstruction, #btnPlay').playplay();
        
        if(btnClicked.btnPopUpClicked) {
            $(this).stopstop();
            btnClicked.btnPopUpClicked = false;

            //for page 1 to 5, pg num starts from 0, so it's 5 here.
            if(pgNum !== 5) {
                audio.src = imgObj.good;
                audio.play();
            } else {
                //for page 6    
                audio.src = imgObj.great;
                audio.play();
            }
        } else {
            $(this).find('div').removeClass().addClass('play');
            btnClicked.btnPopUpClicked = true;
            audio.pause();
            audio.load();
        }
}

//position draggable images and run audio
function imgDropped(imgID) {
    
    //dark green background for old mother image
	if (imgID === 'oldMom') {
        $('#drop_oldMom').removeClass('box-cut-img-one').addClass('box-cut-img-one-bg');
    }
    //increase drop count whenever image is dropped
    objDrop.count++;
	
    //reset play buttons when images are dropped
    $('#btnInstruction, #btnPlay').playplay();
    btnClicked.btnInsClicked = true; btnClicked.btnCtxtClicked = true;

    //
    for (var i = 0; i < 14; i++) {
        switch(imgID) {
            case superArr[i][0]:
                $(superArr[i][1]).html(superArr[i][2]);
                $(superArr[i][3]).draggable('disable');
                $(superArr[i][3]).css({
                    'left': superArr[i][4],
                    'top': superArr[i][5],
                    'cursor': 'default'
                });
                audio.src = imgObj[Object.keys(imgObj)[i+6]];
                break;
                    }
    }
    
    var len;
    pgNum === 0 ? len = 4 : len = 2;
    
    //loop to play audio if images are not dropped yet.
    //When page change, if images are dropped, audio won't play.
    for (var j = 0; j < len; j++) {
        if (imgIDArr[pgNum][1][j] === false) {
            audio.play();
            popUp();
        }
    }
    
    //loop to update boolean of the image ID so that dropped image can stay dropped upon page change.
    for (var j = 0; j < len; j++) {
        var droppedID = imgIDArr[pgNum][0][j];
        if (droppedID === imgID) {
            imgIDArr[pgNum][1][j] = true;
        }
    }
}