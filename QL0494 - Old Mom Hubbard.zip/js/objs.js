var btnClicked = {
    btnInsClicked: {click: true},
    btnCtxtClicked: {click: true},
    btnPopUpClicked: {click: true},
    playBtnClicked: {click: true}
};

var objDrop = {count: 0};

//HTML tags for pop-up.
var popUpMsg = {
    others: { msg: '<div id="popUpID" class="pop-up"><div id="popUpPlay" class="circle pop-up-circle"><div class="play"></div></div><div class="content pop-up-content">Good work! Select <strong>next</strong> to continue.</div><div class="btnclose hover">X</div></div>'},
    six: { msg: '<div id="popUpID" class="pop-up"><div id="popUpPlay" class="circle pop-up-circle"><div class="play"></div></div><div class="content pop-up-content">Great work! Select <strong>next</strong> to hear the whole rhyme.</div><div class="btnclose hover">X</div></div>'}
};

//Object for audio file path.
var imgObj = {
    pgOne: 'assets/audio/_1OldMotherHubbard.mp3',
    pgTwo: 'assets/audio/_2ShewenttotheHatters.mp3',
    pgThree: 'assets/audio/_3ShewenttotheBarbers.mp3',
    pgFour: 'assets/audio/_4ShewenttotheFruiterers.mp3',
    pgFive: 'assets/audio/_5ShewenttotheTailors.mp3',
    pgSix: 'assets/audio/_6ShewenttotheCobblers.mp3',
    
    oldMom: 'assets/audio/_oldMom.mp3',
    doggo: 'assets/audio/_dog.mp3',
    bone: 'assets/audio/_bone.mp3',
    cupBoard: 'assets/audio/_cupboard.mp3',
    hat: 'assets/audio/_hat.mp3',
    kittie: 'assets/audio/_cat.mp3',
    wig: 'assets/audio/_wig.mp3',
    jig:  'assets/audio/_jig.mp3',
    flute: 'assets/audio/_flute.mp3',
    fruit:  'assets/audio/_fruit.mp3',
    coat: 'assets/audio/_coat.mp3',
    goat: 'assets/audio/_goat.mp3',
    news: 'assets/audio/_news.mp3',
    shoes:  'assets/audio/_shoes.mp3',
    
    ins16: 'assets/audio/dragthepicture.mp3',
    ins7: 'assets/audio/selectplaytohearrhyme.mp3',
    great: 'assets/audio/greatworkrhyme.mp3',
    good: 'assets/audio/goodwork.mp3',
    all: 'assets/audio/OldMa_mixdown.mp3'
};

//Object for images in image container on the left
var imgConObj = {
    pgOne: '<div id="doggo" class="dog-img img-size" style="cursor: pointer;"></div><div id="bone" class="bone-img img-size" style="cursor: pointer;"></div><div id="oldMom" class="old-mother-hubbard-img img-size" style="cursor: pointer;"></div><div id="cupboard" class="cupboard-img img-size" style="cursor: pointer;"></div>',
    pgTwo: '<div id="cat" class="cat-img img-size" style="cursor: pointer;"></div><div id="hat" class="hat-img img-size" style="margin-top: 5px; cursor: pointer;"></div>',
    pgThree: '<div id="jig" class="jig-img img-size" style="cursor: pointer;"></div><div id="wig" class="wig-img img-size" style="margin-top: 5px; cursor: pointer;"></div>',
    pgFour: '<div id="flute" class="flute-img img-size" style="cursor: pointer;"></div><div id="fruit" class="fruit-img img-size" style="margin-top: 5px; cursor: pointer;"></div>',
    pgFive: '<div id="coat" class="coat-img img-size" style="cursor: pointer;"></div><div id="goat" class="goat-img img-size" style="margin-top: 5px; cursor: pointer;"></div>',
    pgSix: '<div id="news" class="news-img img-size" style="cursor: pointer"></div><div id="shoes" class="shoes-img img-size" style="margin-top: 5px; cursor: pointer;"></div>'
};

// setter - to determine if the image was droped or not - still testing
var imgIDObj = {
    0: {oldMom: {dropped: false},
        doggo: {dropped:false}, bone: false, cupboard: false},
    1: {hat: false, cat: false},
    2: {wig: false, jig: false},
    3: {flute: false, fruit: false},
    4: {coat: false, goat: false},
    5: {news: false, shoes: false}
};

//for if condition check - still testing
var imgIDArr = [
    [['oldMom', 'doggo', 'bone', 'cupboard'], [false, false, false, false]],
    [['hat', 'cat'], [false, false]],
    [['wig', 'jig'], [false, false]],
    [['flute', 'fruit'], [false, false]],
    [['coat', 'goat'], [false, false]],
    [['news', 'shoes'], [false, false]]
];

var pg7Obj = {
    sec1: '<div class="rhyme-content-container"><div id="btnPlay" class="circle" style="left: 55px; top: 110px; position: absolute;"><div class="play"></div></div><div class="text noselect float-left" style="left: 180px; top: 108px; position: absolute;">went to the</div><div class="text noselect float-left" style="left: 408px; top: 108px; position:absolute;">, </div><div class="old-mother-hubbard-img img-size" style="left: 90px; top: 85px; position: absolute;"></div><div class="cupboard-img img-size" style="left: 320px; top: 90px; position: absolute;"></div></div><div id="bgImg" class="main-bg page-6"></div>',
    sec2: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 30px; margin-top: 170px;"><div class="play"></div></div><div class="text noselect float-left" style="left: 70px; top: 168px; position:absolute;">To fetch her poor dog a</div><div class="bone-img img-size" style="left: 360px; top: 145px; position: absolute;"></div></div><div id="bgImg" class="main-bg page-6"></div>',
    sec3: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="left: 55px; top: 60px; position: absolute;"><div class="play"></div></div><div class="text noselect float-left" style="left: 90px; top: 58px; position: absolute;">But when she got there,</div><div class="text noselect float-left" style="left: 180px; top: 110px; position: absolute;">her cupboard was bare,</div></div><div id="bgImg" class="main-bg page-6"></div>',
    sec4: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="left: 25px; top: 160px; position: absolute;"><div class="play"></div></div><div class="text noselect float-left" style="left: 65px; top: 158px; position: absolute;">And so her poor</div><div class="text noselect float-left" style="left: 360px; top: 158px; position: absolute;">had none.</div><div class="dog-img img-size" style="left: 270px; top: 135px; position:absolute;"></div></div><div id="bgImg" class="main-bg page-6"></div>',
    sec5: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 55px; margin-top: 110px;"><div class="play"></div></div><div class="text noselect float-left" style="left: 90px; top: 108px; position:absolute;">She went to the hatter\'s</div><div class="text noselect float-left" style="left: 180px; top: 178px; position:absolute;">to buy him a</div><div class="text noselect float-left" style="left: 430px; top: 178px; position:absolute;">;</div><div class="hat-img img-size" style="left: 350px; top: 155px; position:absolute;"></div></div><div id="bgImg" class="main-bg page-7"></div>',
    sec6: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 15px; margin-top: 110px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 30px; margin-top: 108px;">When she came back,</div><div class="text noselect float-left" style="margin-left: -245px; margin-top: 178px;">he was feeding the</div><div class="text noselect float-left" style="margin-left: 70px; margin-top: 178px;">.</div><div class="cat-img img-size" style="margin-left: 290px; margin-top: 155px;"></div></div><div id="bgImg" class="main-bg page-7"></div>',
    sec7: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 55px; margin-top: 80px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 78px;">She went to the barber\'s</div><div class="text noselect float-left" style="margin-left: -230px; margin-top: 148px;">to buy him a</div><div class="text noselect float-left" style="margin-left: 25px; margin-top: 148px;">;</div><div class="wig-img img-size" style="margin-left: 310px; margin-top: 130px;"></div></div><div id="bgImg" class="main-bg page-8"></div>',
    sec8: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 35px; margin-top: 150px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 148px;">When she came back,</div><div class="text noselect float-left" style="margin-left: -245px; margin-top: 218px;">he was dancing a</div><div class="text noselect float-left" style="margin-left: 45px; margin-top: 218px;">.</div><div class="jig-img img-size" style="margin-left: 285px; margin-top: 200px;"></div></div><div id="bgImg" class="main-bg page-8"></div>',
    sec9: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 5px; margin-top: 80px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 78px;">She went to the fruiterer\'s</div><div class="text noselect float-left" style="margin-left: -250px; margin-top: 148px;">to buy him some</div><div class="text noselect float-left" style="margin-left: 40px; margin-top: 148px;">;</div><div class="fruit-img img-size" style="margin-left: 295px; margin-top: 130px;"></div></div><div id="bgImg" class="main-bg page-9"></div>',
    sec10: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 15px; margin-top: 100px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 15px; margin-top: 98px;">When she came back,</div><div class="text noselect float-left" style="margin-left: -185px; margin-top: 168px;">he was playing the</div><div class="text noselect float-left" style="margin-left: 100px; margin-top: 168px;">.</div><div class="flute-img img-size" style="margin-left: 330px; margin-top: 150px;"></div></div><div id="bgImg" class="main-bg page-9"></div>',
    
    sec11: '<div class="rhyme-content-container float-left" ><div id="btnPlay" class="circle" style="margin-left: 15px; margin-top: 80px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 78px;">She went to the tailor\'s</div><div class="text noselect float-left" style="margin-left: -260px; margin-top: 148px;">to buy him a</div><div class="text noselect float-left" style="margin-left: -5px; margin-top: 148px;">;</div><div class="coat-img img-size" style="margin-left: 230px; margin-top: 130px;"></div></div><div id="bgImg" class="main-bg page-10"></div>',
    
    sec12: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 85px; margin-top: 100px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 98px;">When she came back,</div><div class="text noselect float-left" style="margin-left: -305px; margin-top: 168px;">he was riding a</div><div class="text noselect float-left" style="margin-left: -15px; margin-top: 168px;">.</div><div id="btnPlay" class="goat-img img-size" style="margin-left: 260px; margin-top: 150px;"></div></div><div id="bgImg" class="main-bg page-10"></div>',
    
    sec13: '<div class="rhyme-content-container float-left" ><div id="btnPlay" class="circle" style="margin-left: 15px; margin-top: 80px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 78px;">She went to the cobbler\'s</div><div class="text noselect float-left" style="margin-left: -300px; margin-top: 148px;">to buy him some</div><div class="text noselect float-left" style="margin-left: -5px; margin-top: 148px;">;</div><div id="btnPlay" class="shoes-img img-size" style="margin-left: 245px; margin-top: 130px;"></div></div><div id="bgImg" class="main-bg page-11"></div>',
    
    sec14: '<div class="rhyme-content-container float-left"><div id="btnPlay" class="circle" style="margin-left: 15px; margin-top: 100px;"><div class="play"></div></div><div class="text noselect float-left" style="margin-left: 20px; margin-top: 98px;">When she came back,</div><div class="text noselect float-left" style="margin-left: -245px; margin-top: 168px;">he was reading the</div><div class="text noselect float-left" style="margin-left: 70px; margin-top: 168px;">.</div><div class="news-img img-size" style="margin-left: 280px; margin-top: 150px;"></div></div><div id="bgImg" class="main-bg page-11"></div>'
};

var contentArr = {
    pageOne: '<div id="btnPlay" class="circle" style="left: 5px; top: 40px; position:absolute;"><div class="play"></div></div><div id="oldMom_txt" class="text" style="left: 65px; top: 38px;">Old Mother Hubbard</div><div id="drop_oldMom" class="box-cut-img-one float-left" style="top: 15px; left: 65px; position:absolute"></div><div class="text  float-left" style="left: 310px; top: 37px; position: absolute;">went to the cupboard,</div><div id="drop_bone" class="box-lines-img float-left" style="top: 78px; left: 555px; position:absolute;"></div><div id="bone_txt" class="text " style="left: 270px; top: 100px; position: absolute;">To fetch her poor dog a &nbsp;bone &nbsp;.</div><div id="drop_cupboard" class="box-cut-img float-left" style="top: 145px; left: 422px; position:absolute;"></div><div class="text " style="left: 90px; top: 160px; position: absolute;">But when she got there, her</div><div id="cupboard_txt" class="text  float-left" style="left: 420px; top: 160px; position: absolute;">cupboard</div><div class="text  float-left" style="left: 520px; top: 160px; position: absolute;">was bare,</div><div id="drop_doggo" class="box-lines-img float-left" style="top: 210px; left: 530px; position: absolute;"></div><div id="doggo_txt" class="text" style="left: 335px; top: 230px; position: absolute;">And so her poor &nbsp;dog&nbsp; had none.</div>',
    pageTwo: '<div id="btnPlay" class="circle" style="left: 25px; top: 85px; position:absolute;"><div class="play"></div></div><div id="hat_txt" class="text noselect float-left" style="left: 65px; top: 78px;">She went to the hatter\'s to buy him a &nbsp;hat&nbsp;&nbsp;;</div><div id="drop_hat" class=" box-lines-img float-left" style="left: 515px; top: 55px; position: absolute;"></div><div id="cat_txt" class="text noselect float-left" style="left: 80px; top: 170px; position: absolute;">When she came back, he was feeding the &nbsp;cat&nbsp;&nbsp;.</div><div id="drop_cat" class="box-lines-img float-left" style="left: 545px; top: 150px; position: absolute;"></div>', 
    pageThree: '<div id="btnPlay" class="circle" style="margin-left: 40px; margin-top: 105px;"><div class="play"></div></div><div id="wig_txt" class="text noselect float-left" style="left: 80px; top: 100px; position: absolute;">She went to the barber\'s to buy him a&nbsp;&nbsp;wig&nbsp;&nbsp;;</div><div id="wig_drop" class="box-lines-img float-left" style="left: 535px; top: 80px; position: absolute;"></div><div id="jig_txt" class="text noselect float-left" style="left: 180px; top: 180px; position: absolute;">When she came back, he was dancing a&nbsp;&nbsp; jig&nbsp;&nbsp; .</div><div id="jig_drop" class="box-lines-img float-left" style="left: 650px; top: 165px; position: absolute;"></div>',
    pageFour: '<div id="btnPlay" class="circle" style="margin-left: 9px; margin-top: 80px;"><div class="play"></div></div><div id="fruit_txt" class="text noselect float-left" style="left: 54px; top: 78px; position: absolute;">She went to the fruiterer\'s to buy him some &nbsp;fruit&nbsp;&nbsp;;</div><div id="fruit_drop" class="box-cut-img float-left" style="left: 560px; top: 60px; position: absolute;"></div><div id="flute_txt" class="text noselect float-left" style="left: 30px; top: 166px; position:absolute;">When she came back, he was playing the &nbsp;flute&nbsp;&nbsp;.</div><div id="flute_drop" class="box-cut-img float-left" style="left: 495px; top: 145px; position: absolute;"></div>'        
    , 
    pageFive: '<div id="btnPlay" class="circle" style="margin-left: 54px; margin-top: 110px;"><div class="play"></div></div><div id="coat_txt" class="text noselect float-left" style="left: 104px; top: 108px; position: absolute;">She went to the tailor\'s to buy him a &nbsp;coat&nbsp;&nbsp;;</div><div id="coat_drop" class="box-lines-img float-left" style="left: 545px; top: 90px; position: absolute;"></div>	<div id="goat_txt" class="text noselect float-left" style="left: -5px; top: 190px; position: absolute;">When she came back, he was riding a &nbsp;goat&nbsp;.</div><div id="goat_drop" class="box-lines-img float-left" style="left: 430px; top: 175px; position: absolute;"></div>'        
    ,
    pageSix: '<div id="btnPlay" class="circle" style="margin-left: 20px; margin-top: 110px;"><div class="play"></div></div><div id="shoes_txt" class="text noselect float-left" style="left: 50px; top: 108px; position:absolute;">She went to the cobbler\'s to buy him some &nbsp;shoes&nbsp;&nbsp;;</div><div id="shoes_drop" class="box-cut-img float-left" style="left: 545px; top: 90px; position:absolute;"></div><div id="news_txt" class="text noselect float-left" style="left: 105px; top: 205px; position:absolute;">When she came back, he was reading the  &nbsp;news&nbsp;&nbsp;. </div> <div id="news_drop" class="box-lines-img float-left" style="left: 585px; top: 185px; position:absolute;"></div>'            
};

var main = {
    content: '<div id="imgContainer" class="side-img-container"></div><div id="content" class="content-container float-left"></div><div id="bgImg" class="main-bg page-0"></div>'
};

//object to create draggable codes for image classes
var dragArr = {
    pgOne: '.dog-img, .bone-img, .old-mother-hubbard-img, .cupboard-img',
    pgTwo: '.cat-img, .hat-img',
    pgThree: '.wig-img, .jig-img',
    pgFour: '.flute-img, .fruit-img',
    pgFive: '.coat-img, .goat-img',
    pgSix: '.news-img, .shoes-img'
};

//3D array || object for drop variables
var dropArr = [
    [['#drop_oldMom', '.old-mother-hubbard-img'], 
     ['#drop_doggo', '.dog-img'], ['#drop_bone', '.bone-img'], 
     ['#drop_cupboard', '.cupboard-img']],
    [['#drop_cat', '.cat-img'], ['#drop_hat', '.hat-img']],
    [['#wig_drop', '.wig-img'], ['#jig_drop', '.jig-img']],
    [['#flute_drop', '.flute-img'], ['#fruit_drop', '.fruit-img']],
    [['#coat_drop', '.coat-img'], ['#goat_drop', '.goat-img']],
    [['#news_drop', '.news-img'], ['#shoes_drop', '.shoes-img']]
];

//array for imgDropped function.
var superArr = [
    //class, id, text, class, left, top
    ['oldMom', '#oldMom_txt', '', '.old-mother-hubbard-img', '225px', '-149px'],
    ['doggo', '#doggo_txt', 'And so her poor &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;had none.', '.dog-img', '615px', '210px'],
    ['bone', '#bone_txt', 'To fetch her poor dog a &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.', '.bone-img', '640px', '-4px'],
    ['cupboard', '#cupboard_txt', '', '.cupboard-img', '507px', '-101px'],
    ['hat', '#hat_txt', 'She went to the hatter\'s to buy him a &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;', '.hat-img', '600px', '-27px'],
    ['cat', '#cat_txt', 'When she came back, he was feeding the &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.', '.cat-img', '630px', '150px'],
    ['wig', '#wig_txt', 'She went to the barber\'s to buy him a &nbsp;&nbsp;&nbsp;&nbsp; ;', '.wig-img', '620px', '-2px'],
    ['jig', '#jig_txt', 'When she came back, he was dancing a &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.', '.jig-img', '735px', '165px'],
    ['flute', '#flute_txt', 'When she came back, he was playing the &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.', '.flute-img', '580px', '145px'],
    ['fruit', '#fruit_txt', 'She went to the fruiterer\'s to buy him some &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;', '.fruit-img', '645px', '-22px'],
    ['coat', '#coat_txt', 'She went to the tailor\'s to buy him a  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;', '.coat-img', '630px', '90px'],
    ['goat', '#goat_txt', 'When she came back, he was riding a  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.', '.goat-img', '515px', '93px'],
    ['news', '#news_txt', 'When she came back, he was reading the  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.', '.news-img', '670px', '185px'],
    ['shoes', '#shoes_txt', 'She went to the cobbler\'s to buy him some  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;', '.shoes-img', '630px', '8px']
];

//positions of dropped images, call this when page is recalled.
var fixPos = [
    [['220px', '-149px'], ['675px', '205px'], ['737px', '-4px'], ['567px', '-111px']],
    [['689px', '-30px'], ['790px', '144px']],
    [['794px', '42px'], ['700px', '205px']],
    [['699px', '142px'], ['798px', '-28px']],
    [['793px', '84px'], ['647px', '81px']],
    [['803px', '183px'], ['763px', '2px']]
];

//codes to toggle UI components
$.fn.extend({
    hidden: function() {
        this.css('visibility', 'hidden');
    },
    
    visible: function() {
        this.css('visibility', 'visible');
    }, 
    
    textChange: function(pgNum) {
        if (pgNum === 6) {
            this.find('span').html('Select play to hear the rhyme.');    
        } else {
            this.find('span').html('Drag the picture onto the matching words of the rhyme.');
        }        
    },
    
    playplay: function() {
        this.find('div').removeClass().addClass('play');
    },
    
    stopstop: function() {
        this.find('div').removeClass().addClass('stop');
    },
});