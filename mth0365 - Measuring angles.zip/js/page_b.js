'use strict'

//call this function when the 'Next' button is clicked.
function page_b_fun() {
    //this means page b
	page_a = false;
    //auto set to tab a for both pages.
	tabID = 'a';
    //disable next button
    $('#next').removeClass('hover normal-bg').addClass('disable-bg').prop({disabled: true});
    //modify label style for 3 list items on page b.
    $('#instruction').css({'line-height':'21px'});
    $('#instruction label').append(instruction.textb);
    
    //enable back button
    $('#back').addClass('normal-bg hover').removeClass('disable-bg').prop({disabled: false});
    //Hide elements from page 1.
	$('#c, #d, #e, #f, #popup1, #close1, #input_text, #angles, #degree').css({'visibility': 'hidden'});
    //reveal elements for page 2.
	$('#ray1, #ray2, #lbl, span, #rayl_rotate, #rayr_rotate').css({'visibility':'visible'});
    //relocate green tick position for page 2
	$('#tick').css({'top':'-40px','left':'-80px'});

    //to set page as it is supposed to be
    page_b_tabs(tabID);
    
    //reset protractor on page change
    btnProtractReset();
}

//call this function when CHECK button is clicked on page 2
function check_page_b() {
    //var tabCondition = new pgCondition();
    var popup = $('#popup1');
    var rays = $('#rayr_rotate, #rayl_rotate');
    var tick = $('#tick');
    
    //display popup upon check button click
    $('#popup1, #close1').css({'visibility':'visible'});
    //bot tabs complete
    if (state.page_b.tab_a.complete && state.page_b.tab_b.complete){
        //show both tabs correct message'
        popup.html(popUpMsg.pg2.complete);
        //none completes or either one is compeleted
    } else {
        condition.tab(tabID);
        
        //for popup message - toggle the variables as per selected tab
        var msg = tabID === 'a' ? ' <b>b</b> ' : ' <b>a</b> ';
        var oppoTab = tabID === 'a' ? 'b' : 'a';
        
        //no action on ray buttons has two possibilites: either complete or no action
        if (noAction(rotation.ray)) {
            //if complete
            if(condition.state) {
                popup.html(popUpMsg.pg2.correct1 + msg + popUpMsg.pg2.correct2);
            //if no action    
            } else {
                popup.html(popUpMsg.pg2.noaction);  //show no action message              
            }
        //check correct degree
        } else if (rayDegreeCheck(tabID, rotation.ray)) {
            tick.css({'visibility':'visible'});     //show tick           
            condition.stateB(tabID, true);          //set the bool value to true if correct
            rays.removeClass('hover');              //remove hover from ray buttons
            
            //to check if another tab is complete
            condition.tab(oppoTab);
            //another tab is complete
            if (condition.state) {
                popup.html(popUpMsg.pg2.complete);  
            //incomplete
            } else {
                popup.html(popUpMsg.pg2.correct1 + msg + popUpMsg.pg2.correct2);
            }
        //incorrect
        } else {
            popup.html(popUpMsg.pg2.incorrect);
        }
    }
}

//call this functions when the tabs are clicked.
function page_b_tabs(tabID) {
    //reset ray rotation to ensure incomplete tab works correctly
    rotation.ray = 0 ;
    //remove hover class on mobile devices.
    if(isApple || isAndriod) {
        $('#back').removeClass('hover');
        $('.tab, #rayl_rotate, #rayr_rotate').removeClass('hover');        
        //specific position adjustment for android and iPad
        $('#rayl_rotate').css({'top':'64px'});        
        if(isApple){$('#ray1').css({'left':'65px'});}
        
    } else {
        $('#rayl_rotate, #rayr_rotate').addClass('hover');
    }
  
    //reset effects on all tabs
    $('.tab').removeClass('active-bg').addClass('normal-bg hover');    
    //add effects on clicked tab
    $('#' + tabID).removeClass('normal-bg hover').addClass('active-bg');    
    //hide check popup upon tab change
    $('#popup1, #close1').css({'visibility':'hidden'});
    
    condition.tab(tabID);                   //call tab method
    $('#lbl').html(condition.htmlVal);      //insert 65deg or 140deg accordingly
    
    //set condition to complete if complete
    if (condition.state) {
        condition.pageState(condition.state, condition.completeDegree);
    //incomplete
    } else {
        condition.pageState(condition.state, condition.incompleteDegree);
    }
}

//this function rotates the ray image (blue) to the left in a rate of 5 degress
function rayRotateLeft(){ 
    if(tabID === 'a' && !state.page_b.tab_a.complete || tabID === 'b' && !state.page_b.tab_b.complete){   
        
        rrleft();
        ray_interval = setInterval(rrleft, 100);        
    }
}

function rrleft(){
    // rotation decreases in 5 everytime.
    if(rotation.ray === -360){
        rotation.ray = 0;
    }
    
    rotation.ray -= 5;
    // sample image rotates everytime in a rate of 5 degress.
    $('#ray1').css({'-webkit-transform' : 'rotate('+ rotation.ray +'deg)',
                    '-moz-transform' : 'rotate('+ rotation.ray +'deg)',
                    '-ms-transform' : 'rotate('+ rotation.ray +'deg)',
                    'transform' : 'rotate('+ rotation.ray +'deg)',
                    'transform-origin':'100%'});
}

function rayRotateRight(){ 
    if(tabID === 'a' && !state.page_b.tab_a.complete || tabID === 'b' && !state.page_b.tab_b.complete){        
        rrright();
        ray_interval = setInterval(rrright, 100);
    }
}

function rrright(){
    
    if(rotation.ray === 360){
        rotation.ray = 0;
    }
    
    // rotation increase in 5 everytime.
        rotation.ray += 5;
        // sample image rotates everytime in a rate of 5 degress.
        $('#ray1').css({'-webkit-transform' : 'rotate('+ rotation.ray +'deg)',
                        '-moz-transform' : 'rotate('+ rotation.ray +'deg)',
                        '-ms-transform' : 'rotate('+ rotation.ray +'deg)',
                        'transform' : 'rotate('+ rotation.ray +'deg)',
                        'transform-origin':'100%'});
}