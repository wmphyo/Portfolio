/* Template JS */
/* The State of Queensland (Department of Education and Training) */
'use strict'

var tabID = 'a';
var checkCount = 0; //for popup message after 3 attempts of incorrect input
var rotation = {
    protractor: 0,
    ray: 0 
}
var page_a = true;
var isDesktop = true;       //assume that it will run on Desktop browsers first
var condition = new pgCondition(page_a);

//instruction underneath the header for both pages.
var instruction = {
	text: '1. Drag the protractor over the angle, matching the centre of the protractor to the vertex. <br/> 2. Rotate the protractor until the 0&deg; line matches one arm of the angle.',
    textb: '<div>3. Rotate the blue ray to make the angle shown.</div>'
};

var isAndriod = /Android/i.test(navigator.userAgent);
var isApple = /iPad|iPhone|iPod/i.test(navigator.userAgent);

//array for control | page a needs incorrect state due to 3 times incorrect inputs.
var state = {
	page_a: {
		tab_a: { complete:false, incorrect:false },
		tab_b: { complete:false, incorrect:false },
		tab_c: { complete:false, incorrect:false },
		tab_d: { complete:false, incorrect:false },
		tab_e: { complete:false, incorrect:false },
		tab_f: { complete:false, incorrect:false }
	},
	page_b: {
		tab_a: {complete:false},
		tab_b: {complete:false}
	}
};

//to store correct ray degrees
var rayArray = {
    tab_a: 0,
    tab_b: 0,
}

function pgCondition (){
    //setter - kinda for page a
    this.stateA = function (tabID, complete, incorrect) {
        switch (tabID) {
            case 'a':
                state.page_a.tab_a.incorrect = incorrect;
                state.page_a.tab_a.complete = complete;
                break;
            case 'b':
                state.page_a.tab_b.incorrect = incorrect;
                state.page_a.tab_b.complete = complete;
                break;
            case 'c':
                state.page_a.tab_c.incorrect = incorrect;
                state.page_a.tab_c.complete = complete;
                break;
            case 'd':
                state.page_a.tab_d.incorrect = incorrect;
                state.page_a.tab_d.complete = complete;
                break;
            case 'e':
                state.page_a.tab_e.incorrect = incorrect;
                state.page_a.tab_e.complete = complete;
                break;
            case 'f':
                state.page_a.tab_f.incorrect = incorrect;
                state.page_a.tab_f.complete = complete;
                break;
            default:
                     }
    };
    //setter - kinda for page b
    this.stateB = function (tabID, complete) {
        switch (tabID) {
            case 'a':
                state.page_b.tab_a.complete = complete;
                break;
            case 'b':
                state.page_b.tab_b.complete = complete;
                break;
            default:
                     }
    };    
    //getter - kinda
    this.tab = function(id) {
        if(page_a) {
            switch (id) {
                case 'a':
                    this.complete = state.page_a.tab_a.complete;
                    this.incorrect = state.page_a.tab_a.incorrect;
                    this.val = '30';
                    break;
                case 'b':
                    this.complete = state.page_a.tab_b.complete;
                    this.incorrect = state.page_a.tab_b.incorrect;
                    this.val = '180';
                    break;
                case 'c':
                    this.complete = state.page_a.tab_c.complete;
                    this.incorrect = state.page_a.tab_c.incorrect;
                    this.val = '135';
                    break;
                case 'd':
                    this.complete = state.page_a.tab_d.complete;
                    this.incorrect = state.page_a.tab_d.incorrect;
                    this.val = '130';
                    break;
                case 'e':
                    this.complete = state.page_a.tab_e.complete;
                    this.incorrect = state.page_a.tab_e.incorrect;
                    this.val = '90';
                    break;
                case 'f':
                    this.complete = state.page_a.tab_f.complete;
                    this.incorrect = state.page_a.tab_f.incorrect;
                    this.val = '60';
                    break;
                default:
                      }
        } else {
            switch (id) {
                case 'a':
                    this.state = state.page_b.tab_a.complete;
                    this.htmlVal = '65&deg;';
                    this.completeDegree = rayArray.tab_a;
                    this.incompleteDegree = 0;
                    break;
                case 'b':
                    this.state = state.page_b.tab_b.complete;
                    this.htmlVal = '140&deg;';
                    this.completeDegree = rayArray.tab_b;
                    this.incompleteDegree = 0;
                    break;
                default:
                      }
        }
    };
    
    this.pageState = function (state, deegree) {
        //complete - page a complete is true.
        if (state) {
            $('#tick').css({'visibility':'visible'});
            $('#rayl_rotate, #rayr_rotate').off('click touchend').removeClass('hover');
            $('#ray1').css({'transform':'rotate(' + deegree + 'deg)'});
        //incomplete
        } else {
            $('#tick').css({'visibility':'hidden'});            
            $('#ray1').css({'transform':'rotate(' + deegree + 'deg)'});
        }        
    };
}

var popUpMsg = {
	pg1: {
		empty: 'Enter an amount before you select <b>check</b>.',
		incorrect: 'Make sure you have positioned the protractor carefully and try again.',
		incorrect3: 'Here is the correct answer. Select <b>reset</b> to try measuring this angle again.',
		complete: 'Great work. Select <b>reset</b> to repeat this activity or <b>next</b> to try constructing some angles.',
		correct: 'Correct. Select the next tab.'
	},
	pg2: {
		correct1: 'Great work. Select tab',
		correct2: 'to construct another angle.',
		incorrect: 'Make sure your protractor is positioned accurately then check that the ray is under the correct number.',
		complete: 'Great work. Select <b>reset</b> to repeat this activity or <b>back</b> to repeat the previous activity.',
		noaction: 'Show the angle before you select <b>check<b/>.'		
	}
};

var pro_interval = null;
var ray_interval = null;

/*Function to set input - number only*/
function charLimit() {
        var position = this.selectionStart;
        var start = $('#input_text').val().length;
        this.value = this.value.replace(/[^0-9]+/g, '');
        var final = $('#input_text').val().length;
	
		/*Codes that keep cursor position as it is instead of moving to the end of input*/
        if (start == final) {
            this.selectionEnd = position;
        } else {
            this.selectionEnd = position - 1;
    	}
}

function noAction (rayDegree) {
    if (rayDegree === 0) {
        return true;
    } else {
        return false;
    }
}

function rayDegreeCheck (tabID, rayDegree) {
    if (tabID === 'a') {
        if (rayDegree === 115 || rayDegree === -115 || rayDegree === 245 || rayDegree === -245) {
            rayArray.tab_a = rayDegree;
            return true;
        } else {
            return false;
        }    
    } else {
        if (rayDegree === 40 || rayDegree === -40 || rayDegree === 320 || rayDegree === -320) {
            rayArray.tab_b = rayDegree;
            return true;
        } else {
            return false;
        }
    }    
}