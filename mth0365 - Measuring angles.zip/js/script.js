/* Template JS */
/* The State of Queensland (Department of Education and Training) */

//jQuery - Run on page ready
$(function () {
    
	//Call charlimit function to limit the input num only 
	$('#input_text').on('input', charLimit);
	
	//next button
	$('#next').on('click touchend', page_b_fun);
	
    $('#back').on('click touchend', page_a_fun);
	//reset button
	$('#reset').on('click touchend', btnReset);
	
	//check button
	$('#check').on('click touchend', function(e){
        e.preventDefault();
	
	   //capture input value and add to the variable
	   var inputVal = $('#input_text').val();	
	
        //page 1
	   if(page_a){
           check_page_a(inputVal);
                
	   //page 2
	   } else {    
           check_page_b();
       }
    });
	
	//Reset protractor position button
	$('#protracreset').on('click touchend', btnProtractReset);
	
	//tab actions
	$('#a, #b, #c, #d, #e, #f').on('click touchend', function(e){
        tabID = e.target.id;	             
        
        //Refactor these codes
        if(page_a){            
            page_a_tabs(tabID);            
            //page b
        } else {					            
            page_b_tabs(tabID);            
        }	 
    });
	
	/*----- continuous rotation codes for the protractor inside the following function -----*/
    continuousProRotate();

    /*----- continuous rotation codes for the ray inside the following function-----*/
    continuousRayRotate();
    
	//popup area and close icons on them to hide popup messages
	$('#close1, #popup1').on('click touchend', function(e){
		e.preventDefault();
        
        $('#close1').css({'visibility':'hidden'});
        $('#popup1').css({'visibility':'hidden'});
	});
	    
	//set boundary for protractor
	$('#protractor').draggable({
		containment: '#frame',
	});
	
	//display instruction label onload.
	$('#instruction label').html(instruction.text);
    
    $('#back').addClass('disable-bg').prop({disabled:true});
    
    //remove hover classes
	if (isApple || isAndriod) {
        isDesktop = false;
		$('.hover').removeClass('hover');
        $('#rayl_rotate').css({'top':'23px'});
        
        if (isApple) {
            //Fix weird display of input text box.
            $('#input_text').css({'width':'60px'});
        }
	}
});

//function that includes rayrotation actions (buttons)
function continuousRayRotate(){  
    
    $('#rayr_rotate').on('mousedown touchstart',function(e){
            e.preventDefault();
            rayRotateRight();
        }).on('mouseup mouseleave touchend',function(){
            clearInterval(ray_interval);
        });
        
        $('#rayl_rotate').on('mousedown touchstart',function(e){
            e.preventDefault();
            rayRotateLeft();
        }).on('mouseup mouseleave touchend',function(){
            clearInterval(ray_interval);
        }); 
    
}

//this function includes protractor rotation actions (buttons)
function continuousProRotate(){
  
     $('#rleft').on('mousedown touchstart',function(e) {
            e.preventDefault();
            rotateLeft();
        }).on('mouseup mouseleave touchend', function() {
            clearInterval(pro_interval);
        });
        
        $('#rright').on('mousedown touchstart',function(e) {
            e.preventDefault();
            rotateRight();
        }).on('mouseup mouseleave touchend',function() {
            clearInterval(pro_interval);
        });
}

function rleft() {
    if (rotation.protractor === -360) {
        rotation.protractor = 0;
    }
	// rotation decreases in 5 everytime.
	rotation.protractor -= 5;
    
    // sample image rotates everytime in a rate of 5 degress.
    $('#protractor').css({'-webkit-transform' : 'rotate('+ rotation.protractor +'deg)',
                          '-moz-transform' : 'rotate('+ rotation.protractor +'deg)',
                          '-ms-transform' : 'rotate('+ rotation.protractor +'deg)',
                          'transform' : 'rotate('+ rotation.protractor +'deg)',
                          'transform-origin':'130px 126px'}); 
    //130px and 126px to set the rotation centre at bottom middle
    
}

//this function rotates the protractor anti-clockwise
function rotateLeft(){
    rleft();    
    pro_interval = setInterval(rleft, 100);   	
}

// this function rotates the protractor clockwise
function rotateRight(){
    rright();
    pro_interval = setInterval(rright, 100);
}

function rright(){
    if (rotation.protractor === 360) {
        rotation.protractor = 0;
    }
    
     // rotation decreases in 5 everytime.
    rotation.protractor += 5;
    // sample image rotates everytime in a rate of 5 degress.
    $('#protractor').css({'-webkit-transform' : 'rotate('+ rotation.protractor +'deg)',
                          '-moz-transform' : 'rotate('+ rotation.protractor +'deg)',
                          '-ms-transform' : 'rotate('+ rotation.protractor +'deg)',
                          'transform' : 'rotate('+ rotation.protractor +'deg)',
                          'transform-origin':'130px 126px'});
    //130px and 126px to set the rotation centre at bottom middle
}
//function to reset the values, positions and whatnot.

function btnReset(){
    //reset active tab on page a
    if(page_a){
        $('#input_text').val('').removeClass('disable complete').prop('disabled', false);
        checkCount = 0;
        $('#tick').css({'visibility': 'hidden'});	
        
        condition.stateA(tabID, false, false);
        
      //reset page b
    } else {		
        condition.stateB(tabID, false);        
        
        //add hover if it's not a mobile device
        if(!isApple || !isAndriod){
            $('#rayr_rotate, #rayl_rotate').addClass('hover');    
        }      
        
        $('#tick, #popup1, #close1').css({'visibility':'hidden'});        
        //for further rotate ray button actions
		rotation.ray = 0;        
        //reset blue ray degree to zero
		$('#ray1').css({'transform':'rotate(' + rotation.ray + 'deg)'});      
        //$('#popup1, #close1').css({'visibility':'hidden'});
        btnProtractReset();
        
	}	
}

//function to move protractor to its original position and degree
function btnProtractReset(){    
    //reset rotation value
	rotation.protractor = 0;	
    
	$('#protractor').css({
		'top': '45px',
		'left': '560px'	,
		'transform': 'rotate(' + rotation.protractor + 'deg)'
	});		        
	
}