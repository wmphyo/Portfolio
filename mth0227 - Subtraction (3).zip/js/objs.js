//variables for the loop inside insertCalcCnt function
var loanNumPos = '#loanNum .pos';
var minuendPos = '#minuend .pos';
var subtrahendPos = '#subtrahend .pos';
var differencePos = '#difference .pos';
var noAnimeBOOL = false;
var clkID = 'tab_a';
var checkCount = tabCount = completeCheck = 0;
var dropCompleteBool = pageCompleteBool = animeBool = false;    //to check page status

var popupMsg = {
    tabClk: '<span>Complete the algorithm and <strong>check</strong> before you select the next tab.</span>',
    checkClk: '<span>Complete the algorithm before you <strong>check</strong>.',
    incorrect: '<span>Keep trying.</span>',
    correct: '<span>Select the next tab.</span>',
    complete: '<span>That seals it! You\'re super on subtraction. Select <strong>reset</strong> to do the activity again.</span>'
};

//correct values - will be used to check against inserted input values
var inputVals = [
    ['', '', '', '', '4', ''],
    ['', '', '', '5', '2', '1'],
    ['6', '9', '10', '9', '6', '1'],
    ['5', '9', '10', '3', '6', '2'],
    ['4', '9', '10', '3', '3', '3'],
    ['', '', '', '', '', '3'],
    ['2', '9', '10', '1', '8', '2'],
    ['8', '9', '10', '7', '6', '4']
];

//to check which tab is active and their completeness
var tabs = [
    ['tab_a', false],
    ['tab_b', false],
    ['tab_c', false],
    ['tab_d', false],
    ['tab_e', false],
    ['tab_f', false],
    ['tab_g', false],
    ['tab_h', false]
];

//to control input boxes - total number of input box and total number of correct input boxes
var inputCtrl = [1, 3, 6, 6, 6, 1, 6, 6];

//to check how many slashes are dropped
var dropBOOL = [false, false, false];

/*Function to set input - number only*/
function charLimit() {
        var position = this.selectionStart;
        var start = $('input').val().length;
        this.value = this.value.replace(/[^0-9]+/g, '');
        var final = $('input').val().length;
	
		/*Codes that keep cursor position as it is instead of moving to the end of input*/
        if (start == final) {
            this.selectionEnd = position;
        } else {
            this.selectionEnd = position - 1;
    	}
};

//arrays for the contents
var loanNumContents = [
    ['<span>1</span>', '<span>9</span>', '<span>10</span>'],
    ['<span>3</span>', '<span>9</span>', '<span>10</span>'],
    ['<input id="input1" class="inputs">', '<input id="input2" class="inputs">', '<input id="input3" class="inputs">'],
    ['<input id="input1">', '<input id="input2">', '<input id="input3">'],
    ['<input id="input1">', '<input id="input2">', '<input id="input3">'],
    ['<span>7</span>', '<span>9</span>', '<span>10</span>'],
    ['<input id="input1">', '<input id="input2">', '<input id="input3">'],
    ['<input id="input1">', '<input id="input2">', '<input id="input3">'],
];

var minuendContents = [
    ['<span>2</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>4</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>7</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>6</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>5</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>8</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>3</span>', '<span>0</span>', '<span>0</span>'],
    ['<span>9</span>', '<span>0</span>', '<span>0</span>'],
];

var subtrahendContents = [
    ['<span>1</span>', '<span>5</span>', '<span>6</span>'],
    ['<span>2</span>', '<span>7</span>', '<span>5</span>'],
    ['<span>5</span>', '<span>3</span>', '<span>1</span>'],
    ['<span>3</span>', '<span>3</span>', '<span>7</span>'],
    ['<span>1</span>', '<span>6</span>', '<span>7</span>'],
    ['<span>4</span>', '<span>1</span>', '<span>8</span>'],
    ['', '<span>1</span>', '<span>9</span>'],
    ['<span>4</span>', '<span>3</span>', '<span>3</span>'],
];

var differenceContents = [
    ['', '<input id="input5">', '<span>4</span>'],
    ['<input id="input6">', '<input id="input5">', '<input id="input4">'],
    ['<input id="input6">', '<input id="input5">', '<input id="input4">'],
    ['<input id="input6">', '<input id="input5">', '<input id="input4">'],
    ['<input id="input6">', '<input id="input5">', '<input id="input4">'],
    ['<input id="input6">', '<span>8</span>', '<span>2</span>'],
    ['<input id="input6">', '<input id="input5">', '<input id="input4">'],
    ['<input id="input6">', '<input id="input5">', '<input id="input4">'],
];

var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;

function init() {
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");
	var comp=AdobeAn.getComposition("2F24AFDBD5AAFE4B84E68275ACF50049");
	var lib=comp.getLibrary();
	handleComplete({},comp);
}

function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	exportRoot = new lib.sealFinal();
	stage = new lib.Stage(canvas);
	stage.addChild(exportRoot);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {
		var lastW, lastH, lastS=1;
		window.addEventListener('resize', resizeCanvas);
		resizeCanvas();
		function resizeCanvas() {
			var w = lib.properties.width, h = lib.properties.height;			
			var iw = window.innerWidth, ih=window.innerHeight;			
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;		
		}
	}
	makeResponsive(false,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}

var container = document.getElementsByClassName('inputs');
container.onkeyup = function(e) {
    var target = e.srcElement || e.target;
    var maxLength = parseInt(target.attributes["maxlength"].value, 10);
    var myLength = target.value.length;
    if (myLength >= maxLength) {
        var next = target;
        while (next = next.nextElementSibling) {
            if (next == null)
                break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }
}

var isAndroid = /Android/i.test(navigator.userAgent);
var isApple = /iPad|iPhone|iPod/i.test(navigator.userAgent);

//to handle UI designs and effects in Mobile devices.
function mobileDevices() {
    if (isApple || isAndroid) {
        $('.hover').removeClass('hover');
        
        if(isApple) {
            $('input').addClass('iOS');
        } else {
            $('.drop1').addClass('droid');
            $('.drop2').addClass('droid');
            $('.drop3').addClass('droid');
        }
    }
}