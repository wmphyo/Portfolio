/* Template JS */
/* The State of Queensland (Department of Education and Training) */

//jQuery - Run on page ready
$(function () {
    
    insertCalcCnt(0);
    slashes();
    mobileDevices();
    
    $('#popup, #slashFrame, #tick, .slash4').css({'visibility':'hidden'});
    
    $('.tabs').on('click touchend', function(e) {
        e.preventDefault();

        //when tab is complete, change to a new one
        if (pageCompleteBool) {
            clkID = e.currentTarget.id;
            tabChange(clkID);
        } else {
            //generate popup message only when clicking on non-active tab
            if(!$(this).hasClass('active')) {
                $('#msg').html(popupMsg.tabClk);
                $('#popup').css({'visibility':'visible'});
            }
        }
    });
    
    $('input').on('click touchend', function(e){
        $('#popup').css('visibility', 'hidden');
    });
    
    //NEED TO insert slash drop complete!!!!!
    $('#btnCheck').on('click touchend', function(e) {
        var inputC = 0;
        
        //assign first array value as per tab
        for (var i = 0; i < 8; i++) {
            if (clkID === tabs[i][0]) {
                //to define which tab is active in numerical value & assign number as per the active tab
                var fArrVal = i;
                var pgCheck = tabs[i][1];
            }
        }
        
        if (pgCheck === false) {
            
            var totalInputBoxNum = 6;
            for (var i = 0; i < totalInputBoxNum; i++) {
                var inputVal = i + 1;
                
                /*Inserted input value is equal to correct value inside the inputVals array.
                if YES, increase count to check against total number of complete inputs and 
                disable the complete input.*/
                if ($('#input'+inputVal).val() === inputVals[fArrVal][i]) {
                    inputC++;
                    $('#input'+inputVal).attr('disabled', 'disabled');
                }
            }
            
            //SET the status of the page true / complete
            if (inputC === inputCtrl[fArrVal]) {
                //for animation steps
                checkCount++;
                //set page completion BOOL true as all inputs are correct
                tabs[fArrVal][1] = true;
                //pageCompleteBool is for individual page
                pageCompleteBool = animeBool = true;
                $('#tick').css({'visibility':'visible'});
            }
            
            //check if an input box is left empty so that check button message can be displayed.
            for (var i = 0; i < totalInputBoxNum; i++) {
                if ($('#input'+i).val() === '') {
                    var yesEmpty = true;
                }
            }
            
            //input field is empty
            if (yesEmpty) {
                //display check button message - complete the algorithm...
                $('#msg').html(popupMsg.checkClk);
            //input field has values
            } else {
                //inputs are correct
                if (tabs[fArrVal][1] === true) {
                    //display 'select the next tab message'
                    $('#msg').html(popupMsg.correct);
                    //disable slash draggablity upon completion of current page
                    $('.slash4').draggable('disable').removeClass('hover');
                //inputs are incorrect
                } else {
                    //display keep trying message
                    $('#msg').html(popupMsg.incorrect);
                    //loop to clear input fields that hold incorrect values
                    for (var i = 0; i < totalInputBoxNum; i++) {
                        var inputVal = i + 1;
                        if ($('#input'+inputVal).val() !== inputVals[fArrVal][i]) {
                            $('#input'+inputVal).val('');
                        }
                    }
                }
            }
        }
        
        //Check completion of all tabs
        completeCheck = 0;
        for (var i = 0; i < 8; i ++) {
            if (tabs[i][1] === true) {
                completeCheck++;
            }
        }
        
        //all tabs are correct and complete
        if (completeCheck === 8) {
            //insert complete message
            $('#msg').html(popupMsg.complete);
            //noAnimeBOOL = true;
        }
        //display popup message container
        $('#popup').css({'visibility':'visible'});
    });
    
    //reset the contents of a particular tab and rewind one step in animation.
    $('#btnReset').on('click touchend', function (e) {
        e.preventDefault();
        
        //when all tabs are complete, reload the entire LO.
        if (completeCheck === 8) {
            
            location.reload();
            
        } else {
            
            //there will be two possibilities - when page is complete or page is yet to complete
            if (pageCompleteBool) {                
                checkCount--;
                animeBool = true;
                pageCompleteBool = false;
                $('#tick').css({'visibility':'hidden'});
                $('.slash4').draggable('enable').addClass('hover');
                
                //reset active tab BOOL value
                for (var i = 0; i < 8; i++) {
                    if (clkID === tabs[i][0]) {
                        tabs[i][1] = false;
                    }
                }
            }
            slashes();            
            //reset slash drop values
            for (var i = 0; i < 3; i++) {
                dropBOOL[i]=false;
            }            
            $('#popup').css({'visibility':'hidden'});
            $('input').val('').removeAttr('disabled');            
        }        
    });
    
    $('#popup, #close').on('click touchend', function(e) {
         $('#popup').css({'visibility':'hidden'});
    });
});

//works when .tab is clicked / when tab changes.
function tabChange(clk) {
    
    for (var i = 0; i < 8; i++) {
        if(clk === tabs[i][0]) {
            insertCalcCnt(i);               //insert numbers and/or input boxes
            var tabCompletion = tabs[i][1]; //to check if tab is complete
        }
    }
    
    //tab is complete, reposition the complete values
    if (tabCompletion === true) {
        
        completedTab();
        
    //tab is incomplete
    } else {
        
        for (var i = 0; i < 3; i++) {
            dropBOOL[i]=false;
        }    
        
        //reset complete bool val upon tab change.
        pageCompleteBool = false;
        $('#popup, #tick').css({'visibility':'hidden'});
        slashes();
        
        //insert draggable function for slash here!
        $('.slash4').draggable({
                revert: 'invalid',
                revertDuration: 0,
                containment: '#frame'
            });
        
        $("#drop1").droppable({
                accept: '.slash',
                tolerance: 'intersect',
                drop: function (event, ui) {
                    slashDrop('drop1');
                    }
                });
        
        $("#drop2").droppable({
                accept: '.slash',
                tolerance: 'intersect',
                drop: function (event, ui) {
                    slashDrop('drop2');
                }
            });
        
        $("#drop3").droppable({
                accept: '.slash',
                tolerance: 'intersect',
                drop: function (event, ui) {
                    slashDrop('drop3');
                }
            });
    }
    
    //style for tabs
    $('.active').removeClass('active').addClass('hover');
    $('#' + clk).removeClass('hover').addClass('active');
    mobileDevices();    //to adjust UI in mobile devices.
}

//function to position slash dropped
function slashes() {
    
    //initialise the disabled draggability first
    $('.slash4').draggable({'disabled':true});
    
    for (var i = 1; i < 4; i++) {
        
        if (clkID === 'tab_a' || clkID === 'tab_b' || clkID === 'tab_f') {
        
            $('.slash4').css({'visibility':'hidden'});            
            $('.drop'+ i).css({'visibility':'visible'});
            $('#slashFrame').css({'visibility':'hidden'});
                
        } else {
            
            $('.slash4').css({'visibility':'visible'});
            $('.drop' + i).css({'visibility':'hidden'});
            $('#slashFrame').css({'visibility':'visible'});
            $('.slash4').draggable('enable').addClass('hover');

        }
    }
}

function slashDrop(droppedID) {
    $('.slash4').css({
        'top':'35px',
        'left':'-175px'
    });
    
    switch(droppedID) {
        case 'drop1':
            dropBOOL[0] = true;
            $('.drop1').css({'visibility':'visible'});
            break;
        case 'drop2':
            dropBOOL[1] = true;
            $('.drop2').css({'visibility':'visible'});
            break;
        case 'drop3':
            dropBOOL[2] = true;
            $('.drop3').css({'visibility':'visible'});
            break;
                    }
    
    var dropCount = 0;
    
    //check if all slashes are dropped
    for (var i = 0; i < 3; i ++) {
        if (dropBOOL[i] === true) {
            dropCount++;
        }
        
        //turn on drop complete bool var if all slashes are dropped
        if (dropCount === 3) {
            dropCompleteBool = true;
            $('.slash4').draggable({'disabled':true}).removeClass('hover');
        }
    }
}

//called inside tabChange function / insert contents in calculation area
function insertCalcCnt (arrPos) {
    
    for (var i = 0; i < 3; i++) {
        var posVal = i + 1;
        $(loanNumPos + posVal).html(loanNumContents[arrPos][i]);
        $(minuendPos + posVal).html(minuendContents[arrPos][i]);
        $(subtrahendPos + posVal).html(subtrahendContents[arrPos][i]);
        $(differencePos + posVal).html(differenceContents[arrPos][i]);
    }
    
    //number only input
    $('input').on('input', charLimit).attr('type', 'text');
    //turn off auto complete or showing previous inputs in Chrome
    $('input').attr('autocomplete', 'off');
    $('input').addClass('classic-font');
    
    //set specific digit number for input boxes
    for (var i = 0; i < 6; i++) {
        var inputVal = i + 1;
        if (inputVal === 3) {
            $('#input' + inputVal).attr({maxlength:2});
        } else {
            $('#input' + inputVal).attr({maxlength:1});
        }
    }
}

//to set the values upon tab call if page is complete
function completedTab () {
    
    slashes();
    pageCompleteBool = dropCompleteBool = true;
    $('#tick').css({'visibility':'visible'});
    $('#popup').css({'visibility':'hidden'});
    
    if (dropCompleteBool) {
        $('.drop1, .drop2, .drop3').css({'visibility':'visible'});
        $('.slash4').draggable('disable').removeClass('hover');
    }
    
    var totalInputBoxNum = 6;
    var totalTabNum = 8;
      
    //assign first array value as per tab
    for (var i = 0; i < totalTabNum; i++) {
        if (clkID === tabs[i][0]) {
            var fArrVal = i;
        }
    }
    
    for (var i = 0; i < totalInputBoxNum; i++) {
        
        var inputVal = i + 1;
        if (inputVals[fArrVal][i] !== '') {
            
            $('#input'+inputVal).val(inputVals[fArrVal][i]);
            $('#input'+inputVal).attr('disabled', 'disabled');
        
        } else {
            
            $('#input'+inputVal).val('');
        }
    }
}