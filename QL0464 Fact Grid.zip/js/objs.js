/*This file contain objects and extended functions that serve as jQuery libraries.*/

//store classes for hovering on clicked friends
var hoArrClkFris = [
	['ho-cell', 'hover-fris', 'ho-cell hover-fris'],
	['ho-count', 'ho-ccfris', 'ho-ccfris ho-count'],
	['ho-cs', 'ho-scfc', 'ho-scfc ho-cs'],
	['ho-add', 'ho-aclk-f', 'ho-add ho-aclk-f'],
	['ho-ca', 'ho-caclk-f', 'ho-ca ho-caclk-f'],
	['ho-cas', 'ho-casclk-f', 'ho-cas ho-casclk-f'],
	['ho-sa', 'ho-asclk-f', 'ho-sa ho-asclk-f'],
	['ho-selected', 'ho-sf', 'ho-selected ho-sf']
];

//store classes for hovering on clicked cell.
var hoArrClk = [
	['ho-clicked', 'ho-cell', 'ho-clicked ho-cell'],
	['ho-count', 'ho-cc', 'ho-count ho-cc'],
	['ho-add', 'ho-ac', 'ho-ac ho-add'],
	['ho-ca', 'ho-caclk', 'ho-caclk ho-ca'],
	['ho-cs', 'ho-csclk', 'ho-cs ho-csclk'],
	['ho-selected', 'ho-sc', 'ho-selected ho-sc'],
	['ho-cas', 'ho-casclk', 'ho-cas ho-casclk'],
	['ho-sa', 'ho-asc', 'ho-sa ho-asc']
];

//store classes for cell head hover classes
var hoHeadArr = [
    ['ho-head', 'ho-hc', 'ho-hc ho-head'],
    ['ho-sch', 'ho-hs', 'ho-sch ho-hs']
];

//store classes for hover loop
var hoLoopArr = [
	['clicked', 'ho-clicked', 'clicked ho-clicked'],
	['clicked-fris', 'hover-fris', 'clicked-fris hover-fris'],
	['count', 'ho-count', 'count ho-count'],
	['count-clicked', 'ho-cc', 'count-clicked ho-cc'],
	['count-clik-f', 'ho-ccfris', 'count-clik-f ho-ccfris'],
	['count-add', 'ho-ca', 'count-add ho-ca'],
	['count-selected', 'ho-cs', 'count-selected ho-cs'],
	['count-as', 'ho-cas', 'count-as ho-cas'],
	['count-sclk', 'ho-csclk', 'count-sclk ho-csclk'],
	['count-sclk-f', 'ho-scfc', 'count-sclk-f ho-scfc'],
	['count-asclk', 'ho-casclk', 'count-asclk ho-casclk'],
	['count-asclk-f', 'ho-casclk-f', 'count-asclk-f ho-casclk-f'],
	['count-aclk', 'ho-caclk', 'count-aclk ho-caclk'],
	['count-aclk-f', 'ho-caclk-f', 'count-aclk-f ho-caclk-f'],	
	['selected-add', 'ho-sa', 'selected-add ho-sa'],
	['add-clicked', 'ho-ac', 'add-clicked ho-ac'],
	['add-clicked-fris', 'ho-aclk-f', 'add-clicked-fris ho-aclk-f'],
	['add-sclk', 'ho-asc', 'add-sclk ho-asc'],
	['add-s-f', 'ho-asclk-f', 'add-s-f ho-asclk-f'],
	['selected-fris', 'ho-sf', 'selected-fris ho-sf'],
	['selected-clicked', 'ho-sc', 'selected-clicked ho-sc']
];

//store classes for add 9
var add9Arr = [
    ['count', 'count-add', 'count-add count'],
    ['count-selected', 'count-as', 'count-selected count-as'],
    ['count-clicked', 'count-aclk', 'count-clicked count-aclk'],
    ['count-clik-f', 'count-aclk-f', 'count-clik-f count-aclk-f'],
    ['count-sclk', 'count-asclk', 'count-sclk count-asclk'],
    ['count-sclk-f', 'count-asclk-f', 'count-sclk-f count-asclk-f'],
    ['clicked', 'add-clicked', 'clicked add-clicked'],
    ['clicked-fris', 'add-clicked-fris', 'clicked-fris add-clicked-fris'],
    ['selected-clicked', 'add-sclk', 'selected-clicked add-sclk'],
    ['selected-fris', 'add-s-f', 'selected-fris add-s-f']
];

//store classes for count on
var countArr = [
	['clicked', 'count-clicked', 'clicked count-clicked'],
	['clicked-fris', 'count-clik-f', 'clicked-fris count-clik-f'],
	['selected-fris', 'count-sclk-f', 'selected-fris count-sclk-f'],
	['selected-clicked', 'count-sclk', 'selected-clicked count-sclk'],
	['add-clicked-fris', 'count-aclk-f', 'add-clicked-fris count-aclk-f'],
	['add-clicked', 'count-aclk', 'add-clicked count-aclk'],
	['add-s-f', 'count-asclk-f', 'add-s-f count-asclk-f'],
	['add-sclk', 'count-asclk', 'add-sclk count-asclk'],
	['selected-add', 'count-as', 'selected-add count-as']
];

//this need revisit!
var headClik = [
    ['count', 'count-selected', 'count count-selected'],	
    ['count-add', 'count-as', 'count-add count-as'],	
	['clicked', 'selected-clicked', 'clicked selected-clicked'],
	['clicked-fris', 'selected-fris', 'clicked-fris selected-fris'],
	['count-clicked', 'count-sclk', 'count-clicked count-sclk'],
	['count-clik-f', 'count-sclk-f', 'count-clik-f count-sclk-f'],
	['count-aclk', 'count-asclk', 'count-aclk count-asclk'],
	['count-aclk-f', 'count-asclk-f', 'count-aclk-f count-asclk-f'],
	['add-clicked', 'add-sclk', 'add-clicked add-sclk'],
	['add-clicked-fris', 'add-s-f', 'add-clicked-fris add-s-f']
];

//stores classes for clicked removal
var removeClik = [
    ['count-asclk', 'count-asclk count-as'],
    ['count-sclk', 'count-sclk count-selected'],
    ['count-aclk', 'count-aclk count-add'],
    ['count-clicked', 'count-clicked count'],
    ['add-sclk', 'add-sclk selected-add'],
    ['ho-clicked', 'ho-clicked ho-cell'],
    ['ho-sc', 'ho-selected ho-sc'],
    ['ho-cc', 'ho-cc ho-count'],
    ['ho-csclk', 'ho-csclk ho-cs'],
    ['ho-ac', 'ho-ac ho-add'],
    ['ho-caclk', 'ho-caclk ho-ca'],
    ['ho-asc', 'ho-asc ho-sa'],
    ['ho-casclk', 'ho-casclk ho-cas']
];

var deSelectArr = [
    ['count-clik-f', 'count-clik-f count'],
    ['count-aclk-f', 'count-aclk-f count-add'],
    ['add-s-f', 'add-s-f selected-add'],
    ['count-sclk-f', 'count-sclk-f count-selected'],
    ['count-asclk-f', 'count-asclk-f count-as'],
    ['hover-fris', 'hover-fris ho-cell'],
    ['ho-sf', 'ho-sf ho-selected'],
    ['ho-scfc', 'ho-scfc ho-cs'],
    ['ho-aclk-f', 'ho-aclk-f ho-add'],
    ['ho-asclk-f', 'ho-asclk-f ho-sa'],
    ['ho-caclk-f', 'ho-caclk-f ho-ca'],
	['ho-casclk-f', 'ho-casclk-f ho-cas'],
	['ho-ccfris', 'ho-ccfris ho-count']
];

var headHLRemoveArr = [
    ['head-clicked', 'head-clicked head-bg']    ,
    ['selected-ch', 'selected-ch head-selected'],
    ['ho-hc', 'ho-head ho-hc'],
    ['ho-sch', 'ho-sch ho-hs']
];

var hoveredArr = [
    ['head-clicked', 'ho-hc', 'ho-hc head-clicked'],
    ['head-selected', 'ho-hs', 'head-selected ho-hs'],
    ['selected-ch', 'ho-sch', 'selected-ch ho-sch']
];

var headClassArr = [
    ['head-clicked', 'selected-ch', 'head-clicked selected-ch'],    
    ['head-selected', 'head-bg', 'head-selected head-bg']
];

var arrIMG = [
    ['nearTens', 'double1-near', 'double1-near double1', 'assets/images/double1.png'],
    ['makeTen', 'double-make', 'double-make doubles', 'assets/images/doubles.png'],
    ['doubles', 'double-make', 'double-make makeTen', 'assets/images/make10.png'],
    ['double1', 'double1-near', 'double1-near nearTens', 'assets/images/nearTens.png']
];

var mSelectArr = [
    ['count', 'count-clik-f', 'count count-clik-f'],
    ['count-selected', 'count-sclk-f', 'count-selected count-sclk-f'],
    ['count-add', 'count-aclk-f', 'count-add count-aclk-f'],
    ['count-as', 'count-asclk-f', 'count-as count-asclk-f'],
    ['selected-add', 'add-s-f', 'selected-add add-s-f']
];

//preload images
var preload_img = [
    'assets/images/btnDouble1.png',
    'assets/images/btnDoubles.png',
    'assets/images/double1.png',
    'assets/images/double1Near.png',
    'assets/images/doubleMake.png',
    'assets/images/doubles.png',
    'assets/images/make10.png',
    'assets/images/nearTens.png',
    'assets/images/makeAdd.png',
    'assets/images/nearAdd.png'
];

var len = preload_img.length;
var img = new Image();

for (var i = 0; i < len; i++) {
    img.src = preload_img[i];
}

$.fn.extend({
    //check classes in cell heads and toggle classes accordingly. 
    //works when hovering on cell head
    headClass: function () {
        for (var i = 0; i < headClassArr.length; i++) {
            if (this.hasClass(headClassArr[i][0])) {
                this.toggleClass(headClassArr[i][2]);
            } else if (this.hasClass(headClassArr[i][1])) {
                this.toggleClass(headClassArr[i][2]);
            }            
        }    
    },
    
    //count on btn
    countOn: function (roVal, colVal) {
        //loop for condition check that has similar nature
        for (var i = 0; i < countArr.length; i++) {
            if (this.hasClass(countArr[i][0])) {
                this.toggleClass(countArr[i][2]);
            } else if (this.hasClass(countArr[i][1])) {
                this.toggleClass(countArr[i][2]);
            } else {
                //row or col selected
                //this must be inside the loop. 
                //otherwise, it will case error when clicked then count on.
                if (this.hasClass('rowSelected')) {
                    this.toggleClass('count-selected rowSelected');
                } else if (this.hasClass('colSelected')) {
                    this.toggleClass('count-selected colSelected');
                } else if (this.hasClass('count-selected')) {
                    if (this.hasClass('row')) {
                        this.toggleClass('rowSelected count-selected');
                    } else if (this.hasClass('col')) {
                        this.toggleClass('colSelected count-selected');
                    }
                } else if (this.hasClass('add')) {
                    this.toggleClass('count-add');
                } else {
                    this.toggleClass('count');
                }
            }
        }
    },
    
    //add 9 btn |
    addNine: function () {
        this.toggleClass('add');
        
        //to check classes
        for (var i = 0; i < add9Arr.length; i++) {
            if (this.hasClass(add9Arr[i][0])) {
                this.toggleClass(add9Arr[i][2]);
            } else if (this.hasClass(add9Arr[i][1])) {
                this.toggleClass(add9Arr[i][2]);
            }
        }
        
        //row or col head selected | this has to be separated to avoid error.
        if (this.hasClass('rowSelected')) {
            this.toggleClass('selected-add rowSelected');
        } else if (this.hasClass('colSelected')) {
            this.toggleClass('selected-add colSelected');
        } else if (this.hasClass('selected-add')) {
            if(this.hasClass('row')) {
                this.toggleClass('rowSelected selected-add');
            } else {
                this.toggleClass('colSelected selected-add');
            }
        } else if (this.hasClass('makeTen')) {
            
            var imgAttr = this.find('img').attr('src');
            imgAttr = imgAttr.substr(imgAttr.lastIndexOf('/') + 1);
            
            if (imgAttr === 'make10.png') {
                this.find('img').attr('src', 'assets/images/makeAdd.png');
            } else if (imgAttr === 'makeAdd.png') {
                this.find('img').attr('src', 'assets/images/make10.png');
            }
            
        } else if (this.hasClass('nearTens')) {
            var imgAttr = this.find('img').attr('src');
            imgAttr = imgAttr.substr(imgAttr.lastIndexOf('/') + 1);            
            
            if (imgAttr === 'nearTens.png') {
                this.find('img').attr('src', 'assets/images/nearAdd.png');
            } else if (imgAttr === 'nearAdd.png') {
                this.find('img').attr('src', 'assets/images/nearTens.png');
            }
        }
    },
    
    //hovering on inner cells
    cellHovered: function (id, row, col) {
        var cellID = id; var rowVal = row; var colVal = col;
        
        //need to separate as two to resolve hover conflict
        var colHead = $('#c' + colVal);
        var rowHead = $('#r' + rowVal);        
            
        //otherwise, it will highlight both row and col head for one class
        rowHead.hovered(); colHead.hovered();
        
        //this one need '<=' to highlight pointer hovered cell
        for (var i = 0; i <= rowVal; i++) {
            var cell =  $('#r' + i + 'c' + colVal);
            cell.hoverLoop();
        }
        
        for (var i = 0; i < colVal; i++) {
            var cell =  $('#r' + rowVal + 'c' + i);
            cell.hoverLoop();
        }
    },
        
    //loop inside cellHovered
    hoverLoop: function () {
        //hover on:
        //put repetitive codes inside array and loop them for better maintenance.
        for (var i = 0; i < hoLoopArr.length; i++) {
            if (this.hasClass(hoLoopArr[i][0])) {
                this.toggleClass(hoLoopArr[i][2]);
            } else if (this.hasClass(hoLoopArr[i][1])) {
                this.toggleClass(hoLoopArr[i][2]);
            } else {
                //head selected | this must be inside the loop.
                //otherwise, it will add ho-cell classes to cells when hover out.
                if (this.hasClass('rowSelected')) {
                    this.toggleClass('ho-selected rowSelected');
                } else if (this.hasClass('colSelected')) {
                    this.toggleClass('ho-selected colSelected');
                } else if (this.hasClass('ho-selected')) {
                    if (this.hasClass('col')) {
                        this.toggleClass('colSelected ho-selected');
                    } else {
                        this.toggleClass('rowSelected ho-selected');
                    }
                } else if (this.hasClass('add')) {
                    this.toggleClass('ho-add');
                } else {
                    this.toggleClass('ho-cell');
                }
            }
        }        
    },
    
    //for hovering effect on cell heads | inside cellHovered function above
    hovered: function () {
        for (var i = 0; i < hoveredArr.length; i++) {
            if (this.hasClass(hoveredArr[i][0])) {
                this.toggleClass(hoveredArr[i][2]);
            } else if (this.hasClass(hoveredArr[i][1])) {
                this.toggleClass(hoveredArr[i][2]);
            } else {
                this.toggleClass('head-bg ho-head');
            }
        }
    },
       
    //click on inner cells - doing | Yet to complete
    clickedInside: function (row, col, getID) {
        var row = row; var col = col;
        var clickedCell = $('#' + getID);
        
        //highlight row and col heads
        var rowHead = $('#r' + row); var colHead = $('#c' + col);
    
        //need to include isTouchDevice here to get correct display on touch on inner cells.    
        if (isMobile || isTouchDevice) {
            
            //rowHead.m_headHighlight(); colHead.m_headHighlight();
            rowHead.m_headHighlight(); colHead.m_headHighlight();
            clickedCell.m_highlight();
            
            //highlight columns
            for (var i = 0; i < row; i++) {         //#r i, #c col
                var cell = $('#r' + i + 'c' + col);
                cell.m_select();
            }
            
            //highlight rows
            for (var i = 0; i < col; i++) {         //#r row, #c i
                var cell = $('#r' + row + 'c' + i);
                cell.m_select();
            }
        } else {
            //Need to separate this to avoid error.
            rowHead.headHighlight(); colHead.headHighlight();
            //highlight for clicked cell.
            clickedCell.highlight();
            
            //highlight columns
            for (var i = 0; i < row; i++) {         //#r i, #c col
                var cell = $('#r' + i + 'c' + col);
                cell.select();
            }
            
            //highlight rows
            for (var i = 0; i < col; i++) {         //#r row, #c i
                var cell = $('#r' + row + 'c' + i);
                cell.select();
            }
        }
    },
    
    //inner function of cellClicked to highlight the cells (clicked-fris) upon inner cell click.
    select: function () {
        for (var i = 0; i < hoArrClkFris.length; i++) {
            if (this.hasClass(hoArrClkFris[i][0])) {
                this.toggleClass(hoArrClkFris[i][2]);
            } else if (this.hasClass(hoArrClkFris[i][1])) {
                this.toggleClass(hoArrClkFris[i][2]);
            }
        }    
    },        
    
    m_select: function () {
        
       for (var i = 0; i < mSelectArr.length; i++) {
            if (this.hasClass(mSelectArr[i][0])) {
                this.toggleClass(mSelectArr[i][2]);
            } else if (this.hasClass(mSelectArr[i][1])) {
                this.toggleClass(mSelectArr[i][2]);
            } else if (this.hasClass('colSelected')) {
                this.toggleClass('colSelected selected-fris');
            } else if (this.hasClass('rowSelected')) {
                this.toggleClass('rowSelected selected-fris');
            } else if (this.hasClass('selected-fris')) {
                if (this.hasClass('col')) {
                    this.toggleClass('colSelected selected-fris');
                } else {
                    this.toggleClass('rowSelected selected-fris');
                }
            }        
           else if (this.hasClass('add')) {
               this.toggleClass('add-clicked-fris');
           } else {
               this.toggleClass('clicked-fris');
           }   
       }
    },
    
    //for clicked (inner) cell.
    highlight: function () {
        for (var i = 0; i < hoArrClk.length; i++){
            if (this.hasClass(hoArrClk[i][0])){
                this.toggleClass(hoArrClk[i][2]);
            } else if (this.hasClass(hoArrClk[i][1])) {
                this.toggleClass(hoArrClk[i][2]);
            }
        }
    },
    
    //This can't follow loop code style
    //So, did the 'if' sequences to get this working!
    m_highlight: function () {
        
        if (this.hasClass('count')) {
            this.toggleClass('count count-clicked');
        } else if(this.hasClass('count-clicked')) {
            this.toggleClass('count count-clicked');
        } 
        
        else if (this.hasClass('count-selected')) {
            this.toggleClass('count-selected count-sclk');
        } else if (this.hasClass('count-sclk')) {
            this.toggleClass('count-selected count-sclk');
        }
        
        else if (this.hasClass('count-as')) {
            this.toggleClass('count-as count-asclk');
        } else if (this.hasClass('count-asclk')) {
            this.toggleClass('count-as count-asclk');
        }
        
        else if (this.hasClass('count-add')) {
            this.toggleClass('count-add count-aclk');
        } else if (this.hasClass('count-aclk')) {
            this.toggleClass('count-add count-aclk');
        } 
        
        else if (this.hasClass('selected-add')) {
            this.toggleClass('selected-add add-sclk');
        } else if (this.hasClass('add-sclk')) {
            this.toggleClass('selected-add add-sclk');
        }
        
        else if (this.hasClass('rowSelected')) {
            this.toggleClass('rowSelected selected-clicked');
        } else if (this.hasClass('colSelected')) {
            this.toggleClass('colSelected selected-clicked');
        } else if (this.hasClass('selected-clicked')) {
            if (this.hasClass('col')) {
                this.toggleClass('colSelected selected-clicked');
            } else {
                this.toggleClass('rowSelected selected-clicked');
            }
        }
        
        else if (this.hasClass('add')) {
            this.toggleClass('add-clicked');
        }
        else {
            this.toggleClass('clicked');    
        }
    },
    
    //to highlight cell heads upon inner cell click, called in cellClick(x, y, zID) function
    //can't be merged with headclass
    headHighlight: function () {
        //hovering on cell head
        for (var i = 0; i < hoHeadArr.length; i++){
            if (this.hasClass(hoHeadArr[i][0])){
                this.toggleClass(hoHeadArr[i][2]);
            } else if (this.hasClass(hoHeadArr[i][1])){
                this.toggleClass(hoHeadArr[i][2]);
            }
        }
    },
    
    m_headHighlight: function(){  
        if(this.hasClass('head-selected')) {
            this.toggleClass('head-selected selected-ch');
        } else if (this.hasClass('selected-ch')) {
            this.toggleClass('head-selected selected-ch');
        } else {
            this.toggleClass('head-clicked head-bg');
        }
    },
    
    //used in 3rd click of cellClick(x, y, zID) function
    clickedRemoveHL: function(getID) {
        
        var regExpNum = /[0-9]+/g;
        selectedNum = getID.match(regExpNum);              //Extract number
        
        var row = selectedNum[0]; var col = selectedNum[1];
        var clickedCell = $('#' + getID);
        var rowHead = $('#r' + row); var colHead = $('#c' + col);
        
        rowHead.headHLRemove(); colHead.headHLRemove();
        
        clickedCell.removeHL();
        
        //remove highlights from row
        for (var i = 0; i < row; i++) {
            var cell = $('#r' + i + 'c' + col);
            cell.deSelect();
        }
        
        //remove highlights from col
        for (var i = 0; i < col; i++) {
            var cell = $('#r' + row + 'c' + i);
            cell.deSelect();
        }
    },
    
    //to remove highlighted inner cell (clicked fris) | used in clickedRemoveHL
    deSelect: function() {
        
        for (var i = 0; i < deSelectArr.length; i++) {
            if (this.hasClass(deSelectArr[i][0])) {
                this.toggleClass(deSelectArr[i][1]);
            } else if (this.hasClass('add-clicked-fris')) {
                this.removeClass('add-clicked-fris');
            } else if (this.hasClass('selected-fris')) {
                if (this.hasClass('col')) {
                    this.toggleClass('selected-fris colSelected');
                } else {
                    this.toggleClass('selected-fris rowSelected');    
                }  
            } else {
                this.toggleClass('clicked-fris');
            }   
        }
    },
    
    //to remove highlights from previous 'clicked cell' | used in clickedRemoveHL
    removeHL: function() {
        
        //clicked on
        for (var i = 0; i < removeClik.length; i++) {
            if (this.hasClass(removeClik[i][0])) {
                this.toggleClass(removeClik[i][1]);
            } //add 9
            else if (this.hasClass('add-clicked')) {
                this.removeClass('add-clicked');
            } else {
                //head selected
                if (this.hasClass('selected-clicked')) {
                    if (this.hasClass('col')) {
                        this.toggleClass('selected-clicked colSelected');
                    } else {
                        this.toggleClass('selected-clicked rowSelected');
                    }
                } else {
                    this.removeClass('clicked');
                }
            }
        }
    },
    
    //to remove head highlights from previous click | used in clickedRemoveHL
    headHLRemove: function () {
        for (var i = 0; i < headHLRemoveArr.length; i++) {
            if (this.hasClass(headHLRemoveArr[i][0])) {
                this.toggleClass(headHLRemoveArr[i][1]);
            }
        }
    },
    
    //for highlighting and selecting inner cells upon hovering or clicking on CELLHEAD.
    clicked: function (head, cellID) {
        
        for (var i = 0; i < 11; i++) {
            var cell;
            //because we are trying to capture the other cell head
            if (head === 'r') {
                headID = '#c'; cell = $('#' + cellID + 'c' + i);                               
                cell.toggleClass('row');        //to identify which is clicked
                
            } else {
                headID = '#r'; cell =  $('#r' + i + cellID);
                cell.toggleClass('col');        //to identify which is clicked
                
            }            
            //to capture the other head - i.e. if click on row head, capture column head.
            var cellHead = $(headID + i);           
            
            if (cell.hasClass('count')) {
                cell.toggleClass('count-selected count');
            } else if (cell.hasClass('count-selected')) {
                //for action - count on, row, col or count on, col, row
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('count count-selected');
                }
            }
            //for count on and add 9
            else if (cell.hasClass('count-add')) {
                cell.toggleClass('count-as count-add');
                
            } else if (cell.hasClass('count-as')) {
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('count-add count-as');
                }
            }
            //for clicked inner cell
            else if (cell.hasClass('clicked')) {
                cell.toggleClass('clicked selected-clicked');
                
            } else if (cell.hasClass('selected-clicked')) {
                //for situation 
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('selected-clicked clicked');
                }
            }
            //for clicked fris
            else if (cell.hasClass('clicked-fris')) {
                cell.toggleClass('selected-fris clicked-fris');
            } else if (cell.hasClass('selected-fris')) {
                //for situation - clicked inner cell, click row and col head, click different row or col
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('clicked-fris selected-fris');
                }
            }
            //for clicked + count on
            else if (cell.hasClass('count-clicked')) {
                cell.toggleClass('count-sclk count-clicked');
                
            } else if (cell.hasClass('count-sclk')) {
                if(!cellHead.hasClass('clik')) {
                    cell.toggleClass('count-clicked count-sclk');
                }
            }
            //for clicked fris + count on
            else if (cell.hasClass('count-clik-f')) {
                cell.toggleClass('count-sclk-f count-clik-f');
                
            } else if (cell.hasClass('count-sclk-f')) {
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('count-clik-f count-sclk-f');
                }
            }
            //for clicked + count + add 
            else if (cell.hasClass('count-aclk')) {
                cell.toggleClass('count-asclk count-aclk');
            } else if (cell.hasClass('count-asclk')) {
                //to resolve # 346
                //if (head === 'r' && !cell.hasClass('col') || head === 'c' && !cell.hasClass('row'))
                    cell.toggleClass('count-aclk count-asclk');
            }
            //for clicked fris + count + add
            else if (cell.hasClass('count-aclk-f')) {
                cell.toggleClass('count-asclk-f count-aclk-f');
            } else if (cell.hasClass('count-asclk-f')) {
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('count-aclk-f count-asclk-f');
                }
            }
            //for clicked cell + add
            else if (cell.hasClass('add-clicked')) {
                cell.toggleClass('add-sclk add-clicked');
            } else if (cell.hasClass('add-sclk')) {
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('add-clicked add-sclk');
                }
            }
            //for clicked cell fris + add
            else if (cell.hasClass('add-clicked-fris')) {
                cell.toggleClass('add-s-f add-clicked-fris');
            } else if (cell.hasClass('add-s-f')) {
                if (!cellHead.hasClass('clik')) {
                    cell.toggleClass('add-clicked-fris add-s-f');
                }
            } else if (cell.hasClass('selected-add')) {
                if (!cellHead.hasClass('clik')) {
                        cell.toggleClass('selected-add');
                }
            }
            else if (cell.hasClass('add')) {
                cell.toggleClass('selected-add');
            }
            else {
                //if cell head got selected, swap selected classes.
                if (cellHead.hasClass('clik')) {
                    //to resolve error ID 345
                    if (head === 'r' && cell.hasClass('col')) {
                        if (!cell.hasClass('colSelected')) {
                            cell.toggleClass('rowSelected colSelected');
                        }
                    } else if (head === 'c' && cell.hasClass('row')) {
                        if (!cell.hasClass('rowSelected')) {
                            cell.toggleClass('colSelected rowSelected');
                        }
                    }
                } else {
                    if(head === 'r') {
                        cell.toggleClass('rowSelected');                            
                    } else {
                        cell.toggleClass('colSelected');
                    }
                }
            }   //
        }
    },
    
    //button 'Near tens'
    nearTens: function () {
        if (this.hasClass('double1')) {
            this.toggleClass('double1 double1-near');
            this.find('img').attr('src', 'assets/images/double1Near.png');
        } else if (this.hasClass('add')) {
            this.toggleClass('nearTens');
            this.append('<img src=\'assets/images/nearAdd.png\' />');
            
        } else {
            this.toggleClass('nearTens');
            this.append('<img src=\'assets/images/nearTens.png\' />');
            
        }
    },
    
    //button 'Make 10'
    make10: function () {
        if (this.hasClass('doubles')) {
            this.toggleClass('doubles double-make');            
            this.find('img').attr('src', 'assets/images/doubleMake.png'); 
            
        } else if (this.hasClass('add')) {
            this.toggleClass('makeTen');
            this.append('<img src=\'assets/images/makeAdd.png\' />');
            
        } else {
            
            this.toggleClass('makeTen');            
            this.append('<img src=\'assets/images/make10.png\' />');
             
        }
        
    },
       
    //button 'Doubles + 1'
    double1: function () {
        if (this.hasClass('nearTens')) {
            this.toggleClass('nearTens double1-near');
            this.find('img').attr('src', 'assets/images/double1Near.png');
        } else {
            this.toggleClass('double1');
            this.append('<img src=\'assets/images/double1.png\' />');
        }
    },

    //button 'Doubles'
    doubles: function() {    
        if (this.hasClass('makeTen')) {
            this.toggleClass('makeTen double-make');
            this.find('img').attr('src', 'assets/images/doubleMake.png');
        } else {
            this.toggleClass('doubles');
            this.append('<img src=\'assets/images/doubles.png\' />');
        }
    },
    
    removeIMG: function(btn) {
        for (var i = 0; i < arrIMG.length; i++) {
            if (btn === arrIMG[i][0]) {
                if (this.hasClass(arrIMG[i][1])) {
                    this.toggleClass(arrIMG[i][2]);
                    this.find('img').attr('src', arrIMG[i][3]);
                } else {
                    this.toggleClass(arrIMG[i][0]);
                    this.find('img').remove();
                }
            }
        }  
    }
});
