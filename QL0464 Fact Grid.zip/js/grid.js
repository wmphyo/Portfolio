var _showFact = _doubles = _makeTen = _nearTens = _doubles1 = true;

//arrays to capture the ID of clicked cells and check whether the same cell is clicked.
var _array = {
    rowArr: [],
    colArr: []
}

//var clickedID, roro, coco;
var clickedID;
var _arrLen;

//for Mobile devices
var isMobile = /iPad|iPhone|iPod|Android/i.test(navigator.userAgent);
var isApple = /iPad|iPhone|iPod/i.test(navigator.userAgent);
var isDroid = /Android/i.test(navigator.userAgent);

//for Safari browser
var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

//for Window tablet
var isTouchDevice = 'ontouchstart' in window || (navigator.msMaxTouchPoints>0);
var processing = true;      //for touch control purpose in Window tablet!

var clickedArr = [];

var innerCells, cellHeads, cellFact, cellFactBot, cellFactRight;

/*Function for cell head selection. Selection will highlight its rows or cols
Don't need to highlight the cells in the following function because cells are 
selected by cellGridHover function below. This function mainly manage the clicks and work with hover function accordingly*/
function cellHeadClick(id) {
    
    var selectedHead, selectedNum;
    
    var cellID = id; var head = $('#' + cellID);
    var regExpStr = /[^0-9]+/g; var regExpNum = /[0-9]+/g;

    selectedHead = regExpStr.exec(cellID).toString();   //Extract r or c
    selectedNum = regExpNum.exec(cellID);               //Extract number
    
    //row selected
    if (selectedHead === 'r') {
        var _arr = _array.rowArr; _arrLen = _arr.push(cellID);
        var headSelected = $('.rowHead.head-selected, .rowHeadLast.head-selected');
        var headClickedSelected = $('.rowHead.selected-ch');        
        var clikmgmt = $('.rowHead, .rowHeadLast');      //to manage the clik class inside cellheads
        
    //col selected
    } else {
        var _arr = _array.colArr; _arrLen = _arr.push(cellID);
        var headSelected = $('.colHead.head-selected, .colHeadLast.head-selected');
        var headClickedSelected = $('.colHead.selected-ch');
        var clikmgmt = $('.colHead, .colHeadLast');
    }
    
    //first click
    if (_arrLen < 2) {
        //to capture which head is clicked and use in hover function below.
        head.addClass('clik');
        
        if (isMobile || isTouchDevice) {
            head.headClass();
            head.clicked(selectedHead, cellID);
        }

    //second click
    } else {
        
        //same cell head
        if (_arr[0] === _arr[1]) {
            head.removeClass('clik');
            if (isMobile || isTouchDevice) {
                head.headClass();
                head.clicked(selectedHead, cellID);
            }
            selectedHead === 'r' ? _array.rowArr = [] : _array.colArr = [];
            
        //different cell head
        } else {
            
            clikmgmt.removeClass('clik');
            head.addClass('clik');
            
            //remove cell head with clicked effect
            headSelected.removeClass('head-selected').addClass('head-bg');
            
            //to remove selected-clicked-head class upon (different) cell click
            headClickedSelected.toggleClass('selected-ch head-clicked');
            
            //remove highlights from previous cells
            head.clicked(selectedHead, _arr[0]);
            head.headClass();
            
            if (isMobile || isTouchDevice) {head.clicked(selectedHead, cellID);}
            
            //manage array for click control purpose.
            selectedHead === 'r' ? _array.rowArr.shift() : _array.colArr.shift();
        }
    }
    processing = true;
}

//To highlight inner cells
function cellClick(ro, co, getID) {
    var row = ro; var col = co;
    var cell = $('#' + getID);
    
    //to check or control inner cell clicks
    clickedArr.push(getID);
    var _arrLen = clickedArr.length;
    
    //first click
    if (_arrLen < 2) {
        
        cell.clickedInside(row, col, getID);
        
    //second click
    } else {
        //same cell head
        if (clickedArr[0] === clickedArr[1]) {
            cell.clickedInside(row, col, getID);
            clickedArr = [];
            
        //different cell head
        } else {
            //had to seperate it (different from cell head click) due to the changes in 
            //classes. clickedInside works with hover classes and when clicking on a new 
            //cell, there are no hover effect on the previous clicked cell.
            
            //remove previous selected inner cells
            cell.clickedRemoveHL(clickedArr[0]);
            //highlight inner cells again (new)
            cell.clickedInside(row, col, getID);
            
            clickedArr.shift();
        }
    }
    
    processing = true;
    
}

//Hover effect on grid cells
function cellGridHoverFun() {
    //for hovering on inner cells
    var rowVal, colVal;
    
    var regExpNum = /\d+/g;         //to define which NUMBER of row or col is selected
    var regExpStr = /[^0-9]+/g;     //to define whether ROW or COL is selected
    
    $('.lastCell, .cellFactBot, .cellFactRight, .cellFact').hover(function(e) {    
        e.preventDefault();
        var cellID = e.currentTarget.id;
        var row_col_val = cellID.match(regExpNum);
        
        rowVal = row_col_val[0];
        colVal = row_col_val[1];
        
        $(this).cellHovered(cellID, rowVal, colVal);
        
    //unhovering function
    }, function(e) {
        e.preventDefault();
        var cellID = e.currentTarget.id;
        var row_col_val = cellID.match(regExpNum);
        
        rowVal = row_col_val[0];
        colVal = row_col_val[1];
        
        $(this).cellHovered(cellID, rowVal, colVal);
    });
    
    //hovering on cell heads
    $('.rowHead, .rowHeadLast, .colHead, .colHeadLast').hover(function(e) {
        e.preventDefault();
        var cellID = e.currentTarget.id;
        var rowCol = cellID.match(regExpStr).toString();
        var head = $('#' + cellID);
        
        //won't toggle the highlights if cellhead has clik class
        if (!head.hasClass('clik')) {
            head.headClass();
            head.clicked(rowCol, cellID);
        }
        
    }, function(e) {
        var cellID = e.currentTarget.id;
        var rowCol = cellID.match(regExpStr).toString();
        var head = $('#' + cellID);
        
        if (!head.hasClass('clik')) {
            head.headClass();
            head.clicked(rowCol, cellID);
        }
    });
}

/*To change button label and display cells*/
function btnShow() {
    
    //to remove the clicked cell and its associates when 'Show the...' button is clicked.
    if (clickedArr.length !== 0) {
        var cell = $('#' + clickedID);
        
        //remove previous selected inner cells
        cell.clickedRemoveHL(clickedArr[0]);
        clickedArr.shift();    
    }
    
	//clear display area upon show the facts / number button click
	document.getElementById('displayArea').innerHTML = '';
	
	if(_showFact) {
		_showFact = false;
        /*Btn display - Show the numbers*/
		$('#btnShow').find('span').html('Show the numbers');
		$('#btnShow').addClass('num').removeClass('fact');
		
		/*Loop to change display values to x + y*/
		for (var rn = 0; rn < 11; rn++) {
			for(var cn = 0; cn < 11; cn++) {
				$('#r' + rn + 'c' + cn).find('span').html(rn + ' + ' +  cn);
			}
		}
		
		//Add + sign to cell number 1 for 'Show the number'
		$('#cellOne').html('<span> + </span>');
	} else {
		/*Btn display - Show the facts*/
		_showFact = true;
		$('#btnShow').find('span').html('Show the facts');
		$('#btnShow').addClass('fact').removeClass('num');
		
		for (var rn = -1; rn < 11; rn++) {
			for(var cn = -1; cn < 11; cn++) {
				var sum = cn + rn;
				$('#r' + rn + 'c' + cn).find('span').html(sum);
			}
		}
		$('#cellOne').html('');
	}    
}

/*To create cells and its content, 
i.e. numbers, variables start from -1 to include column and row headings.*/
function createCells() {
	var count = 0;
	/*Get columns in first row sorted, then go to next row | loop for rows*/
	for (var row_num = -1; row_num < 11; row_num++) {
		/*Loop to create columns*/
		for(var col_num = -1; col_num < 11; col_num++) {
            
			if (col_num === -1 && row_num === -1){
				/*Remove 0 from first cell*/
				$('#mid_right').append('<div class=\"firstCellFact\" id="cellOne"></div>');
			} else if(row_num === -1) {
				//cell with special border | 2px 2px 1px 1px;
				if (col_num === 10) {
					$('#mid_right').append('<div class=\"colHeadLast head-bg\" id=\"c' + col_num + '\"><span>' + col_num + '</span></div>');
				} else {
					/*Remove -1 from top cells and add grey bg | For cells at the top*/
					$('#mid_right').append('<div class=\"colHead head-bg\" id=\"c' + col_num + '\"><span>' + col_num + '</span></div>');
				}
			} else if (col_num === -1) {
				if (row_num === 10) {
					$('#mid_right').append('<div class=\"rowHeadLast head-bg\" id=\"r' + row_num + '\"><span>' + row_num + '</span></div>');
				} else {
					/*Remove -1 from far left cells and add grey bg | For cells on the far left*/
					$('#mid_right').append('<div class=\"rowHead head-bg\" id=\"r' + row_num + '\"><span>' + row_num + '</span></div>');
				}
			} else {
				var sum = row_num + col_num;
				if (col_num === 10) { 
					if (row_num === 10) {
						$('#mid_right').append('<div class=\"lastCell\" id=\"r' + row_num + 'c' + col_num + '"><span>' + sum + '</span></div>');
					} else {
						$('#mid_right').append('<div class=\"cellFactRight\" id=\"r' + row_num + 'c' + col_num + '"><span>' + sum + '</span></div>');
					}
				} else if (row_num === 10) {
					$('#mid_right').append('<div class=\"cellFactBot\" id=\"r' + row_num + 'c' + col_num + '"><span>' + sum + '</span></div>');
				} else {
					$('#mid_right').append('<div class=\"cellFact\" id=\"r' + row_num + 'c' + col_num + '"><span>' + sum + '</span></div>')
				}
			}
		}
		$('#mid_right').append('<br/>');
	}
}

/*To get cell values and display - continue*/
function getCellValue() {
	//capture HTML element ID with event.target thru classes.
	$('.cellFact, .cellFactBot, .lastCell, .cellFactRight').on('click touchend', function(e) {
		e.preventDefault();
		var getID = e.currentTarget.id;
        
        //save this here for 'btnShow' click function to remove clicked cell and it's associates upon 'Show the...' btn click.
		clickedID = getID;
        
		//regular expression to extract row and colum
		var regExp = /[0-9]+/g;
		
		//insert row value (number) by removing r
		var row = parseInt(regExp.exec(getID));
		//insert col value (number) by removing c
		var col = parseInt(regExp.exec(getID));
        roro = row;
        coco = col;
		var sum = row + col;
        
        //For 'Show the facts
	   if (_showFact) {
           $('#displayArea').html('<div id="firstrow"><div class="first"><span>' + row + ' + ' + col + ' = ' + sum + '</span></div>' + 
		  '<div class="second"><span>' + sum + ' - ' + col + ' = ' + row + '</span></div></div>' + 
		  '<div id="secondrow"><div class="first"><span>' + col + ' + ' + row + ' = ' + sum + '</span></div>' + 
		  '<div class="second"><span>' + sum + ' - ' + row + ' = ' + col + '</span></div></div>');
	   //For 'Show the numbers'
	   } else {
           $('#displayArea').html('<div id="showNumTot" class="dis"><span>' + row + ' + ' + col + ' = ' + sum + '</span></div>');
	   }
    
        if (processing) {
            processing = false;
            console.log(processing);
            //function to highlight innercells.
            cellClick(row, col, getID);
            //console.log(processing);
        } else {
            return;
        }
        
        //function to highlight innercells.
        //cellClick(row, col, getID);
	});
}

$(document).ready(function () {
    //create cells upon page load.
	createCells();

	//Counting on 0, 1, 2, 3 button
	$('#btnCount').on('click touchend', function(e) {
        e.preventDefault();
        $(this).toggleClass('btn-clicked');
        
        //add background - first 4 rows and their 11 cols
        for (var i = 0; i < 4; i++) {
            //add background - 11 cols
            for (var j = 0; j < 11; j++) {
                var cells = $('#r' + i + 'c' + j);
                //check 11 cols and  4 rows
                cells.countOn(i, j);
            }
        }
        
        //add background - last 7 rows  and 4 cols 
        //(first 4 rows has been highlighted in previous loop)
        for (var a = 4; a < 11; a++) {
            //add backkground - first 4 cols
            for (var b = 0; b < 4; b++) {
                var cells = $('#r' + a + 'c' + b);
                //check 4 cols and 7 rows;
                cells.countOn(a, b);
            }
        }
    });
	
	//Near tens button
	$('#btnNearTens').on('click touchend', function(e) {
        e.preventDefault();
        $(this).toggleClass('btn-clicked');
        
        var r = 1;
        var c = 10;
        if (_nearTens) {
            _nearTens = false;
            for (var i = 0; i < 11; i++) {
                $('#r' + r + 'c' + c).nearTens();
                r++;
                c--;
            }
            if (isApple) {
                $('img').addClass('isApple');
            } else if(isSafari) {
                $('img').addClass('isSafari');
            }
        } else {
            _nearTens = true;
            //need loop to remove every image tag in every corresponding cells.
            for (var i = 0; i < 11; i++) {
                $('#r' + r + 'c' + c).removeIMG('nearTens');
                r++;
                c--;
            }
        }
	});
	
	//Make 10 button
	$('#btnMake').on('click touchend', function (e) {
        e.preventDefault();
        $(this).toggleClass('btn-clicked');
        
        var c = 10;
        if (_makeTen) {
            _makeTen = false;
            for (var i = 0; i < 11; i++) {
                $('#r' + i + 'c' + c).make10();
                c--;
            }
              
            if(isApple) {
                $('img').addClass('isApple');
            } else if(isSafari) {
                $('img').addClass('isSafari');
            }
        } else {
            _makeTen = true;
            for (var i = 0; i < 11; i++) {
                $('#r' + i + 'c' + c).removeIMG('makeTen');       
                c--;
            }
        }
	});
	
	//Doubles button
	$('#btnDoubles').on('click touchend', function(e) {
        e.preventDefault();
        $(this).toggleClass('btn-clicked');
        
        if (_doubles) {
            _doubles = false;
            for (var i = 0; i < 11; i++){
                $('#r' + i + 'c' + i).doubles();
            }
            if(isApple) {
                $('img').addClass('isApple');
            } else if(isSafari){ 
                $('img').addClass('isSafari');
            }
        } else {
            _doubles = true;
            for (var i = 0; i < 11; i++) {
                $('#r' + i + 'c' + i).removeIMG('doubles');
            }
        }
	});
	
	//Doubles + 1 button
	$('#btnDoublesPlusOne').on('click touchend', function(e) {
        e.preventDefault();
        $(this).toggleClass('btn-clicked');
        
        var r = 1;      //1 to 10
        var c = 0;      //0 to 9
        if(_doubles1) {
            _doubles1  = false;
            for (var i = 0; i < 11; i++) {
                $('#r' + r + 'c' + c).double1();
                $('#r' + c + 'c' + r).double1();
                r++; c++;
            }
            if(isApple){ 
                $('img').addClass('isApple');
            } else if (isSafari){ 
                $('img').addClass('isSafari');
            }
        } else {
            for (var i = 0; i < 11; i++){
                _doubles1 = true;
                $('#r' + r + 'c' + c).removeIMG('double1');
                $('#r' + c + 'c' + r).removeIMG('double1');
                r++; c++;
            }
        }        
	});
	
	//Adding 9 button
	$('#btnAdding').on('click touchend', function(e) {
        e.preventDefault();
		$(this).toggleClass('btn-clicked');
        
        //loop to add bg class for Add nine button.
        for (var i = 0; i < 11; i++){            
            $('#r' + i + 'c' + 9).addNine();
            $('#r' + 9 + 'c' + i).addNine();            
        }
        //cus the loop toggled class at r9c9;
        $('#r9c9').addNine();
	});
	
	//Reset button
	$('#btnReset').on('click touchend', function() {
		 window.location.reload();
	});
    
	//Show the facts - Show the numbers button
	$('#btnShow').on('click touchend', function(e) {
        e.preventDefault();
		btnShow();
	});
	
    //click on the cell heads.
    $('.rowHead, .rowHeadLast, .colHead, .colHeadLast').on('click touchend', function(e) {
        e.preventDefault();
        if (processing) {
            processing = false;
            cellHeadClick(e.currentTarget.id);    
        } else {
            return;
        }        
    });
	
    $('#btnPrint').on('click touchend', function(e) {
        e.preventDefault(); 
        window.print();
    });    
    
    //isTouchDevice is implemented to disable cell hover in Window Tablet.
    if (isMobile || isTouchDevice) {
        $('#btnPrint').addClass('mobile');
        $('#btnShow').addClass('mobile');
        
        //add hover effect to buttons for window tablet.
        if(isTouchDevice) {
            $('#btnShow, #btnPrint, #btnReset, .btn').addClass('hover');
        }
    } else {
        cellGridHoverFun();
        $('#btnShow, #btnPrint, #btnReset, .btn').addClass('hover');
    }
    
    if(isDroid) {
        $('.btn').addClass('isDroid');
        $('#frame').addClass('scrollable');
        //added to adjust the positioning of the text as per QA2 feedback.
        $('#btnReset span').css({'top':'3px'});
    }
    
	//Get celll value to display on display panel
	getCellValue();
});