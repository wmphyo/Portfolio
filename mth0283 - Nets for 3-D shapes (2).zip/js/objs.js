var droppedBOOL = false;
var clkID = 'tab_a';
var anNum = 0;
var svgObj = 'rectPriSVG';

//message inside popup container.
var popupMsg = {
    tabClk: 'Select the shape that forms the base of the 3-D shape before selecting the next tab.',
    correctDrop: 'That\'s correct. Select the shape that forms the base of the 3-D shape.',
    correctSelect: 'Good! Select the next tab.',
    complete:'You\'re in great shape! Select <strong>reset</strong> to do the activity again.'
};

//array that holds id of draggable buttons
var dragID = ['rectPri', 'cylin', 'triPyr', 'squPyr', 'cube', 'cone'];

//array that holds top value for dropped buttons
var topVal = ['45px', '96px', '249px', '147px',  '198px', '-6px'];

//array that holds tab values and their bool
var tabVal = [
    ['tab_a', false],
    ['tab_b', false],
    ['tab_c', false],
    ['tab_d', false],
    ['tab_e', false],
    ['tab_f', false]
];

//last image of GIF files for complete tabs
var completedGIF = ['rectPriL', 'cylinL', 'triPyrL', 'squPyrL', 'cubeL', 'coneL'];

//mini functions
$.fn.extend ({
    //remove hover class for active tab
    active: function() {
        this.removeClass('hover');
        this.addClass('active');
    },
    
    inactive: function() {
        this.removeClass('active');
        this.addClass('hover');
    },
    
    hidden: function() {
        this.css('visibility', 'hidden');
    },
    
    noBG: function() {
        this.css('background', 'none');
    },
    
    visible: function() {
        this.css('visibility', 'visible');
    },
});