/* Template JS */
/* The State of Queensland (Department of Education and Training) */

//jQuery - Run on page ready
$(function () {
    var tabs = $('.tabs');
    var popMSG = $('#msg');
    var popUP = $('#popup');
    var popUPX = $('#popup, #close');
    var resetBTN = $('#btnReset');
    var dragBTNs = $('.dragButt');
    
    tabChange(clkID);
    
    tabs.on('click touchend', function(e) {
        e.preventDefault();
        
        //pagCompleteBool is false, won't work if dragButt is not dropped.
        if (droppedBOOL) {
            //generate popup message only when clicking on non-active tab
            if(!$(this).hasClass('active')) {
                popMSG.html(popupMsg.tabClk);
                popUP.visible();
            }
        } else {
            //do nothing if same tab is clicked
            if (clkID !== e.currentTarget.id) {
                //hide the svg of previous tab, for tab click with completion purpose   
                svgObj.addClass('hidden');
                clkID = e.currentTarget.id;
                tabChange(clkID);
            }
        }
    });
    
    popUPX.on('click touchend', function(e) {
        e.preventDefault();
        popUP.hidden();
    });
    
    resetBTN.on('click touchend', function() {
        window.location.reload();
    });
    
    dragBTNs.draggable({
        revert:'invalid',
        revertDuration:0,
        containment:'#playground'
    });
    
    $('.clk').on('click touchend', function() {
        if (droppedBOOL) {
            $('.gifArea').css('background', 'url("./assets/images/rectPri.gif?'
                              + Math.random() +'") no-repeat center');
            $('.gifArea').removeClass('hidden');
        }
    });
});

function tabChange (tabID) {
    //set variables
    droppedBOOL = false;
    var clickedTab = $('#' + tabID);
    var activeTab = $('.active');
    var btnDropped =  $('.dropped');
    var giffArea = $('.gifArea');
    var clkGIF = $('.clk');
    
    giffArea.noBG();            //remove giff when tab change
    btnDropped.hidden();        //hide the dropped buttons
    
    //tab interactions
    activeTab.inactive();       //update active tab to inactive tab
    clickedTab.active();        //update inactive tab to active tab
    
    //to check which tab is active, then set droppable accept value.
    for (var i = 0; i < tabVal.length; i++) {
        //pull items from animation value array??!??!
        if (tabID === tabVal[i][0]) {
            //has to add # to array elements, otherwise, tricky for condition checks
            anNum = i;
            svgObj = dragID[i] + 'SVG';
            var acceptID = '#' + dragID[i];
        }
    }
    
    $('.gifArea').addClass('hidden');
    svgObj = $('#' + svgObj);
    svgObj.removeClass('hidden');
    
    //enable the hidden dropped buttons
    if($(acceptID).hasClass('dropped')) {
        $(acceptID).visible();
    }
    
    $('#animateArea').droppable({
        accept: acceptID,
        tolerance: 'intersect',
        drop: function (event,ui) {
            
            dropped(ui.draggable.attr('id'));
            //disable the dropped button
            $(acceptID)
                .draggable('disable')
                .removeClass('hover')
                .addClass('dropped');
            
        }
    });
    
    //insert the last image of gif to gifArea if tab is complete.
    for (var i = 0; i < tabVal.length; i++) {
        if (tabID === tabVal[i][0] && tabVal[i][1] === true) {
            $('.gifArea').css('background', 'url("./assets/images/' 
                              + completedGIF[i]  + '.png") no-repeat center');
            $('.gifArea').removeClass('hidden');
            svgObj.addClass('hidden');
        }
    }
    
    //remove SVG, then load GIF
    $('.clk').on('click touchend', function() {
        var boolCount = 0;
        var popMSG = $('#msg');
        var popUP = $('#popup');
        
        //if button is dropped
        if (droppedBOOL) {
            //insert respective GIF
            $('.gifArea').css('background', 'url("./assets/images/' + dragID[anNum] + 
                              '.gif?'+ Math.random() +'") no-repeat center');
            $('.gifArea').removeClass('hidden');
            svgObj.addClass('hidden');
            
            //show correct message
            popMSG.html(popupMsg.correctSelect);
            popUP.visible();
            //set BOOL to false so that it will allow tab change during GIF
            droppedBOOL=false;
        }
        
        //check how many page is complete
        for (var i = 0; i < tabVal.length; i++) {
            if (tabVal[i][1] === true) {
                boolCount++;
            }
        }
        
        //set BOOL true if all pages are complete
        if (boolCount === 6) {
            var allTabsBool = true;
        }
        
        //reveal final message when all pages are complete.
        if (allTabsBool) {
            popMSG.html(popupMsg.complete);
            popUP.visible();
        }
    });
}

function dropped (myID) {
    //consider to change / update this piece of codes...
    for (var i = 0; i < dragID.length; i++) {
        switch(myID) {
            case dragID[i]:
                $('#' + myID).css({
                    'position':'relative',
                    'left':'-410px',
                    'top':topVal[i]
                });
                //set the dropped BOOL value true.
                droppedBOOL = true;
                tabVal[i][1] = true;
                   }
    }
    
    $('#msg').html(popupMsg.correctDrop);
    $('#popup').visible();
}