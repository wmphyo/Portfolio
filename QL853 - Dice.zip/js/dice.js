var ran_dice = [];		//array to store the number of dice
var dic_pos = '';
var ZERO = 0;

/*function to display one dice when the number of dice is 1 */
function one_dice() {
	
	/*Following codes are for "the number of dice: (CSS: #dice_num_panel)"*/
	document.getElementById("img1").src = "assets/images/one_active.jpg";
	document.getElementById("img2").src = "assets/images/two.jpg";
	document.getElementById("img3").src = "assets/images/three.jpg";
	document.getElementById("img4").src = "assets/images/four.jpg";
	document.getElementById("img5").src = "assets/images/five.jpg";

	/*Insert dice image into html codes with Javascript once number of dice is chosen in #dice_num_panel*/
	document.getElementById("dice_roll_area").innerHTML = "<img src='assets/images/dic_inface_1.0.jpg' class='one_dice' id='dice_one'>";		//dice_one is optional for spin?
	
	/*To enable one_dice() function and disable others for roll_dice() function*/
	one_dice.called = true;
	two_dice.called = false;
	three_dice.called = false;
	four_dice.called = false;
	five_dice.called = false;
}

/*function to display two dices when the number of dice is 2 */
function two_dice() {
	/*Following codes are for "the number of dice: (CSS: #dice_num_panel)"*/
	document.getElementById("img2").src = "assets/images/two_active.jpg";
	document.getElementById("img1").src = "assets/images/one.jpg";
	document.getElementById("img3").src = "assets/images/three.jpg";
	document.getElementById("img4").src = "assets/images/four.jpg";
	document.getElementById("img5").src = "assets/images/five.jpg";
	
	/*Insert dice image into html codes with Javascript once number of dice is chosen in #dice_num_panel*/
	document.getElementById("dice_roll_area").innerHTML = "<img src='assets/images/dic_inface_2.0.jpg' class='two_dices' id='dice_one'>\
	<img src='assets/images/dic_inface_4.0_g.jpg' class='two_dices' id='dice_two'>";
	
	/*To enable two_dice() function and disable others for roll_dice() function*/
	two_dice.called = true;
	one_dice.called = false;
	five_dice.called = false;
	four_dice.called = false;
	three_dice.called = false;
}

/*function to display three dices when the number of dice is 3 */
function three_dice() {
	/*Following codes are for "the number of dice: (CSS: #dice_num_panel)"*/
	document.getElementById("img3").src = "assets/images/three_active.jpg";
	document.getElementById("img1").src = "assets/images/one.jpg";
	document.getElementById("img2").src = "assets/images/two.jpg";
	document.getElementById("img4").src = "assets/images/four.jpg";
	document.getElementById("img5").src = "assets/images/five.jpg";

	/*Insert dice image into html codes with Javascript once number of dice is chosen in #dice_num_panel*/
	document.getElementById("dice_roll_area").innerHTML = "<img src='assets/images/dic_inface_3.0.jpg' class='three_dices' id='dice_one'>\
	<img src='assets/images/dic_inface_5.0_g.jpg' class='three_dices' id='dice_two'>\
	<img src='assets/images/dic_inface_4.0_o.jpg' class='three_dices' id='dice_three'>";

	/*To enable three_dice() function and disable others for roll_dice() function*/
	three_dice.called = true;
	two_dice.called = false;
	one_dice.called = false;
	five_dice.called = false;
	four_dice.called = false;
}

/*function to display four dices when the number of dice is 4 */
function four_dice() {

	/*Following codes are for "the number of dice: (CSS: #dice_num_panel)"*/
	document.getElementById("img4").src = "assets/images/four_active.jpg";
	document.getElementById("img1").src = "assets/images/one.jpg";
	document.getElementById("img2").src = "assets/images/two.jpg";
	document.getElementById("img3").src = "assets/images/three.jpg";
	document.getElementById("img5").src = "assets/images/five.jpg";
	
	/*Insert dice image into html codes with Javascript once number of dice is chosen in #dice_num_panel*/
	document.getElementById("dice_roll_area").innerHTML = "<img src='assets/images/dic_inface_4.0.jpg' class='four_dices' id='dice_one' >\
		<img src='assets/images/dic_inface_1.0_g.jpg' class='four_dices' id='dice_two' >\
		<img src='assets/images/dic_inface_2.1_o.jpg' class='four_dices' id='dice_three' >\
		<img src='assets/images/dic_inface_6.1_p.jpg' class='four_dices' id='dice_four' >";
	
	/*To enable four_dice() function and disable others for roll_dice() function*/
	four_dice.called = true;
	three_dice.called = false;
	two_dice.called = false;
	one_dice.called = false;
	five_dice.called = false;
}

/*function to display five dices when the number of dice is 5 */
function five_dice() {
	
	/*Following codes are for "the number of dice: (CSS: #dice_num_panel)"*/
	document.getElementById("img5").src = "assets/images/five_active.jpg";
	document.getElementById("img1").src = "assets/images/one.jpg";
	document.getElementById("img2").src = "assets/images/two.jpg";
	document.getElementById("img3").src = "assets/images/three.jpg";
	document.getElementById("img4").src = "assets/images/four.jpg";
	
	/*Insert dice image into html codes with Javascript once number of dice is chosen in #dice_num_panel*/
	document.getElementById("dice_roll_area").innerHTML = "<img src='assets/images/dic_inface_5.0.jpg' class='five_dices' id='dice_one' >\
		<img src='assets/images/dic_inface_2.1_g.jpg' class='five_dices' id='dice_two' > <img src='assets/images/dic_inface_1.0_o.jpg' class='five_dices' id='dice_three' >\
		 <img src='assets/images/dic_inface_4.0_p.jpg' class='five_dices' id='dice_four' > <img src='assets/images/dic_inface_6.1_r.jpg' class='five_dices' id='dice_five' >";
	
	/*To enable five_dice() function and disable others for roll_dice() function*/
	five_dice.called = true;
	four_dice.called = false;
	three_dice.called = false;
	two_dice.called = false;
	one_dice.called = false;
}

/* ========== Animation stop functions ========== */
function stop_spin() {
	
	display_dice();
	enable_dice_num();
	
	/*Enable the button after animation to roll the dice again*/
	$('#roll_dice').on('click touchend', roll_dice);
	
	$('.num_of_dice').css('cursor', 'pointer');
	$('#roll_dice').css('cursor', 'pointer');

}

/*Function to hide animation and display result after 2.2secs*/	
function time_out() {
	setTimeout(stop_spin, 2200);
}

/*Function to enable images in 'choose the number of dice:' panel to allowe choosing dice numbers after rolling the dices*/
function enable_dice_num(){
	document.getElementById("img1").onclick = one_dice;
	document.getElementById("img2").onclick = two_dice;
	document.getElementById("img3").onclick = three_dice;
	document.getElementById("img4").onclick = four_dice;
	document.getElementById("img5").onclick = five_dice;
}

/*Function to disable images in 'choose the number of dice:' panel to prevent choosing dice number while rolling the dice*/
function disable_num_dice() {
	document.getElementById("img1").onclick = null;
	document.getElementById("img2").onclick = null;
	document.getElementById("img3").onclick = null;
	document.getElementById("img4").onclick = null;
	document.getElementById("img5").onclick = null;
	/*To prevent loading function from repeatedly clicking on the button*/
	$('#roll_dice').off('click touchend');
	
}

/*function to roll the dice*/
function roll_dice(){
	$('.num_of_dice').css('cursor', 'default');
	$('#roll_dice').css('cursor', 'default');

	/*Choosing the number of dice will be disabled when the dices are rolled.*/
	disable_num_dice();

	/*img variables are declared and used to hide images when we roll the dice*/
	
	/*Declare array to store randam value of 1 to 6*/
	ran_dice = [];
	
	/*Random method to get 0 or 1 to decide dice position for 2, 3 and 6.*/
	dic_pos = Math.floor((Math.random() *2) + 1);
	dic_pos = dic_pos - 1;		//Random method generates 1 and 2, where the image names include 0 and 1; 
		
	/*Loop to generate random numbers of 1 to 6 and add generated random number to ran_dice array*/
	for (var i = 0; i < 5; i++){
		var dic_num = Math.floor((Math.random() *6) + 1);
		ran_dice.push(dic_num);			//add random value to array
		dic_num = '';
	}
		
	/*The idea is to hide image (i.e. automatically displayed by one_dice(), two_dice(), three_dice() functions) and
	display animation css (spin_x) for 2.2secs and display the result through time_out() function*/
	if(one_dice.called){
		/*Hide dice number one, which is inserted in one_dice function (line num: 5) */
		$('#dice_one').hide();
		document.getElementById("dice_roll_area").innerHTML = "<div class='one_dice' id='spin_1'></div>";		//image is hyperlinked in spin_1 id
		decide_dice();
		time_out();			
	} 		
	
	if(two_dice.called) {
		$('#dice_one').hide();
		$('#dice_two').hide();
		document.getElementById("dice_roll_area").innerHTML = "<div class='two_dices' id='spin_1'></div> <div class='two_dices' id='spin_2'></div>";	
		decide_dice();
		time_out();			
	}			
	
	if(three_dice.called) {
		$('#dice_one').hide();
		$('#dice_two').hide();
		$('#dice_three').hide();
		document.getElementById("dice_roll_area").innerHTML = "<div class='three_dices' id='spin_1'></div> <div class='three_dices' id='spin_2'></div> <div class='three_dices' id='spin_3'></div>";	
		decide_dice();
		time_out();	
	}
	
	if(four_dice.called) {
		$('#dice_one').hide();
		$('#dice_two').hide();
		$('#dice_three').hide();
		$('#dice_four').hide();
		document.getElementById("dice_roll_area").innerHTML = "<div class='four_dices' id='spin_1'></div><div class='four_dices' id='spin_2'></div><div class='four_dices' id='spin_3'></div><div class='four_dices' id='spin_4'></div>";	
		decide_dice();
		time_out();	
	}
	
	if(five_dice.called) {
		$('#dice_one').hide();
		$('#dice_two').hide();
		$('#dice_three').hide();
		$('#dice_four').hide();
		$('#dice_five').hide();
		document.getElementById("dice_roll_area").innerHTML = "<div class='five_dices' id='spin_1'></div><div class='five_dices' id='spin_2'></div><div class='five_dices' id='spin_3'></div><div class='five_dices' id='spin_4'></div> \
	  <div class='five_dices' id='spin_5'></div>";
	 	decide_dice();
		time_out();
	}
}

/*functions to decide dice urls. the function is excuted once dice starts spinning*/
function decide_dice(){
	if(one_dice.called){
		/*Following loops check array element value and the value is used to display dice interface
		 var dic_pos = 0 or 1 to decide dice position, especially for dice number 2, 3, 6 | image name format is dic_inface_x.y_c.jpg. | eg. dic_inface_1.0_r.jpg | x = 1 to 6, y = 0 or 1, c = colors.*/
		for (var i=1; i<=6; i++) {
			if (ran_dice[0] === i){	
				one_dice_url = "<img src='assets/images/dic_inface_" + i + "." + dic_pos + ".jpg' class='one_dice' id='dice_one' >";
			} 
		}
	} else if(two_dice.called){
		for (var i = 1; i <= 6; i++) {
			if (ran_dice[0] === i) {
				var dice_one = ran_dice[0];		/*Insert value into variable*/
			}	
		}
		for (var j = 1; j <= 6; j++) {
			if (ran_dice[1] === j) {
				var dice_two = ran_dice[1];
			}
		}
		two_dice_url = "<img src='assets/images/dic_inface_" + dice_one + "." + dic_pos + ".jpg' class='two_dices' id='dice_one' >\
		<img src='assets/images/dic_inface_" + dice_two + "." + dic_pos + "_g.jpg' class='two_dices' id='dice_two' >";
	} else if(three_dice.called){
		for (var i = 1; i <= 6; i++) {
			if (ran_dice[0] === i) {
				var dice_one = ran_dice[0];
				}	
			}

		for (var j = 1; j <= 6; j++) {
			if (ran_dice[1] === j) {
				var dice_two = ran_dice[1];
			}
		}
		
		for (var k = 1; k <= 6; k++) {
			if (ran_dice[2] === k) {
				var dice_three = ran_dice[2];
			}
		}
		three_dice_url = "<img src='assets/images/dic_inface_" + dice_one + "." + dic_pos + ".jpg' class='three_dices' id='dice_one' >\
		<img src='assets/images/dic_inface_" + dice_two + "." + dic_pos + "_g.jpg' class='three_dices' id='dice_two' >\
		<img src='assets/images/dic_inface_" + dice_three + "." + dic_pos + "_o.jpg' class='three_dices' id='dice_three' >";	
	} else if(four_dice.called){
		for (var i = 1; i <= 6; i++) {
			if (ran_dice[0] === i) {
				var dice_one = ran_dice[0];
				}	
			}

		for (var j = 1; j <= 6; j++) {
			if (ran_dice[1] === j) {
				var dice_two = ran_dice[1];
			}
		}
		
		for (var k = 1; k <= 6; k++) {
			if (ran_dice[2] === k) {
				var dice_three = ran_dice[2];
			}
		}	
		
		for (var l = 1; l <= 6; l++) {
			if (ran_dice[3] === l) {
				var dice_four = ran_dice[3];
			}
		}	
		four_dice_url = "<img src='assets/images/dic_inface_" + dice_one + "." + dic_pos + ".jpg' class='four_dices' id='dice_one' >\
		<img src='assets/images/dic_inface_" + dice_two + "." + dic_pos + "_g.jpg' class='four_dices' id='dice_two' >\
		<img src='assets/images/dic_inface_" + dice_three + "." + dic_pos + "_o.jpg' class='four_dices' id='dice_three' >\
		<img src='assets/images/dic_inface_" + dice_four + "." + dic_pos + "_p.jpg' class='four_dices' id='dice_four' >";	
	} else {
		for (i = 1; i <= 6; i++) {
			if (ran_dice[0] === i) {
				var dice_one = ran_dice[0];
				}	
			}

		for (j = 1; j <= 6; j++) {
			if (ran_dice[1] === j) {
				var dice_two = ran_dice[1];
			}
		}
		
		for (k = 1; k <= 6; k++) {
			if (ran_dice[2] === k) {
				var dice_three = ran_dice[2];
			}
		}	
		
		for (l = 1; l <= 6; l++) {
			if (ran_dice[3] === l) {
				var dice_four = ran_dice[3];
			}
		}
		
		for (m = 1; m <= 6; m++) {
			if (ran_dice[4] === m) {
				var dice_five = ran_dice[4];
			}
		}
		five_dice_url = "<img src='assets/images/dic_inface_" + dice_one + "." + dic_pos + ".jpg' class='five_dices' id='dice_one' >\
		<img src='assets/images/dic_inface_" + dice_two + "." + dic_pos + "_g.jpg' class='five_dices' id='dice_two' >\
		<img src='assets/images/dic_inface_" + dice_three + "." + dic_pos + "_o.jpg' class='five_dices' id='dice_three' >\
		<img src='assets/images/dic_inface_" + dice_four + "." + dic_pos + "_p.jpg' class='five_dices' id='dice_four' >\
		<img src='assets/images/dic_inface_" + dice_five + "." + dic_pos + "_r.jpg' class='five_dices' id='dice_five'>";
	}
}

/*Function to display decided dice urls once spinning stops*/
function display_dice(){
	if (one_dice.called){
		document.getElementById("dice_roll_area").innerHTML = one_dice_url;
	} else if(two_dice.called){
		document.getElementById("dice_roll_area").innerHTML = two_dice_url;
	} else if(three_dice.called){
		document.getElementById("dice_roll_area").innerHTML = three_dice_url;		
	} else if(four_dice.called){
		document.getElementById("dice_roll_area").innerHTML = four_dice_url;		
	} else {
		document.getElementById("dice_roll_area").innerHTML = five_dice_url;
	}
}

/*Code to disable draggable for all browsers*/
$(document).on("dragstart", function() {
     return false;
});


$(document).ready(function() {
	$('.num_of_dice').css('cursor', 'pointer');
	$('#roll_dice').css('cursor', 'pointer');
	$('html').css('cursor', 'default');
	
	$('#roll_dice').on('click touchend', function(e) {
        roll_dice();
	});
	

/*Create array for image paths*/
var img_preload_arr = [
    'assets/images/dic_inface_1.0.jpg',
	'assets/images/dic_inface_1.0_g.jpg',	
	'assets/images/dic_inface_1.0_o.jpg',
	'assets/images/dic_inface_1.0_p.jpg',
	'assets/images/dic_inface_1.0_r.jpg',
	'assets/images/dic_inface_1.1.jpg',
	'assets/images/dic_inface_1.1_g.jpg',	
	'assets/images/dic_inface_1.1_o.jpg',
	'assets/images/dic_inface_1.1_p.jpg',
	'assets/images/dic_inface_1.1_r.jpg',
	'assets/images/dic_inface_2.0.jpg',
	'assets/images/dic_inface_2.0_g.jpg',	
	'assets/images/dic_inface_2.0_o.jpg',
	'assets/images/dic_inface_2.0_p.jpg',
	'assets/images/dic_inface_2.0_r.jpg',
	'assets/images/dic_inface_2.1.jpg',
	'assets/images/dic_inface_2.2_g.jpg',	
	'assets/images/dic_inface_2.3_o.jpg',
	'assets/images/dic_inface_2.4_p.jpg',
	'assets/images/dic_inface_2.5_r.jpg',
	'assets/images/dic_inface_3.0.jpg',
	'assets/images/dic_inface_3.0_g.jpg',	
	'assets/images/dic_inface_3.0_o.jpg',
	'assets/images/dic_inface_3.0_p.jpg',
	'assets/images/dic_inface_3.0_r.jpg',
	'assets/images/dic_inface_3.1.jpg',
	'assets/images/dic_inface_3.1_g.jpg',	
	'assets/images/dic_inface_3.1_o.jpg',
	'assets/images/dic_inface_3.1_p.jpg',
	'assets/images/dic_inface_3.1_r.jpg',
	'assets/images/dic_inface_4.0.jpg',
	'assets/images/dic_inface_4.0_g.jpg',	
	'assets/images/dic_inface_4.0_o.jpg',
	'assets/images/dic_inface_4.0_p.jpg',
	'assets/images/dic_inface_4.0_r.jpg',
	'assets/images/dic_inface_4.1.jpg',
	'assets/images/dic_inface_4.1_g.jpg',	
	'assets/images/dic_inface_4.1_o.jpg',
	'assets/images/dic_inface_4.1_p.jpg',
	'assets/images/dic_inface_4.1_r.jpg',
	'assets/images/dic_inface_5.0.jpg',
	'assets/images/dic_inface_5.0_g.jpg',	
	'assets/images/dic_inface_5.0_o.jpg',
	'assets/images/dic_inface_5.0_p.jpg',
	'assets/images/dic_inface_5.0_r.jpg',
	'assets/images/dic_inface_5.1.jpg',
	'assets/images/dic_inface_5.1_g.jpg',	
	'assets/images/dic_inface_5.1_o.jpg',
	'assets/images/dic_inface_5.1_p.jpg',
	'assets/images/dic_inface_5.1_r.jpg',
	'assets/images/dic_inface_6.0.jpg',
	'assets/images/dic_inface_6.0_g.jpg',	
	'assets/images/dic_inface_6.0_o.jpg',
	'assets/images/dic_inface_6.0_p.jpg',
	'assets/images/dic_inface_6.0_r.jpg',
	'assets/images/dic_inface_6.1.jpg',
	'assets/images/dic_inface_6.1_g.jpg',	
	'assets/images/dic_inface_6.1_o.jpg',
	'assets/images/dic_inface_6.1_p.jpg',
	'assets/images/dic_inface_6.1_r.jpg',
];

	/*Preload images from the array*/
	var len = img_preload_arr.length;
	var img = new Image();
	
	for( var i = 0; i < len; i++) {
		img.src = img_preload_arr[i];
	}	
});
	
