var textDisplay = new function () {
        this.Fname = 'Hestia';
        this.Lname = 'Seng';
        this.DOB = '12/5/1990';
        this.fav = 'She loves icecreams';
        this.getInfo = function() {
            return this.Fname + '  ' + this.Lname + '  ' + this.DOB + '  ' + this.bio;
        }
    }

function display() {
    //textDisplay.Fname = 'Seng';
    document.getElementById('display').innerHTML = ('<u>User information</u> <br/><br/> <b>First name:&nbsp;&nbsp;&nbsp;&nbsp;</b> ' + textDisplay.Fname + '<br/> <b>Last name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> ' + textDisplay.Lname + '<br/> <b>Date of birth:&nbsp;</b> ' + textDisplay.DOB + '<br/> <b>Favourite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> '+ textDisplay.fav);
}


//Check this out for better understanding of JavaScript prototypal inheritance - https://stackoverflow.com/questions/186244/what-does-it-mean-that-javascript-is-a-prototype-based-language?noredirect=1&lq=1
//Check this out for basic JS OOP - https://stackoverflow.com/questions/14972622/object-oriented-javascript-with-example
//Read this for 'this' vs 'prototype' - https://stackoverflow.com/questions/310870/use-of-prototype-vs-this-in-javascript
//Read this for better understanding of the use of Prototype and OOP - https://stackoverflow.com/questions/572897/how-does-javascript-prototype-work?noredirect=1&lq=1
//Read this for better writing of conditions - https://stackoverflow.com/questions/1771786/question-mark-and-colon-in-javascript