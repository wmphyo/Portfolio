
var MC = {};
MC.CurrentPage = 1;
MC.MAXPAGES = 7;
MC.CLASSSHOW = "show";
MC.CLASSNOSHOW = "noshow";
MC.CLASSHIDE = "hide";
MC.CLASSPOINTER = 'cursor-pointer';
MC.CLASSSELECTED = 'selected';
MC.CLASSRESET = 'reset';
MC.NEXTBUTTONLABELNEXT = 'next';
MC.NEXTBUTTONLABELRESET = 'reset';
MC.PopupMessages = ['Select the next tab.',
                    'Keep trying. You may need to try other shapes, or rotate shapes to make them fit. Remember to use the required number of pieces.',
                    '<ol><li>Drag pieces of the tangram to cover the shape.</li>' +
                    '<li>Rotate if necessary to make the pieces cover the shape exactly.</li>' + 
                    '<li>Use the required number of pieces.</li>' +  
                    '</ol>',
                    'Well done! Select <strong> reset</strong> to do the activity again!'];
MC.MOUSEEVENTCLICK = 'click';
MC.MOUSEEVENTMOUSEDOWN = 'mousedown';
MC.MOUSEEVENTMOUSEUP = 'mouseup';
MC.MOUSEEVENTTOUCHSTART = 'touchstart';
MC.MOUSEEVENTTOUCHEND = 'touchend';
MC.MOUSEEVENTTOUCHMOVE = 'touchmove';
MC.MOUSEEVENTMOUSELEAVE = 'mouseleave';
MC.MOUSEEVENTSCLICKTOUCHSTART = MC.MOUSEEVENTMOUSEDOWN + ' ' + MC.MOUSEEVENTTOUCHSTART;
MC.TIMEOUTTIME = 10;
MC.TIMEOUTID = undefined;
MC.TIMEOUTAUTOID = undefined;
MC.ROTATIONMAXTIMEOUTTIME = 220;
MC.RotationTimeoutTime = MC.ROTATIONMAXTIMEOUTTIME;
MC.ROTATIONMINTIMEOUTITME = 80;
MC.ROTATIONTIMEOUTSPEED = 20;
MC.ProtractorCurrentRotation = 0;
//
MC.OffsetX = 454;
MC.OffsetY = 28;
MC.OffsetXalt = 24;
//
MC.TRIANGLELARGE1 = 'tl1';
MC.TRIANGLELARGE2 = 'tl2';
MC.TRIANGLESMALL1 = 'ts1';
MC.TRIANGLESMALL2 = 'ts2';
MC.SQUARE = 'sqa';
//
//NOTE: tab d (index 4) there are 4 options, tab f (index 6) there are 8 variations
//
//Tab f options: 0(large triangle), 270(sm), 180(sm) OR  180(small triangle), 90(sm), 90(sm).
MC.Requirements = [];
MC.Requirements.push({});
//Page 1
MC.Requirements.push([90, 270]);
//Page 2
MC.Requirements.push([270, 0, 90]);
//Page 3
MC.Requirements.push([180, 90, 0]);
//TODO::Page 4 Next is not finished
MC.Requirements.push([0, 0, 0]);
//Page 5
MC.Requirements.push([270, 180]);
//TODO:: Page 6 below
MC.Requirements.push([180, 180, 90]);
//Page 7
MC.Requirements.push([315, 270, 225, 90, 180]);
//
MC.PagesStatus = [];
MC.PagesStatus.push({complete:false, objs:[]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLESMALL1, MC.TRIANGLESMALL2]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLESMALL1, MC.TRIANGLESMALL2, MC.SQUARE]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLESMALL1, MC.TRIANGLESMALL2, MC.SQUARE]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLESMALL1, MC.TRIANGLESMALL2, MC.SQUARE, MC.TRIANGLELARGE1, MC.TRIANGLELARGE2]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLELARGE1, MC.TRIANGLELARGE2]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLESMALL1, MC.TRIANGLESMALL2, MC.SQUARE, MC.TRIANGLELARGE1, MC.TRIANGLELARGE2]});
MC.PagesStatus.push({complete:false, objs:[MC.TRIANGLESMALL1, MC.TRIANGLESMALL2, MC.SQUARE, MC.TRIANGLELARGE1, MC.TRIANGLELARGE2]});

/*** JScreate is taking car of image loading.
var imageSources = ['', 
                    ''];
for ( var i = 0; i < imageSources.length; i++){
    //jscreate is taking care of this.
    //new Image().src = imageSources[i];
}*/
$(document).ready(function () {
    MC.MainBody = $(".body-wrapper");
    MC.ButtonControlsWrapper = $("#button_control");
    MC.Popup = $('#popup_wrapper');
    MC.DragObjectsContainer = $('.drag-container-wrapper');
    MC.TickContainer = $('.page-complete-icon');
    MC.HelpBtn = $("#help_btn");
    MC.CheckBtn = $("#check_btn");
    MC.ClearBtn = $("#clear_btn");
    MC.PopupCloseBtn = $('.popup-close-btn');
    MC.PopupMessage = $('.popup-message');
    MC.RotateRightBtn = $('.ray-btn.right');
    MC.RotateLeftBtn = $('.ray-btn.left');
    MC.RotateRightBtn.fcn = MC.RotateRight;
    MC.RotateLeftBtn.fcn = MC.RotateLeft;
    //Event listeners
    MC.HelpBtn.on('click', function(){MC.ShowPopup(MC.PopupMessages[2]);});
    MC.CheckBtn.on('click', MC.Check);
    MC.ClearBtn.on('click', MC.Reset);
    $('.tab').on('click', selectPage);
    MC.PopupCloseBtn.on('click', MC.ClosePopup);
    MC.CheckBtn.fcn = MC.Check;
    MC.ClearBtn.fcn = MC.Clear;
    MC.PopupCloseBtn.fcn = MC.ClosePopup;
    //
    MC.Pages = [];
    MC.Pages.push($(".page0"));
    MC.Pages.push($(".page1"));
    MC.Pages.push($(".page2"));
    MC.Pages.push($(".page3"));
    MC.Pages.push($(".page4"));
    MC.Pages.push($(".page5"));
    MC.Pages.push($(".page6"));
    MC.Pages.push($(".page7"));
    MC.PageComplete = [];
    //
    MC.DraggableObjects = '.grid-icon-drag';
    //
    var ua = navigator.userAgent.toLowerCase();
    MC.firefox = ua.indexOf('firefox') > 0;
    MC.mac = ua.indexOf('macintosh') > 0;
    MC.win8 = /Touch/i.test(navigator.userAgent);
    MC.ios = /iphone|ipad/i.test(navigator.userAgent);
    MC.android = /Android/i.test(navigator.userAgent);
    var isAndroid = ua.indexOf("android") > -1;
    if (!(/Touch/i.test(navigator.userAgent)) && (/Trident/i.test(navigator.userAgent)))
        MC.IE = /Trident/i.test(navigator.userAgent);
    if (navigator.userAgent.indexOf('Safari') !== -1 && navigator.userAgent.indexOf('Mac') !== -1 && navigator.userAgent.indexOf('Chrome') === -1 && !(/ipad|iphone/i.test(navigator.userAgent))) {
        MC.Mac = /Mac/i.test(navigator.userAgent);
    }
    if(MC.win8){
        //*.addClass('win8');
    }
    if(MC.ios){
       //*.addClass('iPad');
       MC.OffsetX = 470;
       MC.OffsetXalt = 14;
    }
    if(MC.android){
        MC.OffsetX = 455;
        MC.OffsetXalt = 16;
    }
    if(MC.IE){
        MC.OffsetX = 462;
        MC.OffsetXalt = 16;
    }
    if(MC.Mac && !MC.ios){
        MC.OffsetX = 470;
        MC.OffsetXalt = 8;
        $('.btn').addClass('mobile');
        $('.tab').addClass('mobile');
    }
    //
    if (('ontouchstart' in window || navigator.msMaxTouchPoints || 'ontouchstart' in document.documentElement || typeof window.orientation != 'undefined'))  {
        //isMobile so we remove the hover states and add the mobile start screen
        MC.IsTouch = true;
		$('.btn').addClass('mobile');
        $('.tab').addClass('mobile');
        removeBtnHoverState();
    }else{
        //Use for destop
    }
    $('.page-complete-icon img').on("dragstart", function() {
     		return false;
	});
    init();
});

/*
 * Setup initial page - first start
*/
function init() {
    //Start first time/page display
    if(MC.ios || MC.android){
        MC.RotateRightBtn.on(MC.MOUSEEVENTTOUCHSTART, MC.RotateRight);
        MC.RotateLeftBtn.on(MC.MOUSEEVENTTOUCHSTART, MC.RotateLeft);
        MC.RotateRightBtn.event = MC.MOUSEEVENTTOUCHSTART;
        MC.RotateLeftBtn.event = MC.MOUSEEVENTTOUCHSTART;
        MC.RotateRightBtn.on(MC.MOUSEEVENTTOUCHEND, MC.ClearTimeout);
        MC.RotateLeftBtn.on(MC.MOUSEEVENTTOUCHEND, MC.ClearTimeout);
        MC.RotateRightBtn.on(MC.MOUSEEVENTTOUCHMOVE, function(){});
        MC.RotateLeftBtn.on(MC.MOUSEEVENTTOUCHMOVE, function(){});
        $('body').on(MC.MOUSEEVENTTOUCHSTART, function(){});
        if(MC.ios){
            $('body').on(MC.MOUSEEVENTTOUCHEND, MC.ClearTimeout);
        }else{
            $('body').on(MC.MOUSEEVENTTOUCHMOVE, MC.ClearTimeout);
        }
    }else{
        MC.RotateRightBtn.on(MC.MOUSEEVENTMOUSEDOWN, MC.RotateRight);
        MC.RotateLeftBtn.on(MC.MOUSEEVENTMOUSEDOWN, MC.RotateLeft);
        MC.RotateRightBtn.event = MC.MOUSEEVENTMOUSEDOWN;
        MC.RotateLeftBtn.event = MC.MOUSEEVENTMOUSEDOWN;
        MC.RotateRightBtn.on(MC.MOUSEEVENTMOUSEUP, MC.ClearTimeout);
        MC.RotateRightBtn.on(MC.MOUSEEVENTMOUSELEAVE, MC.ClearTimeout);
        MC.RotateLeftBtn.on(MC.MOUSEEVENTMOUSEUP, MC.ClearTimeout);
        MC.RotateLeftBtn.on(MC.MOUSEEVENTMOUSELEAVE, MC.ClearTimeout);
    }
    MC.RotateRightBtn.fcn = MC.RotateRight;
    MC.RotateLeftBtn.fcn = MC.RotateLeft;
    //
    MC.TickContainer.addClass(MC.CLASSHIDE);
    //The clear function will set up all dragg objects
    // initialise the opjects and assign the base attributes and  start at the first tab.
    MC.Clear();
    /*
    *Reset pages 1
    */
    MC.Pages[1].Reset = function(){
    //console.log("Reset page 1.");
    }
    /*
    *Reset pages 2
    */
    MC.Pages[2].Reset = function(){
    //console.log("Reset page 2.");
    }
    /*
    *Reset pages 3
    */
    MC.Pages[3].Reset = function(){
    //console.log("Reset page 3.");
    }
    /*
    *Reset pages 4
    */
    MC.Pages[4].Reset = function(){
    //console.log("Reset page 4.");
    }
    /*
    *Reset pages 5
    */
    MC.Pages[5].Reset = function(){
    //console.log("Reset page 5.");
    }
    /*
    *Reset pages 6
    */
    MC.Pages[6].Reset = function(){
    //console.log("Reset page 6.");
    }
    MC.ShowPopup(MC.PopupMessages[2]);
}

/*
 * Remove the buttons hover state if it is a mobile deivce
*/
function removeBtnHoverState() {
    $('.hover').removeClass('hover');
}

/*
 * Select the page according the tab clicked
*/
function setupDragObjectsContainer(e) {
    MC.DragObjectsContainer.empty();
    MC.DragObjectsContainer.html(getDragObjects());
    if(!MC.PagesStatus[MC.CurrentPage].complete)$('.drag-container-wrapper .grid-icon-drag').on(MC.MOUSEEVENTSCLICKTOUCHSTART, selectDragObject);
}

/*
 * Select the page according the tab clicked
*/
function selectDragObject(e) {
    MC.ClosePopup();
    removeSelectedClass(MC.DraggableObjects);
    $('#' + e.currentTarget.id).addClass(MC.CLASSSELECTED);
    MC.CurrentDragObject = MC.DragObjects[e.currentTarget.id];
}

/*
 * Select the page according the tab clicked
*/
function selectPage(e) {
    MC.ClosePopup();
    //Check if this page has reduntant objects and remove them
    cleanUpPage();
    $('.tab').removeClass('selected');
    $(e.currentTarget).addClass('selected');
    $('.page').addClass(MC.CLASSHIDE);
    MC.CurrentPage = $(e.currentTarget).attr('data-index');
    checkPageStatus();
    $('.page' + MC.CurrentPage).removeClass(MC.CLASSHIDE);
}

/*
 * Show the Mobile sound start screen and intitate the sound button
*/
MC.Play = function() {
    //Start, play - whatever needed with the play button.
    //console.log("Play");
}

/*
 * Special case undo button, undo any operation
*/
MC.Undo = function() {
    //Undo something...
    //console.log("Undo");
}

/*
 * Check the page status when selecting a new tab if the page has been complete.
*/
function checkPageStatus() {
    //
    if(MC.PagesStatus[MC.CurrentPage].complete){
        //hide the specific graggables
        MC.UpdateDraggablesContainer();
        if(MC.CurrentPage == 7){
            MC.TickContainer.addClass('page7');
        }else{
            MC.TickContainer.removeClass('page7');
        }
        MC.TickContainer.removeClass(MC.CLASSHIDE);
        return;
    }else{
        //Remove all the added objects from the drop containers.
        $('.page' + MC.CurrentPage + ' .drop-zone').empty();
        $('.drop-containers-wrapper > .grid-icon-drag').remove();
        setupDragObjectsContainer();
        initDraggables();
        MC.ResetRotations();
        MC.TickContainer.addClass(MC.CLASSHIDE).removeClass('page7');
    }
}

/*
 * Check the page status when selecting a new tab if the page has been complete.
*/
function cleanUpPage(){
    //
    if(!MC.PagesStatus[MC.CurrentPage].complete){
        //Remove all the added objects from the drop containers.
        $('.page' + MC.CurrentPage + ' .drop-zone').empty();
        $('.drop-containers-wrapper > .grid-icon-drag').remove();
    }
}

/*
 * Special case check button, check results
*/
MC.Check = function() {
    if(MC.PagesStatus[MC.CurrentPage].complete){
        MC.UpdateDraggablesContainer();
        if(checkAllPages()){
            MC.ShowPopup(MC.PopupMessages[3]);
        }else{
            MC.ShowPopup(MC.PopupMessages[0]);
        }
        return;
    }
    var correct = true;
    var checkList = $($('.page' + MC.CurrentPage + ' .drop-containers-wrapper'))[0].children;
    for( var i = 0; i < checkList.length; i++){
        //Check if this is a drop-zone (valid shape) - if not ignore
        //BUT if the shapes are corret, remove the other shapes.
        if(MC.CurrentPage == 6){
            if(!$(checkList[2].children[0]).hasClass('square')){
                if(checkList[0].children.length == 2){
                    var a = 0;
                    var b = 1;
                    if($(checkList[0].children[0]).hasClass('right')){
                        a = 1;
                        b = 0;
                    }
                    var r1 = MC.DragObjects[checkList[0].children[a].id].rotation;
                    var r2 = MC.DragObjects[checkList[0].children[b].id].rotation;
                    var r3 = MC.DragObjects[checkList[1].children[0].id].rotation;
                    if(r1 == 180 && r2 == 90 && r3 == 90){
                        correct = true;
                    }else{
                        correct = false;
                        break;
                    }
                }else{
                    var a = 0;
                    var b = 1;
                    if($(checkList[1].children[0]).hasClass('bottom')){
                        a = 1;
                        b = 0;
                    }
                    if(checkList[1].children.length == 2){
                        var r1 = MC.DragObjects[checkList[1].children[a].id].rotation;
                        var r2 = MC.DragObjects[checkList[1].children[b].id].rotation;
                        var r3 = MC.DragObjects[checkList[0].children[0].id].rotation;
                        if(r1 == 270 && r2 == 180 && r3 == 0){
                            correct = true;
                        }else{
                            correct = false;
                            break;
                        }
                    }else{
                        correct = false;
                        break;
                    }
                }
            }
        }

        if(MC.CurrentPage == 3){
                if(checkList[3].children.length == 1){
                    var a = 0;
                    var b = 1;
                    if(checkList[0].children.length == 1 && checkList[6].children.length == 1){
                        var r1 = MC.DragObjects[checkList[0].children[0].id].rotation;
                        var r2 = MC.DragObjects[checkList[6].children[0].id].rotation;
                        var r3 = MC.DragObjects[checkList[3].children[0].id].rotation;
                    }
                    if(r1 == 180 && r2 == 0 && r3 == r3%90){
                        correct = true;
                    }else{
                        correct = false;
                        break;
                    }
                }else{
                    var _this1 = checkList[1].children.length;
                    var _this2 = checkList[5].children.length;
                    
                    if(_this1 > 0){
                        if(checkList[4].children.length == 1 && checkList[6].children.length == 1){
                            var r1 = MC.DragObjects[checkList[1].children[0].id].rotation;
                            var r2 = MC.DragObjects[checkList[4].children[0].id].rotation;
                            var r3 = MC.DragObjects[checkList[6].children[0].id].rotation;
                            if(r1 == 0 && r2 == 270 && r3 == 0){
                                correct = true;
                            }else{
                                correct = false;
                            }
                        }else{
                            correct = false;
                        }
                    }else if(_this2 > 0){
                        if(checkList[0].children.length == 1 && checkList[2].children.length == 1){
                            var r1 = MC.DragObjects[checkList[0].children[0].id].rotation;
                            var r2 = MC.DragObjects[checkList[2].children[0].id].rotation;
                            var r3 = MC.DragObjects[checkList[5].children[0].id].rotation;
                            if(r1 == 180 && r2 == 90 && r3 == 180){
                                correct = true;
                            }else{
                                correct = false;
                            }
                        }else{
                            correct = false;
                        }
                    }else{
                        correct = false;
                    }
                }
        }
        //
        if(MC.CurrentPage == 4){
            if($(checkList[2].children[0]).hasClass('square')){
                if(checkList[0].children.length == 0 &&
                    checkList[1].children.length == 0 &&
                    checkList[3].children.length == 0 ){
                        var tryMe = checkList[6].children.length;
                        if(tryMe != 0){
                            var tRot = MC.DragObjects[checkList[6].children[0].id].rotation;
                            if(tRot == 0 &&
                                checkList[4].children.length == 0 &&
                                checkList[10].children.length == 0 &&
                                checkList[8].children.length == 0 &&
                                checkList[5].children.length == 1 &&
                                checkList[9].children.length == 1){
                                    var tRot1 = MC.DragObjects[checkList[5].children[0].id].rotation;
                                    var tRot2 = MC.DragObjects[checkList[9].children[0].id].rotation;
                                    if(tRot1 == 0 && tRot2 == 270){
                                        correct = true;
                                    }else{
                                        correct = false;
                                    }
                            }else if(tRot == 180 &&
                                checkList[5].children.length == 0 &&
                                checkList[10].children.length == 0 &&
                                checkList[9].children.length == 0 &&
                                checkList[4].children.length == 1 &&
                                checkList[8].children.length == 1){
                                    var tRot1 = MC.DragObjects[checkList[4].children[0].id].rotation;
                                    var tRot2 = MC.DragObjects[checkList[8].children[0].id].rotation;
                                    if(tRot1 == 90 && tRot2 == 180){
                                        correct = true;
                                    }else{
                                        correct = false;
                                    }
                            }else{
                                correct = false;
                                break;
                            }
                        }else{
                            correct = false;
                            break;
                        } 
                }else{
                    correct = false;
                    break;
                }
            }else{
                if(checkList[6].children.length == 0 &&
                    checkList[8].children.length == 0 &&
                    checkList[9].children.length == 0 ){
                        var tryMe = checkList[3].children.length;
                        if(tryMe != 0){
                            var tRot = MC.DragObjects[checkList[3].children[0].id].rotation;
                            if(tRot == 270 &&
                                checkList[0].children.length == 0 &&
                                checkList[4].children.length == 0 &&
                                checkList[5].children.length == 0 &&
                                checkList[1].children.length == 1 &&
                                checkList[10].children.length == 1){
                                    var tRot1 = MC.DragObjects[checkList[1].children[0].id].rotation;
                                    var tRot2 = MC.DragObjects[checkList[10].children[0].id].rotation;
                                    if(tRot1 == 180 && tRot2 == 270){
                                        correct = true;
                                    }else{
                                        correct = false;
                                    }
                            }else if(tRot == 90 &&
                                checkList[1].children.length == 0 &&
                                checkList[4].children.length == 0 &&
                                checkList[10].children.length == 0 &&
                                checkList[0].children.length == 1 &&
                                checkList[5].children.length == 1){
                                    var tRot1 = MC.DragObjects[checkList[0].children[0].id].rotation;
                                    var tRot2 = MC.DragObjects[checkList[5].children[0].id].rotation;
                                    if(tRot1 == 90 && tRot2 == 0){
                                        correct = true;
                                    }else{
                                        correct = false;
                                    }
                            }else{
                                correct = false;
                                break;
                            }
                        }else{
                            correct = false;
                            break;
                        } 
                }else{
                    correct = false;
                    break;
                }
            }
        }else{
             if(MC.CurrentPage != 3 && MC.CurrentPage != 6 && $(checkList[i]).hasClass('drop-zone')){
                if(checkList[i].children.length == 1){
                    var rotation = MC.DragObjects[checkList[i].children[0].id].rotation;
                    var tRotation = false;
                    var sRotation = false;
                    //Check if we have a sqaure or a triangle.
                    if($(checkList[i].children[0]).hasClass('square')){
                        if(rotation % MC.Requirements[MC.CurrentPage][i] == 0 )sRotation = true;
                    }else{
                        if((MC.Requirements[MC.CurrentPage][i]) == rotation)tRotation = true;
                    }
                    //if either the trianlge rotation is correct or the square rotation
                    if(tRotation || sRotation){
                        correct = true;
                    }else{
                        correct = false;
                        break;
                    }
                }else{
                    //No - what a shame - lost
                    correct = false;
                    break;
                }
            }
        }
    }
    if(correct){
        $('.drop-containers-wrapper .drop-zone .grid-icon-drag.selected').removeClass('selected');
        MC.CurrentDragObject = undefined;
        $('.drop-containers-wrapper .drop-zone .grid-icon-drag').addClass('complete');
        $('.drop-containers-wrapper .drop-zone .grid-icon-drag').id = "empty";
        setupDragObjectsContainer();
        initDraggables();
        MC.ResetRotations();
        MC.PagesStatus[MC.CurrentPage].complete = true;
        checkPageStatus();
        if(checkAllPages()){
            MC.ShowPopup(MC.PopupMessages[3]);
        }else{
            MC.ShowPopup(MC.PopupMessages[0]);
        }
    }else{
        MC.ShowPopup(MC.PopupMessages[1]);
    }
}

/*
 * Reset all the drag objects rotation to start rotation.
*/
MC.ResetRotations = function() {
    MC.DragObjects = [];
    MC.DragObjects[MC.TRIANGLELARGE1] = {};
    MC.DragObjects[MC.TRIANGLELARGE2] = {};
    MC.DragObjects[MC.TRIANGLESMALL1] = {};
    MC.DragObjects[MC.TRIANGLESMALL2] = {};
    MC.DragObjects[MC.SQUARE] = {};
    MC.CurrentDragObject = undefined;
    MC.DragObjects[MC.TRIANGLELARGE1].obj = $('#' + MC.TRIANGLELARGE1);
    MC.DragObjects[MC.TRIANGLELARGE2].obj = $('#' + MC.TRIANGLELARGE2);
    MC.DragObjects[MC.TRIANGLESMALL1].obj = $('#' + MC.TRIANGLESMALL1);
    MC.DragObjects[MC.TRIANGLESMALL2].obj = $('#' + MC.TRIANGLESMALL2);
    MC.DragObjects[MC.SQUARE].obj = $('#' + MC.SQUARE);
    MC.DragObjects[MC.TRIANGLELARGE1].rotation = 0;
    MC.DragObjects[MC.TRIANGLELARGE2].rotation = 90;
    MC.DragObjects[MC.TRIANGLESMALL1].rotation = 0;
    MC.DragObjects[MC.TRIANGLESMALL2].rotation = 0;
    MC.DragObjects[MC.SQUARE].rotation = 0;
    $('.drag-container-wrapper .triangle-lrg-2').css({transform: 'rotate(90deg)'});
    MC.CurrentDragObject = undefined;
}

/*
 * Stop the protractor rotating, clear the interval and reset the starting speed for the interval
*/
MC.ClearTimeout = function() {
    clearTimeout(MC.TIMEOUTID);
    clearTimeout(MC.TIMEOUTAUTOID);
    MC.RotationTimeoutTime = MC.ROTATIONMAXTIMEOUTTIME;
}

/*
 * Clear the AUTO time out, clear all intervals without resetting the interval time.
*/
MC.ClearAutoTimeout = function() {
    clearTimeout(MC.TIMEOUTAUTOID);
    clearTimeout(MC.TIMEOUTID);
}

/*
 * Clear the page or all pages 
*/
MC.Clear = function(){
    MC.Reset();
    $('.drop-zone').empty();
    $('.drop-containers-wrapper').find('.grid-icon-drag').remove();
    $('.tab').removeClass('selected');
    $('.tab.default').addClass('selected');
    $('.page').addClass(MC.CLASSHIDE);
    MC.PageComplete = [false, false, false, false, false, false, false];
    MC.CurrentPage = 1;
    $('.page1').removeClass(MC.CLASSHIDE);
}


/*
 * Reset the page items 
*/
MC.Reset= function(){
    MC.ClosePopup();
    if(checkAllPages()){
        for(var i = 0; i < 8; i++){
            MC.PagesStatus[i].complete = false;
        }
        MC.TickContainer.removeClass('page7').addClass(MC.CLASSHIDE);
        MC.Clear();
    }else{
        MC.PagesStatus[MC.CurrentPage].complete = false;
        $('.page' + MC.CurrentPage + ' .drop-zone').empty();
        $('.page' + MC.CurrentPage + ' .drop-containers-wrapper').find('.grid-icon-drag').remove();
        MC.TickContainer.removeClass('page7').addClass(MC.CLASSHIDE);
    }
    setupDragObjectsContainer();
    MC.ResetRotations();
    initDraggables();
}

/*
 * Update the draggables if a page is correct and locked.
*/
MC.UpdateDraggablesContainer = function(){
    setupDragObjectsContainer();
    initDraggables();
    MC.ResetRotations();
    var tempList = $('.page' + MC.CurrentPage + ' .drop-zone').children();
    MC.RemoveDraggables();
    $('.drag-container-wrapper .grid-icon-drag').removeClass('hide');
    $('.drag-container-wrapper .grid-icon-drag').draggable('disable');
    for(var i = 0; i < tempList.length; i++){
        $('.drag-container-wrapper #' + $(tempList[i]).attr('data-index')).addClass('hide');
        $(tempList[i]).attr('id', "new");
    }
}

/*
 * Remove all other objects from the drop area.
*/
MC.RemoveDraggables= function(){
    $('.drop-containers-wrapper > .grid-icon-drag').remove();
}

/*
 * Show the popup with nessage
*/
MC.ShowPopup = function(message){
    if(message != undefined && message != null && message != '')MC.PopupMessage.html(message);
    MC.Popup.removeClass(MC.CLASSHIDE);
}

/*
 * Hide the popup with nessage
*/
MC.ClosePopup = function(){
    MC.Popup.addClass(MC.CLASSHIDE);
}

/*
 * Print the page 
*/
MC.Print = function(){
    //console.log("Print");
    window.print();
}

/*
 * Initiate one rotate to the right - clockwise
*/
MC.RotateRight = function(e) {
    MC.Right();
    MC.ClearTimeout();
    MC.TIMEOUTID = setInterval(MC.AutoRotatRight, MC.RotationTimeoutTime);
}

/*
 * Rotate the protractor image inside the protractor element right and speed up if mouse down - clockwise
*/
MC.AutoRotatRight = function(){
    if(MC.RotationTimeoutTime > MC.ROTATIONMINTIMEOUTITME){
        MC.RotationTimeoutTime -= MC.ROTATIONTIMEOUTSPEED;
        MC.ClearAutoTimeout();
        MC.TIMEOUTAUTOID = setInterval(MC.AutoRotatRight, MC.RotationTimeoutTime);
    }
    MC.Right();
}

/*
 * Rotate the protractor image inside the protractor element right - clockwise
*/
MC.Right = function() {
    MC.ClosePopup();
    if(MC.CurrentDragObject != undefined){
        MC.CurrentDragObject.rotation += 5;
        if(MC.CurrentDragObject.rotation == 360)MC.CurrentDragObject.rotation = 0;
        $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});   
    }
}

/*
 * Initiate a rotate left - anti clockwise
*/
MC.RotateLeft = function(e) {
    MC.Left();
    MC.ClearTimeout();
    MC.TIMEOUTID = setInterval(MC.AutoRotateLeft, MC.RotationTimeoutTime);
}

/*
 * Rotate the protractor image left and speed up if mouse down - clockwise
*/
MC.AutoRotateLeft = function(){
    if(MC.RotationTimeoutTime > MC.ROTATIONMINTIMEOUTITME){
        MC.RotationTimeoutTime -= MC.ROTATIONTIMEOUTSPEED;
        MC.ClearAutoTimeout();
        MC.TIMEOUTAUTOID = setInterval(MC.AutoRotateLeft, MC.RotationTimeoutTime);
    }
    MC.Left();
}

/*
 * Rotate the protractor image left - anti clockwise
*/
MC.Left = function() {
    MC.ClosePopup();
    if(MC.CurrentDragObject != undefined){
        MC.CurrentDragObject.rotation -= 5;
        if(MC.CurrentDragObject.rotation < 0)MC.CurrentDragObject.rotation = 355;
        $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
    }
}

/*
 * Stop the protractor rotating, clear the interval and reset the starting speed for the interval
*/
MC.ClearTimeout = function() {
    clearTimeout(MC.TIMEOUTID);
    clearTimeout(MC.TIMEOUTAUTOID);
    MC.RotationTimeoutTime = MC.ROTATIONMAXTIMEOUTTIME;
}

/*
 * Clear the AUTO time out, clear all intervals without resetting the interval time.
*/
MC.ClearAutoTimeout = function() {
    clearTimeout(MC.TIMEOUTAUTOID);
    clearTimeout(MC.TIMEOUTID);
}



/*
 * Go to the next page
*/
// MC.Next = function(){
//     console.log("Next - Current Page: " + MC.CurrentPage);
//     MC.CurrentPage++;
//     console.log("Next - Next Page: " + MC.CurrentPage);
//     if(MC.CurrentPage == 2)enable(MC.BackBtn);
//     if(MC.CurrentPage == MC.MAXPAGES)disable(MC.NextBtn);
//     goToCurrentPage();
// }

/*
 * Go to the previous page
*/
// MC.Back = function(){
//     console.log("Back - Current Page: " + MC.CurrentPage);
//     MC.CurrentPage--;
//     console.log("Back - Back Page: " + MC.CurrentPage);
//     if(MC.CurrentPage == 1)disable(MC.BackBtn);
//     if(MC.CurrentPage == MC.MAXPAGES -1)enable(MC.NextBtn);
//     goToCurrentPage();
// }

/*
 * Set the Next button to reset or next. 
*/
function setNextButton(option){
    if(option == 'next'){
        MC.NextBtn.text(MC.NEXTBUTTONLABELNEXT);
        MC.NextBtn.removeClass(MC.CLASSRESET);
    }else{
        MC.NextBtn.text(MC.NEXTBUTTONLABELRESET);
        MC.NextBtn.addClass(MC.CLASSRESET);
    }
}

/*
 * Set the page conponents when moving to another page. 
*/
function goToCurrentPage(){
    hideAllPages();
    showCurrentPage();
}

/*
 *Hide all pages
*/
function hideAllPages(){
     $(".page").removeClass(MC.CLASSSHOW).addClass(MC.CLASSHIDE);
}

/*
 *Check if all pages are complete.
*/
function checkAllPages(){
    var allCorrect = true;
     for( var i = 1; i < MC.PagesStatus.length; i++){
        if(!MC.PagesStatus[i].complete){
            allCorrect = false;
            break;
        }
     }
     return allCorrect;
}

/*
 *Show current page
*/
function showCurrentPage(){
     MC.Pages[MC.CurrentPage].removeClass(MC.CLASSHIDE).Reset();
}

function disable(btn){
    btn.addClass('disabled').removeClass('hover');
    btn.off('click', btn.fcn);
}

function enable(btn){
    if(btn.hasClass('disabled')){
        if(!MC.IsTouch)btn.addClass('hover');
        btn.removeClass('disabled');
        btn.on('click', btn.fcn);
    }
}

/*
 * Remove all select classes from the draggable objects
*/
function removeSelectedClass(selector) {
    $(selector).removeClass(MC.CLASSSELECTED);
}

/*
 * Return the html structure for the drop elements
*/
function getDragObjects(selector) {
    return '<div id="tl1" class="grid-icon-drag triangle-lrg-1 tlrg tlrg1" data-index="tl1">' +
								 	'<svg class="svg-element svg-triangle-lrg-1" xmlns="http://www.w3.org/2000/svg" >' +
								 		'<g class="g-1">' +
								 			'<path class="svg-properties" d="M12,3h274L148,140Z"></path>' +
								 		'</g>' +
								 	'</svg>' +
								 '</div>' +
								 '<div id="tl2" class="grid-icon-drag triangle-lrg-2 tlrg tlrg2" data-index="tl2">' +
								 	'<svg class="svg-element svg-triangle-lrg-2" xmlns="http://www.w3.org/2000/svg">' +
								 		'<g class="g-1">' +
								 			'<path class="svg-properties" d="M12,3h274L148,140Z"></path>' +
								 		'</g>' +
								 	'</svg>' +
								 '</div>' +
								 '<div id="ts1" class="grid-icon-drag triangle-sm-1 tsm1" data-index="ts1">' +
								 	'<svg class="svg-element svg-triangle-sm-1" xmlns="http://www.w3.org/2000/svg">' +
								 		'<g class="g-1">' +
								 			'<path class="svg-properties" d="M4,11v135h135Z"></path>' +
								 		'</g>' +
								 	'</svg>' +
								 '</div>' +
								 '<div id="ts2" class="grid-icon-drag triangle-sm-2 tsm2" data-index="ts2">' +
								 	'<svg class="svg-element svg-triangle-sm-2" xmlns="http://www.w3.org/2000/svg">' +
								 		'<g class="g-1">' +
								 			'<path class="svg-properties" d="M4,11v135h135Z"></path>' +
								 		'</g>' +
								 	'</svg>' +
								 '</div>' +
								 '<div id="sqa" class="grid-icon-drag square" data-index="sqa">' +
								 	'<svg class="svg-element svg-square" xmlns="http://www.w3.org/2000/svg">' +
								 		'<g class="g-1">' +
								 			'<path class="svg-properties" d="M0,0v137h137v-137Z"></path>' +
								 		'</g>' +
								 	'</svg>' +
								'</div>';
}

/*
 * Initialise all draggable opject.
*/
function initDraggables() {
    $(".grid-icon-drag").draggable({
		revert: "true",
		containment: ".sub-content",
		cursor: "pointer",
		helper: "clone",
		start: function(event, ui) {
            $('.grid-drag').css("z-index", 1000000);
            $(this).addClass('hide');   
		},
		stop: function(event, ui) {
            var pos = ui.helper.offset();         
			$(ui.draggable).css("z-index", 10);
             $('.grid-drag').css("z-index", 10);
             $(this).removeClass('hide');    
		}
	});
    var offsetX = 454;
    var offsetY = 28;
    var offsetXalt = 24;
	/**
	 * Set draggable configuration for the the small square and the triangle
	 */
	$('.drop-containers-wrapper').droppable({
		accept: '.grid-icon-drag',
		create: function () {
		},
		drop: function (e, ui) {
            var adjustX = 0;
            $($(ui.draggable)[0]).appendTo($(this));
            var pos = ui.helper.offset();  
            var x = pos.left;// - offsetX;
            var y = pos.top// - offsetY;
            var windowWidth = window.outerWidth;
            var bodyWidth = $('body').outerWidth();
            var margin = (windowWidth - 970)/2;
            if(bodyWidth < 972){
                adjustX = 2;
                if(MC.android == true){
                   adjustX = 10;
                }
            }else{
                 if(MC.firefox){
                    adjustX = -2;
                }
                 if(MC.IE){
                    adjustX = -4;
                }
                if(MC.android == true){
                    adjustX = 6;
                } 
            }
            if(MC.ios){
                    adjustX = 10;
            }
            if(MC.win8){
                    adjustX = 6;
            }
            x = x - 5 - (adjustX);
            if(margin > 0 )x = x - margin;
            $($(ui.draggable)[0]).css('left', x);
            $($(ui.draggable)[0]).css('top', y - 7);
            
		}
	})
    //
    $('.drag-container-wrapper').droppable({
		accept: '.grid-icon-drag',
		create: function () {
		},
		drop: function (e, ui) {
            MC.DragObjects[$(ui.draggable)[0].id].rotation = 0;
            $($(ui.draggable)[0]).attr('style', '');
            if($($(ui.draggable)[0]).hasClass('triangle-lrg-2')){
                $($(ui.draggable)[0]).css('transform', 'rotate(90deg)');
                MC.DragObjects[$(ui.draggable)[0].id].rotation = 90;
            }
            $($(ui.draggable)[0]).appendTo($(this));
		}
	})
    //
    $('.ts').droppable({
		accept: '.triangle-sm-1, .triangle-sm-2',
		drop: function (e, ui) {
            var t1 = $($(this)[0].children[0]).hasClass('tsm1');
            var t2 = $($(ui.draggable)[0]).hasClass('tsm1');
            var t3 = $($(this)[0].children[0]).hasClass('tsm2');
            var t4 = $($(ui.draggable)[0]).hasClass('tsm2');
            var sameObject = false;
            if((t1 && t2) || (t3 && t4))sameObject = true;
            if($(this)[0].children.length == 0 || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
     $('.tl').droppable({
		accept: '.triangle-lrg-1, .triangle-lrg-2',
		drop: function (e, ui) {
            var t1 = $($(this)[0].children[0]).hasClass('tlrg1');
            var t2 = $($(ui.draggable)[0]).hasClass('tlrg1');
            var t3 = $($(this)[0].children[0]).hasClass('tlrg2');
            var t4 = $($(ui.draggable)[0]).hasClass('tlrg2');
            var sameObject = false;
            if((t1 && t2) || (t3 && t4))sameObject = true;
            if($(this)[0].children.length == 0 || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
    $('.sqr7').droppable({
		accept: '.square',
		drop: function (e, ui) {
            if($(this)[0].children.length == 0){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
    $('.tsl').droppable({
		accept: '.triangle-lrg-1, .triangle-lrg-2, .triangle-sm-1, .triangle-sm-2',
		drop: function (e, ui) {
            var pos = ui.helper.offset(); 
            var x = pos.left - ((window.outerWidth - 970)/2);// - offsetX;
            var y = pos.top;
            var childrenSquare = $('.page6 .sqa')[0].children.length;
            if($($(ui.draggable)[0]).hasClass('tlrg')){
                var t1 = $($(this)[0].children[0]).hasClass('tlrg1');
                var t2 = $($(ui.draggable)[0]).hasClass('tlrg1');
                var t3 = $($(this)[0].children[0]).hasClass('tlrg2');
                var t4 = $($(ui.draggable)[0]).hasClass('tlrg2');
                var sameObject = false;
                if((t1 && t2) || (t3 && t4))sameObject = true;
                if($(this)[0].children.length == 0 || sameObject){
                    $($(ui.draggable)[0]).removeAttr('style');
                    $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                    $($(ui.draggable)[0]).appendTo($(this));
                }
            }else{
                if(!$($(this)[0].children[0]).hasClass('tlrg')){
                    var t1 = $($(this)[0].children[0]).hasClass('tsm1');
                    var t2 = $($(ui.draggable)[0]).hasClass('tsm1');
                    var t3 = $($(this)[0].children[0]).hasClass('tsm2');
                    var t4 = $($(ui.draggable)[0]).hasClass('tsm2');
                    var sameObject = false;
                    if((t1 && t2) || (t3 && t4))sameObject = true;
                    //Only got further if there are not 2 elements already and if the is one and not the square
                    if((($(this)[0].children.length == 0 || ($(this)[0].children.length == 1) && childrenSquare != 1) || sameObject )){
                        //Check if the top or bottom dropable
                        if($(this).hasClass('tsltop')){
                            //If there is already an element
                            //console.log("Children: " + $(this)[0].children.length)
                            if($(this)[0].children.length == 1){
                                //If the one has the class left asign the other class
                                var t1 = $($(this)[0].children[0]).hasClass('tsm1');
                                var t2 = $($(ui.draggable)[0]).hasClass('tsm1');
                                var t3 = $($(this)[0].children[0]).hasClass('tsm2');
                                var t4 = $($(ui.draggable)[0]).hasClass('tsm2');
                                //if it is the same triangle stop
                                var sameObject = false;
                                if(($($(this)[0].children[0]).hasClass('tsm1') == true && $($(ui.draggable)[0]).hasClass('tsm1') == true) || ($($(this)[0].children[0]).hasClass('tsm12') == true && $($(ui.draggable)[0]).hasClass('tsm2') == true))sameObject = true;
                               if(!sameObject){
                                    $($(ui.draggable)[0]).removeClass('top').removeClass('bottom');
                                    $($(ui.draggable)[0]).removeClass('left').removeClass('right');
                                    if($($(this)[0].children[0]).hasClass('left')){
                                       if(childrenSquare == 1){
                                            $($(ui.draggable)[0]).addClass('left');
                                        }else{
                                            $($(ui.draggable)[0]).addClass('right');
                                        }
                                    }else{
                                        $($(ui.draggable)[0]).addClass('left');
                                    }
                                }else{
                                    $($(ui.draggable)[0]).removeClass('top').removeClass('bottom');
                                    $($(ui.draggable)[0]).removeClass('left').removeClass('right');
                                    if(x < 244){
                                        $($(ui.draggable)[0]).addClass('left');
                                    }else{
                                        if(childrenSquare == 1){
                                            $($(ui.draggable)[0]).addClass('left');
                                        }else{
                                            $($(ui.draggable)[0]).addClass('right');
                                        }
                                    }
                                }
                            }else{
                                $($(ui.draggable)[0]).removeClass('top').removeClass('bottom');
                                $($(ui.draggable)[0]).removeClass('left').removeClass('right');
                                if(x < 244){
                                    $($(ui.draggable)[0]).addClass('left');
                                }else{
                                     if(childrenSquare == 1){
                                        $($(ui.draggable)[0]).addClass('left');
                                    }else{
                                        $($(ui.draggable)[0]).addClass('right');
                                    }
                                }
                            }
                        }else{
                            if($(this)[0].children.length == 1){
                                //if it is the same triangle stop
                                var sameObject = false;
                                if(($($(this)[0].children[0]).hasClass('tsm1') == true && $($(ui.draggable)[0]).hasClass('tsm1') == true) || ($($(this)[0].children[0]).hasClass('tsm12') == true && $($(ui.draggable)[0]).hasClass('tsm2') == true))sameObject = true;
                                if(!sameObject){
                                    $($(ui.draggable)[0]).removeClass('top').removeClass('bottom');
                                    $($(ui.draggable)[0]).removeClass('left').removeClass('right');
                                    if($($(this)[0].children[0]).hasClass('top')){
                                        $($(ui.draggable)[0]).addClass('bottom');
                                    }else{
                                        if(childrenSquare == 1){
                                            $($(ui.draggable)[0]).addClass('bottom');
                                        }else{
                                            $($(ui.draggable)[0]).addClass('top');
                                        }
                                    }
                                }else{
                                    $($(ui.draggable)[0]).removeClass('top').removeClass('bottom');
                                    $($(ui.draggable)[0]).removeClass('left').removeClass('right');
                                    if(y < 253){
                                        if(childrenSquare == 1){
                                            $($(ui.draggable)[0]).addClass('bottom');
                                        }else{
                                            $($(ui.draggable)[0]).addClass('top');
                                        }
                                    }else{
                                        $($(ui.draggable)[0]).addClass('bottom');
                                    }
                                }
                            }else{

                                $($(ui.draggable)[0]).removeClass('top').removeClass('bottom');
                                $($(ui.draggable)[0]).removeClass('left').removeClass('right');
                                if(y < 253){
                                    if(childrenSquare == 1){
                                        $($(ui.draggable)[0]).addClass('bottom');
                                    }else{
                                        $($(ui.draggable)[0]).addClass('top');
                                    }
                                }else{
                                    $($(ui.draggable)[0]).addClass('bottom');
                                }
                            }
                        }
                        $($(ui.draggable)[0]).removeAttr('style');
                        $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                        $($(ui.draggable)[0]).appendTo($(this));
                    }
                }   
            }
		}
	})
    //
    $('.sqa').droppable({
		accept: '.square',
		drop: function (e, ui) {
            var dropIsLocked = false;
            if(MC.CurrentPage == 6){
                var childrenTop = $('.page6 .tsltop')[0].children;
                var childrenBot = $('.page6 .tslbottom')[0].children;
                var numElTop = childrenTop.length;
                var numElBot = childrenBot.length;
                if(numElTop == 2 || numElBot == 2) {
                    dropIsLocked = true;
                } else if(numElTop == 1){
                    if($(childrenTop[0]).hasClass('right'))dropIsLocked = true;
                }
                if(numElBot == 1){
                    if($(childrenBot[0]).hasClass('top'))dropIsLocked = true;
                }
            }
            var s1 = $($(this)[0].children[0]).hasClass('square');
            var s2 = $($(ui.draggable)[0]).hasClass('square');
            var sameObject = false;
            if((s1 && s2))sameObject = true;
            if(($(this)[0].children.length == 0 && !dropIsLocked) || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
     //for page 3 drag and drop
    $('.ts-3').droppable({
		accept: '.triangle-sm-1, .triangle-sm-2',
		drop: function (e, ui) {
            var dropIsLocked = false;
            var tl1, tl2, sqr = 0;
            //Chech which samll triangle drop zone is this
            var _this1 = $(this).hasClass('ts1');
            var _this2 = $(this).hasClass('ts2');
            var _this3 = $(this).hasClass('ts3');
            var _this4 = $(this).hasClass('ts4');
            sqr = $('.page3 .sqa')[0].children.length;
            tl1 = $('.page3 .tl1')[0].children.length;
            tl2 = $('.page3 .tl2')[0].children.length;
            if(_this1){
                if(tl1 > 0)dropIsLocked = true;
            }
            if(_this2){
                if(sqr > 0 || tl1 > 0)dropIsLocked = true;
            }
            if(_this3){
                if(sqr > 0 || tl2 > 0)dropIsLocked = true;
            }
            if(_this3){
                if(tl2 > 0)dropIsLocked = true;
            }
            var t1 = $($(this)[0].children[0]).hasClass('tsm1');
            var t2 = $($(ui.draggable)[0]).hasClass('tsm1');
            var t3 = $($(this)[0].children[0]).hasClass('tsm2');
            var t4 = $($(ui.draggable)[0]).hasClass('tsm2');
            var sameObject = false;
            if((t1 && t2) || (t3 && t4))sameObject = true;
            if(($(this)[0].children.length == 0 && !dropIsLocked) || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
    $('.tl-3').droppable({
		accept: '.triangle-lrg-1, .triangle-lrg-2',
		drop: function (e, ui) {
            var dropIsLocked = false;
            var _this1 = $(this).hasClass('tl1');
            var _this2 = $(this).hasClass('tl2');
            var ts1, ts2, ts3, ts4, sqr = 0;
            sqr = $('.page3 .sqa')[0].children.length;
            ts1 = $('.page3 .ts1')[0].children.length;
            ts2 = $('.page3 .ts2')[0].children.length;
            ts3 = $('.page3 .ts3')[0].children.length;
            ts4 = $('.page3 .ts4')[0].children.length;
            tl1 = $('.page3 .tl1')[0].children.length;
            tl2 = $('.page3 .tl2')[0].children.length;
            if(_this1){
                if(tl2 > 0 || ts1 > 0 || ts2 > 0 || sqr > 0)dropIsLocked = true;
            }
            if(_this2){
                if(tl1 > 0 || ts3 > 0 || ts4 > 0 || sqr > 0)dropIsLocked = true;
            }
            var t1 = $($(this)[0].children[0]).hasClass('tlrg1');
            var t2 = $($(ui.draggable)[0]).hasClass('tlrg1');
            var t3 = $($(this)[0].children[0]).hasClass('tlrg2');
            var t4 = $($(ui.draggable)[0]).hasClass('tlrg2');
            var sameObject = false;
            if((t1 && t2) || (t3 && t4))sameObject = true;
            if(($(this)[0].children.length == 0 && !dropIsLocked) || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    $('.page3 .sqa').droppable({
		accept: '.square',
		drop: function (e, ui) {
            var dropIsLocked = false;
            var ts1 = $('.page3 .ts2')[0].children.length;
            var tl1 = $('.page3 .tl1')[0].children.length;
            var tl2 = $('.page3 .tl2')[0].children.length;
            var ts2 = $('.page3 .ts3')[0].children.length;
            if(ts1 > 0 || tl1 > 0 || tl2 > 0 || ts2 > 0){
                dropIsLocked = true;
            }
            var s1 = $($(this)[0].children[0]).hasClass('square');
            var s2 = $($(ui.draggable)[0]).hasClass('square');
            var sameObject = false;
            if((s1 && s2))sameObject = true;
            if(($(this)[0].children.length == 0 && !dropIsLocked) || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //for page 4 drag and drop
    $('.ts-4').droppable({
		accept: '.triangle-sm-1, .triangle-sm-2',
		drop: function (e, ui) {
            var t1 = $($(this)[0].children[0]).hasClass('tsm1');
            var t2 = $($(ui.draggable)[0]).hasClass('tsm1');
            var t3 = $($(this)[0].children[0]).hasClass('tsm2');
            var t4 = $($(ui.draggable)[0]).hasClass('tsm2');
            var sameObject = false;
            if((t1 && t2) || (t3 && t4))sameObject = true;
            if($(this)[0].children.length == 0 || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
    $('.tl-4').droppable({
		accept: '.triangle-lrg-1, .triangle-lrg-2',
		drop: function (e, ui) {
            var t1 = $($(this)[0].children[0]).hasClass('tlrg1');
            var t2 = $($(ui.draggable)[0]).hasClass('tlrg1');
            var t3 = $($(this)[0].children[0]).hasClass('tlrg2');
            var t4 = $($(ui.draggable)[0]).hasClass('tlrg2');
            var sameObject = false;
            if((t1 && t2) || (t3 && t4))sameObject = true;
            if($(this)[0].children.length == 0 || sameObject){
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
            }
		}
	})
    //
    $('.page4 .sqr1').droppable({
		accept: '.square',
		drop: function (e, ui) {
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
           // }
		}
	})
    //
    $('.page4 .sqr2').droppable({
		accept: '.square',
		drop: function (e, ui) {
                $($(ui.draggable)[0]).removeAttr('style');
                $(MC.CurrentDragObject.obj).css({transform: 'rotate(' + MC.CurrentDragObject.rotation + 'deg)'});
                $($(ui.draggable)[0]).appendTo($(this));
           // }
		}
	})
}