/* Template JS */
/* The State of Queensland (Department of Education and Training) */

//jQuery - Run on page ready
$(document).ready(function () {
   
    //codes for interface design / positioning elements on iOS.
    if(isApple){
        $('.btn-design').css({'font-size':'13px'});
        $('#popup1, #popup').css({'font-weight':'200','font-size':'14px'});
        $('.btn-close').addClass('padding-ios').removeClass('padding-desk');
    }
    //for andriod device
    if (isDroid) {
        $('.btn-close').addClass('padding-droid').removeClass('padding-desk');
    }
    
    //insert first page elements on load.
    page_a();
    
    //show popup box
    $('#help').on('click touchend', function(e){
        e.preventDefault();
        $('#popup, #close').css({'visibility':'visible'});  
        $('#popup1, #close1').css({'visibility':'hidden'});
    });
    
    //close big popup message
    $('#popup, #close').on('mousedown touchstart', function(e){
        e.preventDefault();
        $('#popup, #close').css({'visibility':'hidden'});    
    });
    
    //close small popup message
    $('#popup1, #close1').on('mousedown touchstart', function(e){
        e.preventDefault();
        $('#popup1, #close1').css({'visibility':'hidden'});
    });
    
    /*check button*/
    $('#check').on('click touchend', function(e) {        
        e.preventDefault();
        //hide big popup to display only one popup at a atime.
        $('#popup, #close').css({'visibility':'hidden'});
        
        //to off the click if checkCount is 3.
        if(checkCount !== 3){            
            checkVal();
        } else {            
            //change all input boxes to readonly and cursor default
            $('input').prop('readonly', true).addClass('default-cursor');
            $('#popup1, #close1').css({'visibility':'visible'});
        }
    });
    
    /*reset accordin to page*/
    $('#reset').on('click touchend', function(e) {
         e.preventDefault();
    
        //first page
        if(page.a) {
            
            //reset all values
            $('#blue_tick').css({'visibility':'hidden'});
            $('#ballOne, #ballTwo, #ballThree').removeClass().addClass('balls hover').draggable('enable');
            
            //reset balls' positions.
            $('#ballOne').addClass('ball-one').css({'left':'10px','top':'10px'});
            $('#ballTwo').addClass('ball-two').css({'left':'20px','top':'80px'});
            $('#ballThree').addClass('ball-three').css({'left':'60px','top':'50px'});
            
            $('.tabs').removeClass('active-tab').addClass('normal-tab');
            $('#a').removeClass().addClass('tabs hover active-tab arial');
            $('#match_area_display').removeClass().addClass('tab-a-display');
            
            //reset ball drop values
            tab.a.ballDropped = tab.b.ballDropped = tab.c.ballDropped = false;
            tab.a.active = true;
            tab.b.active = tab.c.active = false;
            
            $('#popup1, #close1').css({'visibility':'hidden'});
 
            page_a();
            //second page & third page
        } else {
            
            if(page.c){
                $('#next').addClass('btn-disable').removeClass('btn-bg hover');
                document.getElementById('next').disabled = true;
            }            
            
            //reset the cells
            $('.cells').removeClass().addClass('hover cells cell-color-white');
        
            colorCount = checkCount = 0;
            $('input').val('');
            
            if($('input').hasClass('disabled-input')){
                $(this).removeClass('disabled-input');
            }
            
            //hide all blue ticks
            $('#blue_tick_pvm, #blue_tick_commfract, #blue_tick_cells').css({'visibility':'hidden'});
            
            //set all bool values to false upon reset
            correct_values.cell_count = correct_values.value_mat.ones = correct_values.value_mat.tths = correct_values.value_mat.hths = correct_values.comm_fract.bot = correct_values.comm_fract.top = correct_values.value_mat.tru = correct_values.comm_fract.tru = false;
            
            $('input').prop('readonly', false).removeClass('default-cursor disabled-input');
            $('#popup, #close, #popup1, #close1').css({'visibility':'hidden'});
            
            //don't need to change it again when page changes because html elements are updated
            document.getElementById('ones').disabled = false;
            document.getElementById('tths').disabled = false;
            document.getElementById('hths').disabled = false;
            document.getElementById('cf_top').disabled = false;
            document.getElementById('cf_bot').disabled = false;            
        }
    });
    
    $('#next').on('click touchend', function(e) {
        e.preventDefault();
        //set page b stats true
        if (page.c){
            page.b = page.c = false;
            page.a = true;             
            //reset values to their origins to reset the LO
            $('#next').html('Next').addClass('hover btn-bg').removeClass('btn-disable');        
            
            tab.a.ballDropped = tab.b.ballDropped = tab.c.ballDropped = false;
            page_a();
            
        } else if(page.a) {
            page.a = page.c = false;
            page.b = true;   
            
            page_b_c();
            //page b
        } else {
            page.a = page.b = false;
            page.c = true; 
            
            page_b_c();
        }        
    });
    
    $('#back').on('click touchend', function(e){
       e.preventDefault();
        //current page c
        if(page.c) {
            page.a = page.c = false;
            page.b = true;
            
            page_b_c();
        //current page b
        } else {
            page.b = page.c = false;
            page.a = true;
            
            tab.a.ballDropped = tab.b.ballDropped = tab.c.ballDropped = false;
            page_a();
        }
        
        //enable next button once page c is left.
        document.getElementById('next').disabled = false;
        $('#next').addClass('btn-bg hover').removeClass('btn-disable');
        
        //remove hover effect on mobile devices
        if(isApple || isDroid){
            $('.hover').removeClass('hover');
            $('#next').removeClass('hover');
        }    
    });   
    
    //mousedown and drag for cell selection.
    $(document).mousedown(function(){
        down = true;
    }).mouseup(function(){
        down = false;
    });  
});