//works when next button is clicked.
function page_b_c() {
    //set default values to check against input values
    ones_val = '0';
    cf_bot_val = '100';
    
    //hide the elements from first page
    $('#page_one, #blue_tick, #popup1, #close1').css({'visibility':'hidden'});
    
    //change instruction text and help text
    $('#instruction').html(text.instruction.two);
    $('#popup').html(text.help.two);
    
    //insert page 2 contents
    $('#pg_ctrl').html(page_content.two.main_content);
    
    //insert PVM and CF
    $('#right_side').html(page_content.two.value_mat + page_content.two.common_fraction);
    
    //create cells
    for(var count = 0; count < 100; count++) {
        $('#cell_area').append('<div class="hover cells cell-color-white"></div>');
    }
    
    //insert created cells / divs into an array for later use.
    cell_list = $('.cells');    
    
    //reveal page 2 and its elements
    $('#popup, #close, #page_two').css({'visibility':'visible'});
    
    //to change display heading and values accordingly
    if(page.b) {
        
        //forty-five hundredths
        $('#display_heading').html(text.heading.two);
        red_count = cell_count = 45;
        tths_val = '4';
        hths_val = '5';
        cf_top_val = '45';
        btnAction = '<b>next</b>';
        $('#next').html('Next');
        
        //page c
    } else {
        
        //nine-hundredths
        $('#display_heading').html(text.heading.three);
        red_count = cell_count = 9;
        tths_val = '0';
        hths_val = '9';
        cf_top_val = '9';
        btnAction = '<b>back</b>';
		
        //change next button text here and code it to reload.      
        $('#next').html('Reset').addClass('btn-disable').removeClass('hover btn-bg');
        document.getElementById('next').disabled = true;
        
        //change reset button text here
        $('#reset').html('Clear');
    }
    
    //cell selection functions
    $('.cells').on('mouseenter', function(e) {
         e.preventDefault();
         if(!correct_values.cell_count) {
             if(down) {
                //toogle the background colors
                if($(this).hasClass('cell-color-white')){                
                    $(this).removeClass('cell-color-white').addClass('cell-color-blue');    
                    colorCount++;
                }            
            } 
        }
    });

    //drag and select cells
    $('.cells').on('mousedown touchend', function(e){
        e.preventDefault();

        if(!correct_values.cell_count) {            
            //toogle the background colors
            if($(this).hasClass('cell-color-white')){
                $(this).removeClass('cell-color-white').addClass('cell-color-blue');    
                colorCount++;
            } else {
                $(this).removeClass('cell-color-blue').addClass('cell-color-white');    
                colorCount--;    
            }        
        }
    });
   
    //set input boxes on page 2 number only input boxes
    $('input').on('input', charLimit);
    
    //reset colour count and check count whenever page b is loaded / called.
    colorCount = checkCount = 0;
    
    //reset all the states to false upon page change
    correct_values.cell_count = correct_values.value_mat.ones = correct_values.value_mat.tths = correct_values.value_mat.hths = correct_values.comm_fract.bot = correct_values.comm_fract.top = correct_values.value_mat.tru = correct_values.comm_fract.tru = false;
    
    document.getElementById('back').disabled = false;
    document.getElementById('check').disabled = false;
    $('#back, #check').addClass('hover btn-bg').removeClass('btn-disable');
    
    //remove hover effect on mobile devices
    if(isApple || isDroid) {
        $('.hover').removeClass('hover');
		//adjust the sizes of the text boxex inside Common fraction
        if(isApple) {
			$('#cf_top').css({'top':'-32px','left':'-6px'});
			$('#cf_bot').css({'top':'-5px','left':'-6px'});
        }
    }   
    
    if (!isDroid) {
        $('#cell_area').addClass('noZoom');
    }
    //hide popups upon mousedown or touchstart
    $('#display_area').on('mousedown touchstart', function(e) {
        $('#popup, #close, #popup1, #close1').css({'visibility':'hidden'}); 
    });
}

//function to check values, i.e. cell count, input fields.
function checkVal() {
    
    //For a condition where either one of input boxes are empty / hold null values AND cell is no tselected.
    if (colorCount === 0 || !$('#hths').val() || !$('#tths').val() || !$('#ones').val() || !$('#cf_top').val() || !$('#cf_bot').val()) {        
        $('#popup1').html(text.popup_msg.empty);
        $('#popup1, #close1').css({'visibility':'visible'});
        
    //execute following codes when inputs are not empty - every field holds value(s) in them
    } else {
        checkCount++;
        //correct cell count
        if (colorCount === cell_count) {
            //remove the blue cells and replace them with green cells
            $('.cell-color-blue').removeClass('cell-color-blue').addClass('cell-color-green');
            //remove hover
            $('.cells').removeClass('hover');            
            //show blue tick in cell area   
            $('#blue_tick_cells').css({'visibility':'visible'});            
            correct_values.cell_count = true;                                           
        //incorrect input
        } else {
            //3 times incorrect input
            if (checkCount === 3) {
                //remove blue colored cells and replace them with white cells.
                $('.cell-color-blue').removeClass('cell-color-blue').addClass('cell-color-white');                
                //insert red color cells
                for (var j = 0; j < red_count; j++) {
                    $(cell_list[j]).removeClass('cell-color-white').addClass('cell-color-red');
                }                
                $('.cells').removeClass('hover');                
                //this will disable the cell selection after incorrect attampts
                correct_values.cell_count = true;           
            } else {
                $('.cells').removeClass('cell-color-blue').addClass('cell-color-white');    
                colorCount = 0;
            }
        }
        
        //correct Place Value Mat - ones input
        if ($('#ones').val() === ones_val) {
            $('#ones').prop('readonly', true).addClass('default-cursor');
            correct_values.value_mat.ones = true;
            document.getElementById('ones').disabled = true;
        //incorrect value
        } else {
            //generate the correct value in red colour
            if (checkCount === 3) {
                 $('#ones').val(ones_val).addClass('disabled-input default-cursor').prop('readonly', true);
                document.getElementById('ones').disabled = true;
                $('#ones').attr('se')
            }
        }
        
        //correct Place Value Mat - tths input
        if ($('#tths').val() === tths_val) {         
            $('#tths').prop('readonly', true).addClass('default-cursor');
            correct_values.value_mat.tths = true;           
            document.getElementById('tths').disabled = true;
        //incorrect value
         } else {
            //generate correct value in red colour
            if (checkCount === 3) {
                $('#tths').val(tths_val).addClass('disabled-input default-cursor').prop('readonly', true);    
                document.getElementById('tths').disabled = true;
            }         
        }
        
        //correct Place Value Mat - hths input
        if ($('#hths').val() === hths_val) {            
            $('#hths').prop('readonly', true).addClass('default-cursor');
            correct_values.value_mat.hths = true;
            document.getElementById('hths').disabled = true;
        //incorrect value
        } else {
            //generate correct value in red colour
            if (checkCount === 3) {
                $('#hths').val(hths_val).addClass('disabled-input default-cursor').prop('readonly', true);  
                document.getElementById('hths').disabled = true;
            }          
        }
        
        //correct Comm Fract value - top input
        if ($('#cf_top').val() === cf_top_val) {         
            $('#cf_top').prop('readonly', true).addClass('default-cursor');    
            correct_values.comm_fract.top = true;
            document.getElementById('cf_top').disabled = true;
        //incorrect value
        } else {
            //generate correct value in red colour
            if (checkCount === 3) {
                $('#cf_top').val(cf_top_val).addClass('disabled-input default-cursor').prop('readonly', true);    
                document.getElementById('cf_top').disabled = true;
            }          
        }
        
        //correct Comm Fract value - bot input
        if ($('#cf_bot').val() === cf_bot_val) {            
            $('#cf_bot').prop('readonly', true).addClass('default-cursor');
            correct_values.comm_fract.bot = true;  
            document.getElementById('cf_bot').disabled = true;
        //incorrect value
        } else {
            //generate correct value in red colour
            if (checkCount === 3) {
                $('#cf_bot').val(cf_bot_val).addClass('disabled-input default-cursor').prop('readonly', true);   
                document.getElementById('cf_bot').disabled = true;
            }          
        }

        //show blue tick for PVM if all 3 input boxes hold correct values
        if (correct_values.value_mat.ones && correct_values.value_mat.tths && correct_values.value_mat.hths) {
            $('#blue_tick_pvm').css({'visibility':'visible'}); 
            correct_values.value_mat.tru = true;        
        }
              
        //show blue tick for Comm Frat if all two input boxes hold correct values
        if (correct_values.comm_fract.top && correct_values.comm_fract.bot) {
            $('#blue_tick_commfract').css({'visibility':'visible'});
            correct_values.comm_fract.tru = true;          
        }
        
        //popup message for all correct inputs
        if (correct_values.cell_count && correct_values.value_mat.tru && correct_values.comm_fract.tru) {
            //page c
            if(page.c) {
                //select back to repeat
                $('#popup1').html(text.popup_msg.complete_first + btnAction + text.popup_msg.complete_second_c);
				document.getElementById('next').disabled = false;
                $('#next').html('Reset').removeClass('btn-disable').addClass('btn-bg hover');
            //page b
            } else {
                //select next to continue
                $('#popup1').html(text.popup_msg.complete_first + btnAction + text.popup_msg.complete_second_b);    
            }            
            $('#popup1, #close1').css({'visibility':'visible'});            
            //need to reset checkCount everytime correct message is displayed in order to not reach check count 3. 
            checkCount = 0;
            //remove focus from input fields 
            $('input').blur();
        }
        
        if (!correct_values.cell_count || !correct_values.value_mat.tru || !correct_values.comm_fract.tru) {
            //incomplete and incorrect input
            if (checkCount !== 3) {
                $('#popup1').html(text.popup_msg.incomplete);
                $('#popup1, #close1').css({'visibility':'visible'});     
                //empty inputs with incorrect values
                if (!correct_values.value_mat.ones) {
                    $('#ones').val('');
                }
                if (!correct_values.value_mat.hths) {
                    $('#hths').val('');
                }                
                if (!correct_values.value_mat.tths) {
                    $('#tths').val('');
                }                
                if (!correct_values.comm_fract.top) {
                    $('#cf_top').val('');
                }                
                if (!correct_values.comm_fract.bot) {
                    $('#cf_bot').val('');
                }                
            //incomplete 3 times
            } else {
                //3 times incorrect popup message 
                if(page.c) {
                    //for page c
                    $('#popup1').html(text.popup_msg.three_times_c);                     
                    //enable 'Reset' button to reload the page.
                    document.getElementById('next').disabled = false;
                    $('#next').html('Reset').removeClass('btn-disable').addClass('btn-bg hover');
                } else {
                    //for page b
                    $('#popup1').html(text.popup_msg.three_times_b);                
                }                
                $('#popup1, #close1').css({'visibility':'visible'}); 
                $('input').blur();
            }
        }            
    }
}