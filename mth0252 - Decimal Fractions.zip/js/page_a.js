//works when page a is called, i.e. back button is clicked or on load.
function page_a(){   
      
    //show page one and its elements when page loads or page changes  
    $('#page_one, #popup, #close').css({'visibility':'visible'});
    //insert page one contents into #pg_ctrl
    $('#pg_ctrl').html(page_content.one.main_content);
    //match_area and balloons tags are inside main_content
    $('#match_area').html(page_content.one.match_area);
    $('#balloons').html(page_content.one.balloons);
    
    //set balls draggable
    $('#ballOne, #ballTwo, #ballThree').draggable({
        revert: 'invalid',
        revertDuration: 40,
        containment:'#body',
        start: function(){
            //hide popup box when balls are dragged.
            $('#popup, #close, #popup1, #close1').css({'visibility':'hidden'});
			$(this).css({'z-index':'100'});			
			$(this).mouseup(function(){
				$(this).css({'z-index':'1'});
			});
        }
    });
    
    //set droppable area
    $('#match_area_display').droppable({
            accept: '#ballOne, #ballTwo, #ballThree',
            tolerance: 'intersect', //to not block tabs
            drop: function(event, ui){
                //call function.
                ballDropped(ui.draggable.attr('id'));
            }
        });
    
    //tab clicks
    $('#a, #b, #c').on('click touchend', function(e){
        e.preventDefault();
        var tabID = e.target.id;
        $('.tabs').removeClass('active-tab').addClass('normal-tab');
        
        //reset balloons' positions unless the balls are dropped / it's a correct drop
        $('#ballOne').css({'left':'10px','top':'120px'}).removeClass('ball-one-correct').addClass('ball-one hover');
        $('#ballTwo').css({'left':'20px','top':'10px'}).removeClass('ball-two-correct').addClass('ball-two hover');
        $('#ballThree').css({'left':'60px','top':'50px'}).removeClass('ball-three-correct').addClass('ball-three hover');
        
        //hide popup message and blue tick when tab changed.
        $('#blue_tick, #popup1, #close1').css({'visibility':'hidden'});
        $('#ballOne, #ballTwo, #ballThree').draggable('enable');
        
        if (tabID === 'a') {
            activeTabA();
        } else if (tabID === 'b') {
            activeTabB();
        } else {
            activeTabC();
        }
    });
    
    //hide page two, its elements and popup1
    $('#page_two, #popup1, #close1').css({'visibility':'hidden'});
    
    //set instruction label and help popup message.
    $('#instruction').html(text.instruction.one);
    $('#popup').html(text.help.one);
    
    //display tab a as default upon page change.
    $('.tabs').removeClass('active-tab').addClass('normal-tab');
    $('#a').removeClass().addClass('tabs active-tab hover arial');
    $('#match_area_display').removeClass().addClass('tab-a-display');
    activeTabA();
    
    //these codes are intended to reset balloons colours to grey if they were active before page change.
    $('#ballOne').removeClass('ball-one-correct').addClass('ball-one');
    $('#ballTwo').removeClass('ball-two-correct').addClass('ball-two');
    
    //disable check and back buttons for first page.
    document.getElementById('back').disabled = true;
    document.getElementById('check').disabled = true;
    $('#back, #check').addClass('btn-disable').removeClass('hover btn-bg');
    
    //remove hover effect on mobile devices
    if(isApple || isDroid){
        $('.hover').removeClass('hover');
    }
    
    //hide big popup box when these tags are click - mousedown. put this inside page_a so that it will work when clear button is clicked.
     $('#balloons, #match_area, #ballOne, #ballTwo, #ballThree').on('mousedown touchstart', function(e) {
        $('#popup, #popup1, #close, #close1').css({'visibility':'hidden'});        
    });
}

//works when the balls are dropped, parent codes in script.js
function ballDropped(ID){
    var ballID = ID;    
    //check tab
    if (tab.a.active){
        //without these codes, incorrect balloons won't be sent back to their origins
        $('#ballTwo').css({'left':'20px','top':'10px'});
        $('#ballOne').css({'left':'10px','top':'120px'});
        
        //without this if, 0.78 ball will be disabled when the other two balls are dragged.
        if(ballID === 'ballThree'){
            //disable draggable for correct balloon.
            $('#ballThree').draggable('disable');
            //remove hover and replace grey balloon with yellow one.
            $('#ballThree').removeClass('ball-three hover').addClass('ball-three-correct');
            $('#blue_tick').css({'visibility':'visible'});
            
            //capture drop position for tab change
            tab.a.ballDropped = true; 
            pos = $('#ballThree').position();
            
            //need to add -190 otherwise, it won't display correctly.
            ballDropPosition.three.left = pos.left - 190;
            ballDropPosition.three.top = pos.top;
            
            //this is called inside IF to prevent generating popup message everytime balls are dropped
            //in other words, popup message will only be displayed when correct ball is dropped.
            popupMsg();
        }        
    } else if (tab.b.active) {
        //without these codes, incorrect balloons won't be sent back to their origins
        $('#ballTwo').css({'left':'20px','top':'10px'});
        $('#ballThree').css({'left':'60px','top':'50px'});
        
        //without this if, 0.37 ball will be disabled when the other two balls are dragged.
        if (ballID === 'ballOne') {
            $('#ballOne').draggable('disable');
            $('#ballOne').removeClass('ball-one hover').addClass('ball-one-correct');
            $('#blue_tick').css({'visibility':'visible'});
             
            tab.b.ballDropped = true;
            pos = $('#ballOne').position();
            
            ballDropPosition.one.left = pos.left - 95;
            ballDropPosition.one.top = pos.top;
            
            popupMsg();
        }
    } else {
        //without these codes, incorrect balloons won't be sent back to their origins
        $('#ballOne').css({'left':'10px','top':'120px'});
        $('#ballThree').css({'left':'60px','top':'50px'});
        
        if(ballID === 'ballTwo'){
            $('#ballTwo').draggable('disable');
            $('#ballTwo').removeClass('ball-two hover').addClass('ball-two-correct');
            $('#blue_tick').css({'visibility':'visible'});
            
            tab.c.ballDropped = true;
            pos = $('#ballTwo').position();
            
            //need to add - 100 otherwise, it won't display correctly.
            ballDropPosition.two.left = pos.left;
            ballDropPosition.two.top = pos.top;
            
            popupMsg();            
        }
    }
}

//correct drop popup message
function popupMsg(){    
    if(tab.a.ballDropped && tab.b.ballDropped && tab.c.ballDropped){
        $('#popup1').html(text.popup_msg.a_two);
    } else {
        $('#popup1').html(text.popup_msg.a_one);
    }    
    $('#popup1, #close1').css({'visibility':'visible'});
}

//Following functions are separated as they are recalled at some point.
function activeTabA(){
    tab.a.active = true;
    tab.b.active = false;
    tab.c.active = false;
    
    //set tab a active and change display image for 0.78 balloon.
    $('#a').removeClass('normal-tab').addClass('active-tab');
    $('#match_area_display').removeClass().addClass('tab-a-display');
    
    //to keep the ball at dropped position if dropped
    if(tab.a.ballDropped){            
        //reposition the balls to their original positions.
        $('#ballTwo').css({'left':'20px','top':'10px'});
        $('#ballOne').css({'left':'10px','top':'120px'});       
        
        //keep the ball at its correct / dropped position.
        $('#ballThree').css({
            'left': ballDropPosition.three.left + 'px',
            'top': ballDropPosition.three.top + 'px'
        }).removeClass('ball-three hover').addClass('ball-three-correct').draggable('disable');
        $('#blue_tick').css({'visibility':'visible'});            
    }        
}


function activeTabB(){
    tab.b.active = true;
    tab.a.active = false;
    tab.c.active = false;
    
    //set tab b active and change display image for 0.37 balloon.
    $('#b').removeClass('normal-tab').addClass('active-tab');
    $('#match_area_display').removeClass().addClass('tab-b-display');
    
    //to keep the ball at dropped position if dropped
    if(tab.b.ballDropped){
        //reposition the balls to their original positions.
        $('#ballThree').css({'left':'60px','top':'50px'});
        $('#ballTwo').css({'left':'20px','top':'10px'});
        
        //keep the ball at its correct / dropped position.
        $('#ballOne').css({
            'left': ballDropPosition.one.left + 'px',
            'top': ballDropPosition.one.top + 'px'
        }).removeClass('ball-one hover').addClass('ball-one-correct').draggable('disable');
        $('#blue_tick').css({'visibility':'visible'});            
    }        
}


function activeTabC(){
     tab.c.active = true;
        tab.a.active = false;
        tab.b.active = false;
    
        //set tab c active and change display image for 0.07 balloon.
        $('#c').removeClass('normal-tab').addClass('active-tab');
        $('#match_area_display').removeClass().addClass('tab-c-display');
        
        //to keep the ball at dropped position if dropped
        if(tab.c.ballDropped){
            //reposition the balls to their original positions.
            $('#ballOne').css({'left':'10px','top':'120px'});
            $('#ballThree').css({'left':'60px','top':'50px'});
            
            //keep the ball at its correct / dropped position.
            $('#ballTwo').css({
                'left': ballDropPosition.two.left + 'px',
                'top': ballDropPosition.two.top + 'px'
            }).removeClass('ball-two hover').addClass('ball-two-correct').draggable('disable');
            
            $('#blue_tick').css({'visibility':'visible'}); 
        }
}