//all labels
var text = {
    instruction : {
        one: '<label>Match the balloon to the hundredths grid.</label>',
        two: '<label>Show the decimal fraction in 3 different ways.</label>'},
    help: {
        one: '<label>Drag the balloon that shows the matching decimal fraction onto the hundredths grid.</label>',
        two: '<label>1. Drag your mouse across the rows to colour the hundredths.</label><br /><br /><label>2. Select a square to remove the colour.</label><br /><br /><label>3. Write the number in the correct columns on the place value mat.</label><br /><br /><label>4. Write the number as a common fraction.</label>'},
   popup_msg: {
       empty: '<label>Complete the activity before you select <b>check</b>.</label>',
       incomplete: '<label>Try again.</label>',
       complete_first: '<label>Great work. Select ',
       complete_second_c: ' to repeat an activity or <b>reset</b> to start again.</label>',
       complete_second_b: ' to continue.</label>',
       three_times_b: '<label>Here are the correct answers. Select <b>next</b> to continue or <b>clear</b> to try again.</label>',
       three_times_c: '<label>Here are the correct answers. Select <b>reset</b> to try again, or <b>back</b> to repeat an activity. </label>',
       a_one: '<label>Well done. Select another tab to continue.</label>',
       a_two: '<label>Very good. Select <b>next</b> to continue.</label>'},
    heading: {
        two: '<label>(i) forty-five hundredths</label>',
        three: '<label>(ii) nine-hundredths</label>'
    }
};

//control for tabs on first page
var tab = {
    a: {ballDropped: false, active: true},
    b: {ballDropped: false, active: false},
    c: {ballDropped: false, active: false}
};

//array for cells
var cell_list;

//for easier repositioning of the balls upon tab changes.
var ballDropPosition = {
    one: {left: 0, top: 0},
    two: {left: 0, top: 0},
    three: {left: 0, top: 0}
};

//for ball positions on page one
var pos;

//to count blue bg cells | for page two and three
var colorCount, cell_count, red_count, ones_val, tths_val, hths_val, cf_top_val, cf_bot_val, btnAction;

//to count check button clicks | for page two and three
var checkCount = 0;
var down = false;

//page control.
var page = {a: true,b: false,c: false};

//correct values for each input
var correct_values = {
    cell_count: false,
    value_mat: {ones: false, tths: false, hths: false, tru: false},
    comm_fract: {top: false, bot: false, tru: false}
};

//hold contents for pages | HTML codes.
var page_content = {
    one: { main_content: '<div id="match_area" class="bg-br-bra"></div><div id="a" class="tabs active-tab hover arial">a</div><div id="b" class="tabs normal-tab hover arial">b</div><div id="c" class="tabs normal-tab hover arial">c</div><div id="balloons"></div>',
          match_area: '<div id="match_area_display" class="tab-a-display"></div><div id="blue_tick" class="tick" style="visibility:hidden;"></div>',
          balloons: '<div id="ballTwo" class="balls ball-two hover" style="left:20px; top:10px;"></div><div id="ballOne" class="balls ball-one hover" style="left:10px; top:120px;"></div><div id="ballThree" class="balls ball-three hover" style="left:60px; top:50px;"></div>'},
    two: {'main_content': '<div id="display_area" class="bg-br-bra"><div id="left_side"><div id="display_heading" class="arial"></div><div id="cell_area"></div><div id="blue_tick_cells" class="tick" style="visibility:hidden;"></div></div><div id="right_side"></div>',
          'value_mat': '<div id="pvm" class="arial"><label><b>Place value mat</b></label><div class="pvm-cells pvm-cells-top-left"><b>T</b></div><div class="pvm-cells pvm-cells-top"><b>Ones</b></div><div class="pvm-cells pvm-cells-top"><b>t</b></div><div class="pvm-cells pvm-cells-top-right"><b>h</b></div><div class="pvm-cells pvm-cells-bottom-left"></div><div class="pvm-cells pvm-cells-bottom"><input id="ones" type="text" maxlength="1" style="font-size:16px;"><div class="dot"></div></div><div class="pvm-cells pvm-cells-bottom"><input id="tths" type="text" maxlength="1" style="font-size:16px;"></div><div class="pvm-cells pvm-cells-bottom-right"><input id="hths" type="text" maxlength="1" style="font-size:16px;"></div><div id="blue_tick_pvm" class="tick" style="visibility:hidden;"></div></div>',
          'common_fraction': '<div id="comm_fraction" class="arial"><label><b>Common fraction</b></label><div class="com-fract-cells-top com-fract-cells" style="width:60px;padding:5px 0px 2px 5px;"><input id="cf_top" type="text" maxlength="3" style="font-size:16px;"></div><div class="com-fract-cells-bot com-fract-cells" style="width:60px;padding:7px 0px 0px 5px;"><input id="cf_bot" type="text" maxlength="3" style="font-size:16px;"></div><div id="blue_tick_commfract" class="tick" style="visibility:hidden;"></div>'
         }
};

//useragents for mobile devices.
var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
var isDroid = /Android/i.test(navigator.userAgent);

/*Function to set input - number only*/
function charLimit() {	
        var position = this.selectionStart;
        var start = $('#hths, #tths, #ones, #cf_top, #cf_bot').val().length;
        this.value = this.value.replace(/[^0-9]+/g, '');
        //this.value = this.value.replace(/[^0-9.]+/g, '');
        var final = $('#hths, #tths, #ones, #cf_top, #cf_bot').val().length;
	
		/*Codes that keep cursor position as it is instead of moving to the end of input*/
        if (start == final) {
            this.selectionEnd = position;
        } else {
            this.selectionEnd = position - 1;
    	}	
}