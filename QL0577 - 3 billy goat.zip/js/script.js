/*The State of Queensland (Department of Education and Training)*/

var display = {
    intro : "Hello! My name is Middle-sized Billy Goat Gruff. I have a big brother whose name is Great Big Billy Goat Gruff. And I have a little brother whose name is Little Billy Goat Gruff. My brothers and I are fat and happy.<br/><br/> But life wasn't always this good ... My brothers and I used to live in a dry, dusty meadow on the other side of the river. There was never enough grass to eat, and our tummies growled with hunger all day long.<br/><br/>Across the river was a beautiful meadow where the grass was lush and green. I know what you're thinking. Why didn't we just walk across the bridge to the other side, and eat the lush, green grass? Let me tell you why ...<br/><br/>Under the bridge lived a nasty, fierce, goat-eating troll! But one day, my brothers and I were so hungry we knew we had to get to the meadow on the other side of the river. It was time to cross the bridge.<br/><br/>",
    lilbro : "Little Billy Goat Gruff went first. He set off across the wooden bridge - trip, trap, trip, trap, trip, trap. Suddenly, from the darkness under the bridge, an awful voice called out: \"Who\'s that trip-trapping over my bridge!\"<br/><br/>My little brother was shaking with fear, but he called back: \"It\'s me! Little Billy Goat Gruff! I\'m going to the meadow so I can eat the lush, green grass!\" And I heard the troll reply: \"No, you\'re not! I\'m going to eat you up!\" And two horrible hands reached up out of the darkness!<br/><br/>And Little Billy Goat Gruff said, \"Don\'t eat me! My brother, Middle-sized Billy Goat Gruff, will be along in a minute. He\'s bigger than me.\" And the troll said: \"A middle-sized goat, hey? Hmm ... yum! All right, off you go.\" And my little brother trip-trapped over the bridge to the other side, and he was so hungry he just put his head down and chomped at the lush, green grass.<br/><br/>",
    myturn: "Now it was my turn to cross the bridge. I was so scared! But off I went - trip, trap, trip, trap, trip, trap - over the wooden bridge. I was halfway across when I heard: \"Who\'s that trip-trapping over my bridge! I was shaking with fear, but I called back: \"It\'s me! Middle-sized Billy Goat Gruff! I\'m going to the meadow so I can eat the lush, green grass!<br/><br/>And I Heard the troll reply: \"No you\'re not! I\m going to eat you up!\" I saw the troll's big ugly hands reach up over the side of the bridge. I was so scared. I called out: \"Don\'t eat me! My brother, Great Big Billy Goat Gruff, will be along in a minute. He\'s bigger than me.\"<br/><br/>And the troll said: \"A great big goat, hey? Hmm ... yum! All right, off you go.\" And I quickly trip-trapped over the bridge to the other side. Oh, the grass was so green! I put my head down and took a big, tasty mouthful! But then I remember my poor brother, Great Big Billy Goat Gruff. He still had to make the terrible walk across the bridge.<br/><br/>",
    bigbro: "Trip, trap, trip, trap, trip, trap! Over the bridge he came! And sure enough, he was halfway across when: \"Who\'s that trip-trapping over my bridge!\" My brother replied: \"It is I, Great Big Billy Goat Gruff. I\'m going to the meadow so I can eat the lush, green grass!\"<br/><br/> And I heard the troll reply: \"No you're not! I\'m going to eat you up!\" And two big hands reached up over the side of the bridge. But Great Big Billy Goat Gruff stood his ground. \"Do your best, troll!\" he said. \"I can take you!\"<br/><br/>The troll roared and pulled himself up onto the bridge. I\'d never really seen him before, with his long yellow nails; long, pointy nose and eyes as big and round as dinner plates! I was sure that troll was going to swallow my brother in one gulp.<br/><br/>",
    theend: "Suddenly, the troll ran at my brother and my brother ran at the troll. Closer and closer and closer and closer and - BANG! The troll trumbled off the bridge and fell down, down, down into the river far below ... and was never heard of again.<br/><br/>And now my brothers and I live on the good side of the river, in the lush, green meadow, and eat, eat, eat juicy green grass all day long. Oo - now I mention it, I think I see a nice big clump of new grass over there - better go! See ya!"
};
    
/*Run on page ready*/
$(document).ready(function(){
	vdoTimerFun();

    $("#displayTxt").html(display.intro);       //insert texts to html
    $("#displayTxt").append(display.lilbro);    //add more texts
	$("#displayTxt").append(display.myturn);
    $("#displayTxt").append(display.bigbro);
    $("#displayTxt").append(display.theend);
    
	$("#btnTxtDisplay").on("click touchend", txtDisplay);
	
	ctrlBtns();
	
	volBtn();
	
	detectDevice();
	
	$("#btnPrint").on("click touchend", function(e){
		e.preventDefault();
        //creat a tag, insert link and open new tab on click
        var newTab = document.createElement('a');
        newTab.href = 'assets/EY1_06_3BGG.pdf';
        window.open(newTab.href, '_blank');
	});
	
	$('#btnTxtDisplay, #btnPrint, #btnPlay, #btnStop, #btnPause, #btnVol').on('dragstart', false);   
    
});

function txtDisplay(){          
        //off click action
        $('#btnTxtDisplay').off('click touchend');
    
        //Toogle slide left and right
        $("#displayTxt").toggle("slide", {
            direction: "left"
        }, 300);
    
        setTimeout(function() {
            //turn back on
            $("#btnTxtDisplay").on('click touchend', txtDisplay);            
        }, 700);
	}

/*Function to detect mobile device / desktop browser and hide button on iPad and hover features on all mobile devices.*/
function detectDevice(){
	var isApple = /iPhone|iPad|iPod/i.test(navigator.userAgent);
	var isDroid = /Android/i.test(navigator.userAgent);
	
	if (isApple) {
		$('#btnVol').hide();
		$('.hover').removeClass('hover');
	} else if (isDroid) {
		$('.hover').removeClass('hover');
		//add these to display 00:00 on load on andriod
		var min = '00';
		var sec = '00';
		document.getElementById("timer").innerHTML = min + ":" + sec;
	} else {
		hoverEffects();
	}	
}

//Function to display text on hovering the buttons | If hover, visible. Else, hidden
function hoverEffects(){
	//Display 'Play' TEXT on screen on hovering play button
	$("#btnPlay").hover(function(){
        $('#playTxt').css({'visibility':'visible'});
	}, function() {
		$('#playTxt').css({'visibility':'hidden'});		
	});
	
	//Display 'Stop' TEXT on screen on hovering stop button
	$("#btnStop").hover(function(){		
        $('#stopTxt').css({'visibility':'visible'});
	}, function(){		
		$('#stopTxt').css({'visibility':'hidden'});
	});
	
	//Display 'Pause' TEXT on screen on hovering pause button
	$("#btnPause").hover(function(){		
        $('#pauseTxt').css({'visibility':'visible'});
	}, function(){		
        $('#pauseTxt').css({'visibility':'hidden'});
	});
	
	//Display 'Volume' TEXT on screen on hovering volume button
	$("#btnVol").hover(function(){		
        $('#volTxt').css({'visibility':'visible'});
	}, function(){		
        $('#volTxt').css({'visibility':'hidden'});
	});
}

function vdoTimerFun(){
	var vdoTime = document.getElementById("videoScreen");
	
	vdoTime.addEventListener("timeupdate", function(){
		/*Store video timer value in variable*/
		
		var currentTime = this.currentTime;
		var remainingseconds = 0;
		var sec = '00';
		var min = '00';
		
		/*Condition check for minute display*/
		if(currentTime >= 60){
			if(Math.floor(currentTime / 60) < 10) {
				min = "0" + Math.floor(currentTime / 60);
			} else {
				min = Math.floor(currentTime / 60);
			}
		}

		remainingseconds = currentTime - (Math.floor(currentTime / 60) * 60);

		/*Condition check for second display*/
		if (remainingseconds < 10) {
			sec = "0" + Math.floor(remainingseconds);
		} else {
			sec = Math.floor(remainingseconds);	
		}
		
		/*Display the numbers on load*/
		document.getElementById("timer").innerHTML = min + ":" + sec;
	});
	
	//Set the timer back to 00:00 at the end of audio. ()
	vdoTime.addEventListener('ended', function(){
		var sec = '00';
		var min = '00';
		document.getElementById('timer').innerHTML = min + ":" + sec;
	});	
}

/*Function to control the video - play, pause, stop*/
function ctrlBtns(){
	
	var vdo = document.getElementById("videoScreen");
	
	$("#btnPlay").on("click touchend", function(e){
		e.preventDefault();
		vdo.play();
	});
	
	$("#btnStop").on("click touchend", function(e){
		e.preventDefault();
		
		if (vdo.currentTime !== 0){
			vdo.pause();
			vdo.addEventListener("loadedmetadata", function () {
				
				/*Assign 0 to current time*/
				vdo.currentTime = 0;
				
			}, false);		
			
			/*reload the video file on load and pause to get ready*/
			vdo.load();
			vdo.pause();
		}
	});
	
	$("#btnPause").on("click touchend", function(e){
		e.preventDefault();
		vdo.pause();
	});	
}

/*Function to control volume*/
function volBtn(){
	
	/*Store different volume images*/
	var volume = new Array("assets/images/volume3.png", "assets/images/volume2.png", "assets/images/volume1.png", "assets/images/volume.png");
	var counter = 0;

	$("#btnVol").on("click touchend", function(e){
		e.preventDefault();
		/*Reset the counter if it reaches 3*/
		if (counter === 3){
			counter = 0;
		} else {
			counter++;
		}
		
		/*Set volume according to click count*/
		if (counter === 0){
			document.getElementById("videoScreen").volume = 1;
		} else if (counter === 1){
			document.getElementById("videoScreen").volume = 0.6;
		} else if (counter === 2){
			document.getElementById("videoScreen").volume = 0.3;
		} else { 	/*counter == 3*/
			document.getElementById("videoScreen").volume = 0;
		} 
		
		/*Insert volume images into HTML code*/
		$("#btnVol").html("<img src=" + volume[counter] + ">");
	});
}